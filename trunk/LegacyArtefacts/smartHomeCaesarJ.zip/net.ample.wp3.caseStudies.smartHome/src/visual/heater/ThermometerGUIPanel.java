package visual.heater;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import heaterManagement.*;

public class ThermometerGUIPanel extends JPanel{
	
	//Variable to store a reference to the CaesarJ GUIComponent of the heater of the panel 
	HeaterManagement.ThermometerGUI guiComponent; 
	public String thermometerId;
	public String roomId;
	public String floorId;
	public JLabel id;
	public JPanel panel;
	public JLabel temp;
	public JLabel tempText;
	public JLabel outTemp;
	public JLabel outTempText;
	
	//Thermometer icon
	ImageIcon iconImage;
	JLabel icon;
	
	public String getThermometerId() {
		return thermometerId;
	}

	public void setThermometerId(String id) {
		this.thermometerId = id;
		this.id.setText(id);
	}
	
	public String getTemp() {
		return temp.getText();
	}

	public void setTemp(String temp){
		this.temp.setText(temp);
	}
	
	public String getOutsideTemp() {
		return outTemp.getText();
	}

	public void setOutsideTemp(String temp){
		this.outTemp.setText(temp);
	}
	
	public ThermometerGUIPanel(HeaterManagement.ThermometerGUI guiComponent ){
		super();
		this.guiComponent=guiComponent;
		
		iconImage=createImageIcon("/visual/icons/thermometer40.png","Thermomter icon");
		icon=new JLabel(iconImage);
		
		this.id=new JLabel("");
		this.tempText=new JLabel("Temp: ");
		this.temp=new JLabel("00");
		this.outTempText=new JLabel("OutTemp: ");
		this.outTemp=new JLabel("00");
		
		this.add(icon);
		this.add(this.id);
		this.add(this.tempText);
		this.add(this.temp);
		this.add(this.outTempText);
		this.add(this.outTemp);
	}
	
	//Change the thermometer temp if it exists
	public void changeThermometerTemp(String id, String temp){
		if(thermometerId.equals(id)){
			setTemp(temp);
		}
	}
	
	//Change the thermometer outside temp if it exists
	public void changeThermometerOutsideTemp(String id, String temp){
		if(thermometerId.equals(id)){
			setOutsideTemp(temp);
		}
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}