package visual.heater;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import heaterManagement.*;

public class VisualHeatingController extends JPanel{
		
	//Variable to store a reference to the CaesarJ GUIComponent that represent this visual class 
	HeaterManagement.HeatingController guiComponent;
	
	//Required swing visual elements
	JLabel heaterId;
	String heaterIdString;
	String roomIdString;
	String floorIdString;
	
	JLabel power;
	JLabel powerText;
	JLabel mode;
	JLabel modeText;
	JLabel state;
	JLabel stateText;
		
	//Thermometer icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualHeatingController(HeaterManagement.HeatingController guiComponent){
		this.guiComponent=guiComponent;
		
		iconImage=createImageIcon("/visual/icons/heater40.png","Thermomter icon");
		icon=new JLabel(iconImage);
		
		heaterId=new JLabel();
		heaterIdString=null;
		roomIdString=null;

		this.power=new JLabel("00%");
		this.powerText=new JLabel("Power: ");
		this.mode=new JLabel("Cooling");
		this.modeText=new JLabel("Mode: ");
		this.state=new JLabel("Off");
		this.stateText=new JLabel("State: ");
		
		this.add(icon);
		this.add(heaterId);
		this.add(powerText);
		this.add(power);
		this.add(modeText);
		this.add(mode);
		this.add(stateText);
		this.add(state);
	}

	public void setPower(String power) {
		this.power.setText(power);
	}

	public void setMode(String mode) {
		this.mode.setText(mode);
	}

	public void setState(String state) {
		this.state.setText(state);
	}

	public void setHeaterId(String heaterId){
		this.heaterId.setText(heaterId);
		heaterIdString=heaterId;
		if((heaterIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "HeaterController", heaterIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((heaterIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "HeaterController", heaterIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((heaterIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "HeaterController", heaterIdString, this);
		}
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
	
}