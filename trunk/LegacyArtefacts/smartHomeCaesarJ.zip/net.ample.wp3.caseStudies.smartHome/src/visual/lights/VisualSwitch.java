package visual.lights;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

import lightManagement.LightManagement.Switch;

//Auxiliar class to show the switch in the Screen

public class VisualSwitch extends JPanel implements ActionListener{
	
	//Reference to the Switch component in which it is contained
	public Switch switchComponent;
	//Required swing visual elements
	public JButton switchButton;
	public String lightIdString;
	public String roomIdString;
	public String floorIdString;
	public JLabel lightId;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualSwitch(Switch switchComponent){
		
		iconImage=createImageIcon("/visual/icons/bulb40.png","Bulb icon");
		icon=new JLabel(iconImage);
		this.switchComponent=switchComponent;
		lightId=new JLabel();
		lightIdString=null;
		roomIdString=null;
		this.switchButton=new JButton("TurnOn");
		this.switchButton.setActionCommand("switch");
		this.switchButton.addActionListener(this);
		
		this.add(icon);
		this.add(lightId);
		this.add(switchButton);
	}
	
	public void setState(boolean state){
		if(state){
			switchButton.setText("TurnOff");
		}else{
			switchButton.setText("TurnOn");
		}
	}
	
	public void setLightId(String lightId){
		this.lightId.setText(lightId);
		lightIdString=lightId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightSwitch", lightIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightSwitch", lightIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightSwitch", lightIdString, this);
		}
	}
	
	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("switch".equals(e.getActionCommand())) {
	        JButton b=((JButton)e.getSource());
	        if(b.getText().equals("TurnOff")){
	        	b.setText("TurnOn");
	        	switchComponent.changeSwitchStatus(false);
	        }else{
	        	b.setText("TurnOff");
	        	switchComponent.changeSwitchStatus(true);
	        }
	    } 
	} 	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
