package visual.lights;
import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import lightManagement.*;

public class LightGUIPanel extends JPanel implements ChangeListener,ActionListener{
	
	//Variable to store a reference to the CaesarJ GUIComponent of the light of the panel 
	LightManagement.LightGUI guiComponent;
	String lightId;
	JLabel id;
	JSlider intensitySlider;
	JButton switchButton;
	JLabel intensity;
	JLabel intensityText;
	int intensityValue;
	boolean stateValue;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public String getLightId() {
		return lightId;
	}

	public void setLightId(String id) {
		this.lightId = id;
		this.id.setText(id);
	}

	public int getIntensity() {
		return intensityValue;
	}

	public void setIntensity(int intensity) {
		this.intensity.setText(Integer.toString(intensity));
		this.intensitySlider.setValue(intensity);
		this.intensityValue=intensity;
	}

	public boolean getState(){
		return stateValue;
	}
	
	public void setState(boolean state){
		stateValue=state;
		if(stateValue){
			switchButton.setText("TurnOFF");
		}else{
			switchButton.setText("TurnON");
		}
	}
	
	public LightGUIPanel(LightManagement.LightGUI guiComponent){
		super();
		this.guiComponent=guiComponent;
		this.intensityValue=0;
		this.stateValue=false;
	
		iconImage=createImageIcon("/visual/icons/bulb40.png","Bulb icon");
		icon=new JLabel(iconImage);
		
		this.id=new JLabel();
		
		this.intensitySlider=new JSlider();
		this.intensitySlider.setMaximum(100);
		this.intensitySlider.setPreferredSize(new Dimension(90, 16));
		this.intensitySlider.setValue(0);
		this.intensitySlider.addChangeListener(this);
		
		this.switchButton=new JButton("switch");
		this.switchButton.setActionCommand("switch");
		this.switchButton.addActionListener(this);
		this.switchButton.setText("TurnON");
		
		this.intensity = new JLabel();
		this.intensity.setText("00");
		this.intensity.setFont(new Font("Dialog", Font.BOLD, 10));
		this.intensityText = new JLabel();
		this.intensityText.setText("  Intensity:");
		this.intensityText.setFont(new Font("Dialog", Font.BOLD, 10));
		this.intensityText.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		this.add(icon);
		this.add(id);
		this.add(intensitySlider);
		this.add(intensityText);
		this.add(this.intensity);
		this.add(this.switchButton);
		
	}
	
	//----------------------EVENTS--------------------------------------------------
			
	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("switch".equals(e.getActionCommand())) {
	        JButton b=((JButton)e.getSource());
	        if(b.getText().equals("TurnOFF")){
	        	b.setText("TurnON");
	        	guiComponent.notifyLightStateChange(lightId,false);
	        }else{
	        	b.setText("TurnOFF");
	        	guiComponent.notifyLightStateChange(lightId,true);
	        }
	    } 
	} 	

	public void stateChanged(ChangeEvent e) {
		//Intensity slider moved
	    JSlider source = (JSlider)e.getSource();
	    intensity.setText(String.valueOf(source.getValue()));
	    guiComponent.notifyLightIntensityChange(lightId,source.getValue());
	}

	
	//Change the light intensity if it exists
	public void changeLightIntensity(String id, int value){
		if(this.lightId.equals(id)){
			setIntensity(value);
		}
	}
	
	public void changeLightState(String id, boolean state){
		if(this.lightId.equals(id)){
			setState(state);
		}
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}