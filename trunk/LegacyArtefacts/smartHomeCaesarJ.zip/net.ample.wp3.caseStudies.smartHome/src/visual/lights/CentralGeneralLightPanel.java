package visual.lights;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import lightManagement.*;

public class CentralGeneralLightPanel extends JPanel implements ActionListener{
		
	//Variable to store a reference to the CaesarJ GUIComponent that represent this visual class 
	LightManagement.CentralGUI guiComponent;
	JButton switchOnButton;
	JButton switchOffButton;
	JButton applyButton;
	JTextField intensityField;
	JLabel intensity;
		
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public CentralGeneralLightPanel(LightManagement.CentralGUI guiComponent){
		this.guiComponent=guiComponent;
		
		iconImage=createImageIcon("/visual/icons/bulbs40.png","Bulb icon");
		icon=new JLabel(iconImage);
		
		this.switchOnButton=new JButton("SwitchOnAll");
		this.switchOnButton.setText("SwitchOnAll");
		this.switchOnButton.setActionCommand("switchOn");
		this.switchOnButton.addActionListener(this);
		
		this.switchOffButton=new JButton("SwitchOffAll");
		this.switchOffButton.setText("SwitchOffAll");
		this.switchOffButton.setActionCommand("switchOff");
		this.switchOffButton.addActionListener(this);
		
		this.applyButton=new JButton("Apply");
		this.applyButton.setText("ApplyIntensity");
		this.applyButton.setActionCommand("apply");
		this.applyButton.addActionListener(this);
		
		this.intensity=new JLabel("Intensity:");
		this.intensityField=new JTextField();
		this.intensityField.setText("00");
		
		this.add(icon);
		this.add(switchOnButton);
		this.add(switchOffButton);
		this.add(intensity);
		this.add(intensityField);
		this.add(applyButton);
		
		
	}

	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("apply".equals(e.getActionCommand())) {
			try{
				int value=Integer.parseInt(intensityField.getText());
				if((0<=value)&&(value<=100)){
					guiComponent.changeAllLightsIntensity(value);
				}else{
					System.err.println("Error in CentralGeneralLightPanel: The entered intensity is not valid");
				}
			}catch(Exception ex){
				System.err.println("Exception in CentralGeneralLightPanel: "+ex.toString());
			}
	    } else if ("switchOn".equals(e.getActionCommand())) {
	    	guiComponent.switchOnAllLights();
	    } else if ("switchOff".equals(e.getActionCommand())) {
	    	guiComponent.switchOffAllLights();
	    } 
	} 	
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}