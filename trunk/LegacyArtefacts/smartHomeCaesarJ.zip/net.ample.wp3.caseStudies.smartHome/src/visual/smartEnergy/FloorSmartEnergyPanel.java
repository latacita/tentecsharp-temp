package visual.smartEnergy;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import smartEnergyControl.*;

public class FloorSmartEnergyPanel extends JPanel implements ActionListener{
		
	//Variable to store a reference to the CaesarJ GUIComponent that represent this visual class 
	SmartEnergyControl.FloorGUI guiComponent;
	JButton switchButton;
		
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public FloorSmartEnergyPanel(SmartEnergyControl.FloorGUI guiComponent){
		this.guiComponent=guiComponent;
		iconImage=createImageIcon("/visual/icons/energySaver40.png","Bulb icon");
		icon=new JLabel(iconImage);
		this.switchButton=new JButton("SwitchOnEnergySaver");
		this.switchButton.setText("SwitchOnEnergySaver");
		this.switchButton.setActionCommand("switch");
		this.switchButton.addActionListener(this);

		this.add(icon);
		this.add(switchButton);
	}

	public void switchOnEnergySaver(){
		switchButton.setText("SwitchOffEnergySaver");
	}
	
	public void switchOffEnergySaver(){
		switchButton.setText("SwitchOnEnergySaver");
	}
	
	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("switch".equals(e.getActionCommand())) {
			JButton aux=(JButton)e.getSource();
			if(aux.getText().equals("SwitchOnEnergySaver")){
				guiComponent.switchOnEnergySaver();
			}else{
				guiComponent.switchOffEnergySaver();
			}
	    } 
	} 	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}