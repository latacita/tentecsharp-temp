package visual.initial;

import javax.swing.*;
import javax.swing.event.*;


import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class CentralGUIPanel extends JPanel{

	JPanel namePanel;	//Panel that contains the name of the GUI
	JTabbedPane tabbedMenu; //Tabbed menu for the GUI
	JTabbedPane tabbedFloors; //Tabbed menu for floors
	JLabel guiName;	//Name of the GUI
	
	JPanel generalOptionsPanel; //Pannel with the general options or information of the GUI
	
	JLabel welcomeText;
	
	
	public CentralGUIPanel (String name){
		namePanel=new JPanel();	
		guiName=new JLabel(name);	//Name of the GUI
		namePanel.add(guiName);
		//Tabbed pannel test-------------------------
		generalOptionsPanel=new JPanel();
		//Add some text
		welcomeText=new JLabel("This panel contains the general controller that affects the whole house");
		generalOptionsPanel.add(welcomeText);
		
		tabbedMenu = new JTabbedPane();
		tabbedFloors = new JTabbedPane();
		
		//tabbedMenu.addTab("General",generalOptionsPanel);
		tabbedMenu.addTab("Floors",createImageIcon("/visual/icons/stairs20.png"),tabbedFloors);
		
		this.setLayout(new BorderLayout());
		
		this.add(tabbedMenu,BorderLayout.CENTER);	
	}
	
	//Method to retrieve the name of the pannel
	
	public String getNamePanel(){
		return this.guiName.getText();
	}
	
	//Method to add a new floorGUIPanel
	
	public void addFloorGUI(FloorGUIPanel newPanel){
		tabbedFloors.addTab(newPanel.getNamePanel(),createImageIcon("/visual/icons/stairs20.png"),newPanel);
	}
	
	//Method to add an panel item to the tabbedMenu
	public void addPanel(JPanel newPanel,String name){
		tabbedMenu.add(name,newPanel);
	}
	
	//Method to add an panel item to the tabbedMenu with an icon
	public void addPanel(JPanel newPanel,String name,String iconUrl){
		ImageIcon icon=createImageIcon(iconUrl);
		tabbedMenu.addTab(name, icon, newPanel);
	}
	
	//Method to add an tabbedMenu item to the tabbedMenu
	public void addTabbedPanel(JTabbedPane newPanel,String name){
		tabbedMenu.add(name,newPanel);
	}
	
	//Method to add an tabbedMenu item to the tabbedMenu with an icon
	public void addTabbedPanel(JTabbedPane newPanel,String name,String iconUrl){
		ImageIcon icon=createImageIcon(iconUrl);
		tabbedMenu.addTab(name,icon,newPanel);
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
