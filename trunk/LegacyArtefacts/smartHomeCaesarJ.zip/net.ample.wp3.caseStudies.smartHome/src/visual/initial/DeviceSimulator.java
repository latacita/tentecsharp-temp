package visual.initial;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class DeviceSimulator extends JFrame implements ListSelectionListener{

	protected ArrayList elements;
	
	protected JPanel upperPanel;
	protected JPanel lowerPanel;
	protected JList listFloors;
	protected JList listRooms;
	protected JList listTypes;
	protected JList listDevices;
	protected DefaultListModel listModelFloors;
	protected DefaultListModel listModelRooms;
	protected DefaultListModel listModelTypes;
	protected DefaultListModel listModelDevices;
	protected JLabel floor;
	protected JLabel room;
	protected JLabel deviceType;
	protected JLabel identifier;
	protected JPanel floorsPanel;
	protected JPanel roomsPanel;
	protected JPanel typesPanel;
	protected JPanel devicesPanel;
	
	public DeviceSimulator(String text){
		super(text);
		
		String hola;
		
		roomsPanel=new JPanel();
		floorsPanel=new JPanel();
		typesPanel=new JPanel();
		devicesPanel=new JPanel();
		
		floorsPanel.setLayout(new BoxLayout(floorsPanel, BoxLayout.PAGE_AXIS));
		roomsPanel.setLayout(new BoxLayout(roomsPanel, BoxLayout.PAGE_AXIS));
		typesPanel.setLayout(new BoxLayout(typesPanel, BoxLayout.PAGE_AXIS));
		devicesPanel.setLayout(new BoxLayout(devicesPanel, BoxLayout.PAGE_AXIS));
		
		floor=new JLabel("Floor");
		room=new JLabel("Room");
		deviceType=new JLabel("Device Type");
		identifier=new JLabel("Identifier");
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		java.net.URL imgURL = getClass().getResource("/visual/icons/house20.png");
		if(imgURL!=null){
			java.awt.Image icon = java.awt.Toolkit.getDefaultToolkit().getImage(imgURL);
    		this.setIconImage(icon);
		}else{
			System.err.println("Couldn't find file: /visual/icons/house20.png");
		}
		
		
		elements=new ArrayList();
		lowerPanel=new JPanel();
		lowerPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		lowerPanel.setPreferredSize(new Dimension(550,70));
		upperPanel=new JPanel();
		
		listModelFloors = new DefaultListModel();
		listModelRooms = new DefaultListModel();
		listModelTypes = new DefaultListModel();
		listModelDevices = new DefaultListModel();
		
		listFloors = new JList(listModelFloors);
		listFloors.setName("listFloors");
		listFloors.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listFloors.setSelectedIndex(0);
		listFloors.addListSelectionListener(this);
		listFloors.setVisibleRowCount(10);
	    JScrollPane listScrollPane1 = new JScrollPane(listFloors);
	    listScrollPane1.setPreferredSize(new Dimension(150,150));
		
		listRooms = new JList(listModelRooms);
		listRooms.setName("listRooms");
		listRooms.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listRooms.setSelectedIndex(0);
		listRooms.addListSelectionListener(this);
		listRooms.setVisibleRowCount(10);
	    JScrollPane listScrollPane2 = new JScrollPane(listRooms);
	    listScrollPane2.setPreferredSize(new Dimension(150,150));

	    listTypes = new JList(listModelTypes);
	    listTypes.setName("listTypes");
	    listTypes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    listTypes.setSelectedIndex(0);
	    listTypes.addListSelectionListener(this);
	    listTypes.setVisibleRowCount(10);
	    JScrollPane listScrollPane3 = new JScrollPane(listTypes);
	    listScrollPane3.setPreferredSize(new Dimension(150,150));
	    
	    listDevices = new JList(listModelDevices);
	    listDevices.setName("listDevices");
	    listDevices.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    listDevices.setSelectedIndex(0);
	    listDevices.addListSelectionListener(this);
	    listDevices.setVisibleRowCount(10);
	    JScrollPane listScrollPane4 = new JScrollPane(listDevices);
	    listScrollPane4.setPreferredSize(new Dimension(150,150));
		
	    floorsPanel.add(floor);
	    floorsPanel.add(listScrollPane1);
	    upperPanel.add(floorsPanel);
	    roomsPanel.add(room);
	    roomsPanel.add(listScrollPane2);
	    upperPanel.add(roomsPanel);
	    typesPanel.add(deviceType);
	    typesPanel.add(listScrollPane3);
	    upperPanel.add(typesPanel);
	    devicesPanel.add(identifier);
	    devicesPanel.add(listScrollPane4);
	    upperPanel.add(devicesPanel);
	    
	    this.getContentPane().add(upperPanel, BorderLayout.BEFORE_FIRST_LINE);
	    this.getContentPane().add(lowerPanel, BorderLayout.CENTER);
	    
	    this.pack();
	    this.setVisible(true);
	    
	}
	
	public void addDevice(String floor,String room, String type, String id, JPanel devicePanel){
		elements.add(new Element(floor,room,type,id,devicePanel));
		if(!(listModelFloors.contains(floor))){
			listModelFloors.addElement(floor);
		}
		this.validate();
	}
	
	public boolean contains(ArrayList list,String cad){
		for(int i=0;i<list.size();i++){
			if(((String)list.get(i)).equals(cad)){
				return true;
			}
		}
		return false;
	}
	
	//Method that creates a list with the rooms strings presented inside the floor
	public ArrayList createRoomsList(String floor){
		ArrayList result=new ArrayList();
		Element aux;
		for(int i=0;i<elements.size();i++){
			aux=((Element)elements.get(i));
			if(aux.getFloor().equals(floor)){
				if(!(contains(result,aux.getRoom()))){
					result.add(aux.getRoom());
				}
			}
		}
		return result;
	}
	
	//Method that creates a list with the element types strings presented inside a room
	public ArrayList createElementTypesList(String room){
		ArrayList result=new ArrayList();
		Element aux;
		for(int i=0;i<elements.size();i++){
			aux=((Element)elements.get(i));
			if(aux.getRoom().equals(room)){
				if(!(contains(result,aux.getType()))){
					result.add(aux.getType());
				}
			}
		}
		return result;
	}
	
	//Method that creates a list with the device strings presented inside a room with a concrete type
	public ArrayList createElementDeviceList(String room,String type){
		ArrayList result=new ArrayList();
		Element aux;
		for(int i=0;i<elements.size();i++){
			aux=((Element)elements.get(i));
			if((aux.getRoom().equals(room))&&(aux.getType().equals(type))){
				if(!(contains(result,aux.getId()))){
					result.add(aux.getId());
				}
			}
		}
		return result;
	}
	
	public JPanel getDevicePanel(String room,String type,String device){
		String roomAux;
		String typeAux;
		String deviceAux;
		for(int i=0;i<elements.size();i++){
			roomAux=((Element)elements.get(i)).getRoom();
			typeAux=((Element)elements.get(i)).getType();
			deviceAux=((Element)elements.get(i)).getId();
			if((roomAux.equals(room))&&(typeAux.equals(type))&&(deviceAux.equals(device))){
				return ((Element)elements.get(i)).getDevicePanel();
			}
		}
		return null;
	}
	
	public void valueChanged(ListSelectionEvent e) {
		if (e.getValueIsAdjusting() == false) {
			JList source=((JList)e.getSource());
			if (source.getName().equals("listFloors")){ //A new floor has been selected in the list
				int index=listFloors.getSelectedIndex();
	    		if (index != -1) {
	    			//Obtain the name of the selected room
	    			String floor=((String)listModelFloors.get(index));
	    			//Erase the rooms list
	    			listModelRooms.removeAllElements();
	    			//Erase the device list
	    			listModelDevices.removeAllElements();
	    			//Erase the type list
	    			listModelTypes.removeAllElements();
	    			//Erase the lower panel
	    			lowerPanel.removeAll();
	    			//Creating the list of rooms presented on that floor
	    			ArrayList rooms=createRoomsList(floor);
	    			for(int i=0;i<rooms.size();i++){
	    				listModelRooms.addElement(((String)rooms.get(i)));
	    			}
		        } 
			}else if(source.getName().equals("listRooms")){ //A new room has been selected in the list
	    		int index=listRooms.getSelectedIndex();
	    		if (index != -1) {
	    			//Obtain the name of the selected room
	    			String room=((String)listModelRooms.get(index));
	    			//Erase the device list
	    			listModelDevices.removeAllElements();
	    			//Erase the type list
	    			listModelTypes.removeAllElements();
	    			//Erase the lower panel
	    			lowerPanel.removeAll();
	    			//Creating the list of element types presented on that room
	    			ArrayList types=createElementTypesList(room);
	    			for(int i=0;i<types.size();i++){
	    				listModelTypes.addElement(((String)types.get(i)));
	    			}
		        } 
		    }else if(source.getName().equals("listTypes")){
	    		int indexRoom=listRooms.getSelectedIndex();
	    		int indexType=listTypes.getSelectedIndex();
	    		if ((indexRoom != -1)&&(indexType != -1)) {
	    			//Obtain the name of the selected room and type
	    			String room=((String)listModelRooms.get(indexRoom));
	    			String type=((String)listModelTypes.get(indexType));
	    			//Erase the device list
	    			listModelDevices.removeAllElements();
	    			//Erase the lower panel
	    			lowerPanel.removeAll();
	    			//Creating the list of devices types presented on that room and that type
	    			ArrayList devices=createElementDeviceList(room,type);
	    			for(int i=0;i<devices.size();i++){
	    				listModelDevices.addElement(devices.get(i));
	    			}
		        } 
		    }else if(source.getName().equals("listDevices")){
	    		int indexRoom=listRooms.getSelectedIndex();
	    		int indexType=listTypes.getSelectedIndex();
	    		int indexDevice=listDevices.getSelectedIndex();
	    		if (indexDevice != -1){
	    			//Obtain the name of the selected room and type and device
	    			String room=((String)listModelRooms.get(indexRoom));
	    			String type=((String)listModelTypes.get(indexType));
	    			String device=((String)listModelDevices.get(indexDevice));
	    			//Obtain the device panel
	    			JPanel panel=getDevicePanel(room,type,device);
	    			//Remove elements of the lower pannel
	    			//Erase the lower panel
	    			lowerPanel.removeAll();
	    			if(panel!=null){
	    				lowerPanel.add(panel);
	    			}
		        } 
		    }
	    }
		this.validate();
		this.repaint();
	}

	public class Element{
		
		protected String room;
		protected String type;
		protected String id;
		protected String floor;
		protected JPanel devicePanel;
		
		public Element(String floor,String room, String type, String id, JPanel devicePanel){
			this.floor=floor;
			this.room=room;
			this.type=type;
			this.id=id;
			this.devicePanel=devicePanel;
		}
		
		public String getFloor() {
			return floor;
		}
		public void setFloor(String floor) {
			this.floor = floor;
		}
		public String getRoom() {
			return room;
		}
		public void setRoom(String room) {
			this.room = room;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public JPanel getDevicePanel() {
			return devicePanel;
		}
		public void setDevicePanel(JPanel devicePanel) {
			this.devicePanel = devicePanel;
		}
	}
}