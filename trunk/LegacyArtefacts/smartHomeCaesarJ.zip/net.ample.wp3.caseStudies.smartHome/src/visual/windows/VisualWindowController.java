package visual.windows;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import windowManagement.WindowManagement.WindowController;

//Very simple visual class that simulates a WindowController
public class VisualWindowController extends JPanel{
	public JFrame frame;
	public JLabel apertureText;
	public JLabel aperture;
	public JPanel panel;
	
	public String windowIdString;
	public String roomIdString;
	public JLabel windowId;
	public String floorIdString;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualWindowController(){
		iconImage=createImageIcon("/visual/icons/window40.png","Bulb icon");
		icon=new JLabel(iconImage);
		windowId=new JLabel();
		roomIdString=null;
		windowIdString=null;
		apertureText=new JLabel ("Aperture: ");
		aperture=new JLabel("00");
		this.add(icon);
		this.add(windowId);
		this.add(apertureText);
		this.add(aperture);
		
	}
	
	public void setWindowId(String windowId){
		this.windowId.setText(windowId);
		windowIdString=windowId;
		if((windowIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "WindowController", windowIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((windowIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "WindowController", windowIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((windowIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "WindowController", windowIdString, this);
		}
	}
	
	public void setAperture(int value){
		this.aperture.setText(Integer.toString(value));
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
