package visual.windows;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import windowManagement.WindowManagement.BlindController;

//Very simple visual class that simulates a WindowController
public class VisualBlindController extends JPanel {
	
	public JLabel apertureText;
	public JLabel aperture;
	public JPanel panel;
	public String blindIdString;
	public String roomIdString;
	public String floorIdString;
	public JLabel blindId;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualBlindController(){
		blindId=new JLabel();
		iconImage=createImageIcon("/visual/icons/blind40.png","Bulb icon");
		icon=new JLabel(iconImage);
		blindIdString=null;
		roomIdString=null;
		apertureText=new JLabel ("Aperture: ");
		aperture=new JLabel("00");
		this.add(icon);
		this.add(blindId);
		this.add(apertureText);
		this.add(aperture);
	}
	
	public void setBlindId(String blindId){
		this.blindId.setText(blindId);
		blindIdString=blindId;
		if((blindIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "BlindController", blindIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((blindIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "BlindController", blindIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((blindIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "BlindController", blindIdString, this);
		}
	}
	
	public void setAperture(int value){
		this.aperture.setText(Integer.toString(value));
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}

