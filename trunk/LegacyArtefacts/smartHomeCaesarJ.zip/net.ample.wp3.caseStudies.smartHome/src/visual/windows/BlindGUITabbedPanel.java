package visual.windows;
import javax.swing.*;

public class BlindGUITabbedPanel extends JTabbedPane {

	public BlindGUITabbedPanel(){
		super();
	}
	
	public void addBlindGUIPanel(String name,BlindGUIPanel newPanel){
		this.addTab(name,createImageIcon("/visual/icons/blind20.png"),newPanel);
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
