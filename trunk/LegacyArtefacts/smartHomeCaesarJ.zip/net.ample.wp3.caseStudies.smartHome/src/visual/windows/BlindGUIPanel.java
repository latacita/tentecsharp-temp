package visual.windows;
import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import windowManagement.*;

public class BlindGUIPanel extends JPanel implements ChangeListener{
	
	//Variable to store a reference to the CaesarJ GUIComponent of the light of the panel 
	WindowManagement.BlindGUI guiComponent;
	String blindId;
	JLabel id;
	JSlider apertureSlider;
	JLabel aperture;
	JLabel apertureText;
	int apertureValue;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public String getBlindId() {
		return blindId;
	}

	public void setBlindId(String id) {
		this.blindId = id;
	}

	public int getAperture() {
		return apertureValue;
	}

	public void setAperture(int aperture) {
		this.aperture.setText(Integer.toString(aperture));
		this.apertureSlider.setValue(aperture);
		this.apertureValue=aperture;
	}
	
	public BlindGUIPanel(WindowManagement.BlindGUI guiComponent){
		super();
		this.id=new JLabel();
		this.guiComponent=guiComponent;
		this.apertureValue=0;
		iconImage=createImageIcon("/visual/icons/blind40.png","Bulb icon");
		icon=new JLabel(iconImage);
		this.apertureSlider=new JSlider();
		this.apertureSlider.setMaximum(100);
		this.apertureSlider.setPreferredSize(new Dimension(90, 16));
		this.apertureSlider.setValue(0);
		this.apertureSlider.addChangeListener(this);
		
		this.aperture = new JLabel();
		this.aperture.setText("00");
		this.aperture.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText = new JLabel();
		this.apertureText.setText("  Aperture:");
		this.apertureText.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		this.add(icon);
		this.add(id);
		this.add(apertureSlider);
		this.add(apertureText);
		this.add(this.aperture);	
	}
	
	//----------------------EVENTS--------------------------------------------------

	public void stateChanged(ChangeEvent e) {
		//Intensity slider moved
	    JSlider source = (JSlider)e.getSource();
	    aperture.setText(String.valueOf(source.getValue()));
	    guiComponent.notifyBlindApertureChange(blindId,source.getValue());
	}
	
	
	
	//---------------------------------------------------------------------
	//Methods used by the GUI components----------------------------------
	//---------------------------------------------------------------------
	
	
	//Change the blind aperture if it exists
	public void changeBlindAperture(String id, int value){
		if(blindId.equals(id)){
			setAperture(value);
		}
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
	
}