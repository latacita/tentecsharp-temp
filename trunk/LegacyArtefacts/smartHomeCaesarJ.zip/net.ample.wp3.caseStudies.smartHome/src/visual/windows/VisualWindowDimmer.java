package visual.windows;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import windowManagement.WindowManagement.WindowDimmer;

//Auxiliar class to show the dimmer in the Screen

public class VisualWindowDimmer extends JPanel implements ChangeListener{
	
	//Reference to the Dimmer component in which it is contained
	public WindowDimmer dimmer;
	//Required swing visual elements
	public JLabel apertureText;
	public JLabel aperture;
	public JSlider apertureSlider;
	
	public String windowIdString;
	public String roomIdString;
	public String floorIdString;
	public JLabel windowId;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualWindowDimmer(WindowDimmer dimmer){
		this.dimmer=dimmer;
		iconImage=createImageIcon("/visual/icons/window40.png","Bulb icon");
		icon=new JLabel(iconImage);
		windowId=new JLabel();
		roomIdString=null;
		windowIdString=null;
		
		this.apertureSlider=new JSlider();
		this.apertureSlider.setMaximum(100);
		this.apertureSlider.setPreferredSize(new Dimension(90, 16));
		this.apertureSlider.setValue(0);
		this.apertureSlider.addChangeListener(this);
		
		this.aperture = new JLabel();
		this.aperture.setText("0");
		this.aperture.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText = new JLabel();
		this.apertureText.setText("  Aperture:");
		this.apertureText.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		this.add(icon);
		this.add(windowId);
		this.add(apertureText);
		this.add(aperture);
		this.add(apertureSlider);
	}
	
	public void setAperture(int aperture){
		this.aperture.setText(Integer.toString(aperture));
		this.apertureSlider.setValue(aperture);
	}
	
	public void setWindowId(String windowId){
		this.windowId.setText(windowId);
		windowIdString=windowId;
		if((windowIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "WindowDimmer", windowIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((windowIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "WindowDimmer", windowIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((windowIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "WindowDimmer", windowIdString, this);
		}
	}
	
	public void stateChanged(ChangeEvent e) {	
		//Intensity slider moved
	    JSlider source = (JSlider)e.getSource();
	    aperture.setText(String.valueOf(source.getValue()));
	    dimmer.changeDimmerValue(source.getValue());
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}