cclass baseModel.BaseModel;

import java.util.*;

/**
 * Parent class for the enum types in order to been able to merge them.
 * This class is not generated based in the UML model.
 * The class is type safe so if there is an error in the given values it is set to -1
 * and an exception is arised
 * 
 * @author Carlos Nebrera Cuevas
 *
 */
public abstract cclass TypeEnum {
	
	/**
	 * String list with all the possible values of the enum type
	 */
	public ArrayList values;

    /**
     * Position in the array of the actual value of the enum type, -1 means there is no given value yet
     */
	public int value=-1;
	
	/**
	 * Basic constructor in which only the array of values is instantiated
	 */
	public TypeEnum(){
		values=new ArrayList();
	}
	
	public TypeEnum(String literalValue){
		super();
		int pos=0;
		boolean found=false;
		while (pos<values.size()&&(!found)){
			if(((String)values.get(pos)).equals(literalValue)){
				found=true;
			}else{
				pos++;
			}
		}
		if (found) {
			this.value=pos;
		}else {
			System.err.println("Enumeration problem: The enum type doesn't contain the given String value");
		}
	}
	
	/**
	 * Gives the position in the array of the enum type value, if the value is -1 it means
	 * there is no given value for the enum type and an exception will be arised
	 * 
	 * @return position in the array of the enum type value
	 */
    public int getValue(){
    	if(value==-1){
    		System.err.println("Enumeration problem: Enum type has no value");
    	}
		return value;
	}
    
    /**
     * Returns the String that represent the given value, if it's out of bounds
     * it throws an exception
     * 
     * @param val the position in the array for the value to be retrieven
     * @return the String value of the possition given
     */
    public String getStringValue(int val){
    	if((0<values.size())&&(values.size()<val)){
    		return ((String)(values.get(val)));
    	}else{
    		System.err.println("Enumeration problem: The given possition if out of range of the enum type");
    		return null;
    	}
    }
    
    /**
     * Returns the String that represent the actual value, if it's out of bounds
     * it throws an exception
     * 
     * @return the actual String value
     */
    public String getStringValue(){
    	if(value==-1){
    		System.err.println("Enumeration problem: The enum type has no valid defined value");
    		return null;
    	}else{
    		return ((String)(values.get(value)));
    	}
    }
    
    /**
     * Retrieve the number of possible values of the enum type
     * @return size of the list of values
     */
    public int getSize(){
    	return values.size();
    }
    
    /**
     * Set the value for the enum type by giving the possition in the array, if it is not valid
     * it set the value to -1 and throws an exception
     * @param value position of the value in the array
     */
	public void setValue(int value){
		if((0<=value)&&(value<values.size())){
			this.value = value;
		}else{
			System.err.println("Enumeration problem: The given value is out of range");
		}
	}
	
	/**
	 * Set the value of the enum type by giving the String that represents the value, 
	 * if the String doesn�t exists the value is not changed and an exception is thrown
	 * 
	 * @param value String value for the enum type
	 */
	public void setValue(String value){
		int pos=0;
		boolean found=false;
		while (pos<values.size()&&(!found)){
			if(((String)values.get(pos)).equals(value)){
				found=true;
			}else{
				pos++;
			}
		}
		if (found) {
			this.value=pos;
		}else {
			System.err.println("Enumeration problem: The enum type doesn't contain the given String value");
		}
	}
}

