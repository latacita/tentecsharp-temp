package baseModel;

import java.util.ArrayList;

public cclass BaseModel {
	public BaseModel(){
		
	}
}
