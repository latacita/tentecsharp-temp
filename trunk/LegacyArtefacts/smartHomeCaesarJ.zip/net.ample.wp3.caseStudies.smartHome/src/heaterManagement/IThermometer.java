package heaterManagement;

public interface IThermometer {
	public float getTemperature(String thermometerId);
	public float getOutDoorTemperature(String thermometerId);
}
