cclass heaterManagement.HeaterManagement;

//As it happens with LightGUI, each instance of HeaterGUI is able to control several heaters
public cclass ThermometerGUI extends TypeComponent{

	public RequestPort request;
	public ThermometerGUIPanel visualGUI;
	public String thermometerId;
	public String roomId;
	public String floorId;
	
	public ThermometerGUI(String id){
		super(id);
		request=new RequestPort();
		visualGUI=new ThermometerGUIPanel(this);
	}
	
	public void setThermometerId(String value){
		this.thermometerId=value;
		visualGUI.setThermometerId(value);
	}
	
	public String getThermometerId(){
		return this.thermometerId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public ThermometerGUIPanel getVisualGUI(){
		return visualGUI;
	}
	
	public RequestPort getRequest(){
		return this.request;
	}
	
	public void newTemperature(String thermometerId,float temp){
		visualGUI.changeThermometerTemp(thermometerId,""+temp);
	}
	
	public void newOutsideTemperature(String thermometerId,float temp){
		visualGUI.changeThermometerOutsideTemp(thermometerId,""+temp);
	}
	
	public cclass RequestPort extends TypePort implements IThermometerGUINotify{
		
		public RequestPort(){
			super();
		}
		
		public void newTemperature(String thermometerId,float temp){
			ThermometerGUI.this.newTemperature(thermometerId,temp);
		}
		public void newOutsideTemperature(String thermometerId,float temp){
			ThermometerGUI.this.newOutsideTemperature(thermometerId,temp);
		}	
	}
}
