package heaterManagement;

public interface IHeaterGUINotify {
	public void heaterTemperatureChanged(String heaterId,float newTemp);
	public void heaterSwitchChanged(String heaterId,boolean on);	
}
