cclass heaterManagement.HeaterManagement;

//As it happens with LightGUI, each instance of HeaterGUI is able to control several heaters
public cclass HeaterGUI extends TypeComponent{

	public RequestPort request;
	public ServicesPort services;
	public HeaterGUIPanel visualGUI;
	
	public String heaterId;
	public String roomId;
	public String floorId;
	
	public HeaterGUI(String id){
		super(id);
		request=new RequestPort();
		services=new ServicesPort();
		visualGUI=new HeaterGUIPanel(this);
	}
	
	public HeaterGUIPanel getVisualGUI(){
		return visualGUI;
	}
	
	public void setHeaterId(String value){
		this.heaterId=value;
		visualGUI.setHeaterId(value);
	}
	
	public String getHeaterId(){
		return this.heaterId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public RequestPort getRequest(){
		return request;
	}
	
	public ServicesPort getServices(){
		return services;
	}
	
	public void heaterTemperatureChanged(String heaterId,float temp){
		ArrayList ports=services.getPortsIHeaterGUINotify();
		IHeaterGUINotify port;
		for(int i=0;i<ports.size();i++){
			port=((IHeaterGUINotify)ports.get(i));
			port.heaterTemperatureChanged(heaterId,temp);
		}
	}
	
	public void heaterSwitchChanged(String heaterId,boolean state){
		ArrayList ports=services.getPortsIHeaterGUINotify();
		IHeaterGUINotify port;
		for(int i=0;i<ports.size();i++){
			port=((IHeaterGUINotify)ports.get(i));
			port.heaterSwitchChanged(heaterId,state);
		}
	}
	
	public void setTemperature(String heaterId,float temp){
		visualGUI.changeHeaterTemperature(heaterId,""+temp);
	}
	
	public void setPower(String heaterId,int amount) {
		visualGUI.changeHeaterPower(heaterId,""+amount);
	}
	
	public void setMode(String heaterId,HeatingModes mode){
		visualGUI.changeHeaterMode(heaterId,mode.getStringValue());
	}
	
	public void heatingSwitch(String heaterId,boolean on){
		if(on){
			visualGUI.changeHeaterState(heaterId,"On");
		}else{
			visualGUI.changeHeaterState(heaterId,"Off");
		}
	}
	
	public cclass RequestPort extends TypePort implements IHeating{
		
		public RequestPort(){
			super();
		}
		
		public void setPower(String heaterId,int amount) {
			HeaterGUI.this.setPower(heaterId,amount);
		}
		
		public void setMode(String heaterId,HeatingModes mode){
			HeaterGUI.this.setMode(heaterId,mode);
		}
		
		public void heatingSwitch(String heaterId,boolean on){
			HeaterGUI.this.heatingSwitch(heaterId,on);
		}
		
		public void setTemperature(String heaterId,float temp){
			HeaterGUI.this.setTemperature(heaterId,temp);
		}
		
	}
	
	public cclass ServicesPort extends TypePort{
		
		protected ArrayList portsIHeaterGUINotify;
		
		public ServicesPort(){
			super();
			portsIHeaterGUINotify=new ArrayList();
		}
		
		public void connectPort(IHeaterGUINotify port){
			portsIHeaterGUINotify.add(port);
        } 
		
		public ArrayList getPortsIHeaterGUINotify(){
			return portsIHeaterGUINotify;
		}
	}
}