cclass heaterManagement.HeaterManagement;

public cclass FloorGUI{

	public HeaterNotifyPort heaterNotifyPort;
	public FloorGeneralHeaterPanel generalHeaterPanel;
	
	public FloorGUI(String id){
		super(id);
		heaterNotifyPort=new HeaterNotifyPort();
		generalHeaterPanel=new FloorGeneralHeaterPanel(this);
		visualGUI.addPanel(generalHeaterPanel,"HeatingControl","/visual/icons/heating20.png");
	}
	
	public HeaterNotifyPort getHeaterNotifyPort(){
		return heaterNotifyPort;
	}
	
	public cclass HeaterNotifyPort extends TypePort{
		public ArrayList portsIGeneralHeaterNotify;
		
		public HeaterNotifyPort(){
			super();
			portsIGeneralHeaterNotify=new ArrayList();
		}
		
		public void connectPort(IGeneralHeaterNotify port){
			portsIGeneralHeaterNotify.add(port);
		}	
		
		public ArrayList getPortsIGeneralHeaterNotify(){
	    	return portsIGeneralHeaterNotify;
	    }
	}
	
	//Methods used by the visual GUI to notify to FloorGUI
	
	public void changeAllHeatersTemperature(float value){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).changeAllHeatersTemp(floorId,null,value);
		}
	}
	
	public void switchOnAllHeaters(){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).switchOnAllHeaters(floorId,null);
		}
	}
	
	public void switchOffAllHeaters(){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).switchOffAllHeaters(floorId,null);
		}
	}
}

