package heaterManagement;

public interface IGeneralHeaterNotify {
	public void switchOnAllHeaters(String floorId,String roomId);
	public void switchOffAllHeaters(String floorId,String roomId);
	public void changeAllHeatersTemp(String floorId, String roomId,float temp);
}
