cclass heaterManagement.HeaterManagement;

public cclass HouseGateway extends TypeComponent {

	public HouseGateway(String id){
		super(id);
	}
	
	//A thermometer has notify about a change in the temperature
	public void insideTempChanged(String thermometerId,float value){
		//First step is to do the modifications in the data structure
		houseData.getThermometerById(thermometerId).setTemp(value);
		
		//Second step is to check which heaters are connected to that thermometer and in case the heaters
		//are on, modify the power and the information on the heater if it is necessary
		
		ArrayList heaters=houseData.getAllHeaters();
		Heater heaterAux;
		HeatingModes mode=new HeatingModes();
		for(int i=0;i<heaters.size();i++){
			heaterAux=((Heater)heaters.get(i));
			if((heaterAux.getThermometerId().equals(thermometerId))&&(heaterAux.getState())){ 
				//Heater is connected to the thermometer and it is switched on
				//Now check what is the temperature difference
				float difference=value-heaterAux.getTemperature();
				if(difference>0.0f){//The internal temperature is bigger, the heater has to be set in cooling mode 
					mode.setValue("Cooling");
					heaterAux.setMode(mode);
					//Now the power of the heater has to change depending of the temperature difference
					if(difference>10.0f){
						heaterAux.setPower(100);
					}else{
						heaterAux.setPower(((int)(difference*10.0f)));
					}
					
				}else if(difference<0.0f){//Internal temperature lesser, the heater should be set in heating mode
					mode.setValue("Heating");
					heaterAux.setMode(mode);
					//Now the power of the heater has to change depending of the temperature difference
					if(difference<-10.0f){
						heaterAux.setPower(100);
					}else{
						heaterAux.setPower(((int)(difference*-10.0f)));
					}
					
				}else{//Other case, the temperature is the same, the power should be set to 0
					heaterAux.setPower(0);
				}
				
				//Now it is necessary to modify the information of the HeatingController component and HeaterGUI
				ArrayList ports=getActuators().getPortsIHeating();
				for(int j=0;j<ports.size();j++){
					((IHeating)ports.get(j)).setPower(heaterAux.getHeaterId(),heaterAux.getPower());
					((IHeating)ports.get(j)).setMode(heaterAux.getHeaterId(),heaterAux.getMode());
				}
			}
		}
		
		//Third step is to notify the GUI about the change
		ArrayList ports=this.getActuators().getPortsIThermometerGUINotify();
		for(int i=0;i<ports.size();i++){
			((IThermometerGUINotify)ports.get(i)).newTemperature(thermometerId,value);
		}
	}
	
	//A thermometer has notify about a change in the outside temperature
	public void outsideTempChanged(String thermometerId,float value){
		//First step is to do the modifications in the data structure
		houseData.getThermometerById(thermometerId).setOutTemp(value);
		
		//The heaters are not modified if the outside temperature changed
		
		//Third step is to notify the GUI about the change
		ArrayList ports=this.getActuators().getPortsIThermometerGUINotify();
		for(int i=0;i<ports.size();i++){
			((IThermometerGUINotify)ports.get(i)).newOutsideTemperature(thermometerId,value);
		}
	}
	
	public void heaterTemperatureChanged(String heaterId,float newTemp){
		//First step is to do the modifications in the data structure
		Heater heaterAux=houseData.getHeaterById(heaterId);
		heaterAux.setTemperature(newTemp);
		
		HeatingModes mode=new HeatingModes();
		
		//Second step is to recalculate the new state of the heater if it is switched on
		//Then the heater controller and the GUI have to be modified with the new values
		if(heaterAux.getState()==true){
			float insideTemp=houseData.getThermometerById(heaterAux.getThermometerId()).getTemp();
			float difference=insideTemp-heaterAux.getTemperature();
			if(difference>0.0f){//The internal temperature is bigger, the heater has to be set in cooling mode 
				mode.setValue("Cooling");
				heaterAux.setMode(mode);
				//Now the power of the heater has to change depending of the temperature difference
				if(difference>10.0f){
					heaterAux.setPower(100);
				}else{
					heaterAux.setPower(((int)(difference*10.0f)));
				}
				
			}else if(difference<0.0f){//Internal temperature lesser, the heater should be set in heating mode
				mode.setValue("Heating");
				heaterAux.setMode(mode);
				//Now the power of the heater has to change depending of the temperature difference
				if(difference<-10.0f){
					heaterAux.setPower(100);
				}else{
					heaterAux.setPower(((int)(difference*-10.0f)));
				}
				
			}else{//Other case, the temperature is the same, the power should be set to 0
				heaterAux.setPower(0);
			}
			
			//Now it is necessary to modify the information of the HeatingController component and HeaterGUI
			ArrayList ports=getActuators().getPortsIHeating();
			for(int j=0;j<ports.size();j++){
				((IHeating)ports.get(j)).setPower(heaterAux.getHeaterId(),heaterAux.getPower());
				((IHeating)ports.get(j)).setMode(heaterAux.getHeaterId(),heaterAux.getMode());
			}
		}
		//Now it is necessary to modify the temperature information in the HeaterGUI
		ArrayList ports=getActuators().getPortsIHeating();
		for(int j=0;j<ports.size();j++){
			((IHeating)ports.get(j)).setTemperature(heaterAux.getHeaterId(),newTemp);
		}
	}
	
	public void heaterSwitchChanged(String heaterId,boolean on){
		//First step is to do the modifications in the data structure
		Heater heaterAux=houseData.getHeaterById(heaterId);
		heaterAux.setState(on);
		
		HeatingModes mode=new HeatingModes();
		//Second step is to recalculate the new state of the heater if it has switched on
		//Then the heater controller and the GUI have to be modified with the new values
		if(on==true){
			float insideTemp=houseData.getThermometerById(heaterAux.getThermometerId()).getTemp();
			float difference=insideTemp-heaterAux.getTemperature();
			if(difference>0.0f){//The internal temperature is bigger, the heater has to be set in cooling mode 
				mode.setValue("Cooling");
				heaterAux.setMode(mode);
				//Now the power of the heater has to change depending of the temperature difference
				if(difference>10.0f){
					heaterAux.setPower(100);
				}else{
					heaterAux.setPower(((int)(difference*10.0f)));
				}
				
			}else if(difference<0.0f){//Internal temperature lesser, the heater should be set in heating mode
				mode.setValue("Heating");
				heaterAux.setMode(mode);
				//Now the power of the heater has to change depending of the temperature difference
				if(difference<-10.0f){
					heaterAux.setPower(100);
				}else{
					heaterAux.setPower(((int)(difference*-10.0f)));
				}
				
			}else{//Other case, the temperature is the same, the power should be set to 0
				heaterAux.setPower(0);
			}
			
			//Now it is necessary to modify the information of the HeatingController component and HeaterGUI
			ArrayList ports=getActuators().getPortsIHeating();
			for(int j=0;j<ports.size();j++){
				((IHeating)ports.get(j)).setPower(heaterAux.getHeaterId(),heaterAux.getPower());
				((IHeating)ports.get(j)).setMode(heaterAux.getHeaterId(),heaterAux.getMode());
				((IHeating)ports.get(j)).heatingSwitch(heaterAux.getHeaterId(),heaterAux.getState());
			}
		}else{
			ArrayList ports=getActuators().getPortsIHeating();
			for(int j=0;j<ports.size();j++){
				((IHeating)ports.get(j)).heatingSwitch(heaterAux.getHeaterId(),heaterAux.getState());
			}
		}
	}
	
	public void switchOnAllHeaters(String floorId,String roomId){
		ArrayList heaters=new ArrayList();
		Heater heaterAux;
		if((floorId==null)&&(roomId==null)){
			heaters=houseData.getAllHeaters();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				heaters=floorAux.getAllHeaters();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				heaters=roomAux.getHeaters();
			}
		}
		for(int i=0;i<heaters.size();i++){
			heaterAux=((Heater)heaters.get(i));
			heaterSwitchChanged(heaterAux.getHeaterId(),true);
		}
		
		
	}
	
	public void switchOffAllHeaters(String floorId,String roomId){
		ArrayList heaters=new ArrayList();
		Heater heaterAux;
		if((floorId==null)&&(roomId==null)){
			heaters=houseData.getAllHeaters();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				heaters=floorAux.getAllHeaters();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				heaters=roomAux.getHeaters();
			}
		}
		for(int i=0;i<heaters.size();i++){
			heaterAux=((Heater)heaters.get(i));
			heaterSwitchChanged(heaterAux.getHeaterId(),false);
		}
	}
	
	public void changeAllHeatersTemp(String floorId, String roomId,float temp){
		ArrayList heaters=new ArrayList();
		Heater heaterAux;
		if((floorId==null)&&(roomId==null)){
			heaters=houseData.getAllHeaters();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				heaters=floorAux.getAllHeaters();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				heaters=roomAux.getHeaters();
			}
		}
		for(int i=0;i<heaters.size();i++){
			heaterAux=((Heater)heaters.get(i));
			heaterTemperatureChanged(heaterAux.getHeaterId(),temp);
		}
	}
	
	//Method used to search for a heater inside the structure of the house
    //Returns null if there is no heater with the given id in the structure
    public Heater searchHeater(String id){
    	return houseData.getHeaterById(id);
    }
    
    //Method used to search for a thermometer inside the structure of the house
    //Returns null if there is no thermometer with the given id in the structure
    public Thermometer searchThermometer(String id){
    	return houseData.getThermometerById(id);
    }
	
	public cclass ServicesPort extends TypePort implements IHeaterGUINotify {
		
		public ServicesPort(){
			
		}
		
		public void heaterTemperatureChanged(String heaterId,float newTemp){
			HouseGateway.this.heaterTemperatureChanged(heaterId, newTemp);
		}
		
		public void heaterSwitchChanged(String heaterId,boolean on){
			HouseGateway.this.heaterSwitchChanged(heaterId, on);
		}
		
	}
	
	public cclass SensorPort extends TypePort implements IThermometerNotify{
	 	
    	public SensorPort(){
    		super();
    	}
	
    	public void newTemperature(String thermometerId, float value){
    		HouseGateway.this.insideTempChanged(thermometerId,value);
    	}
    	
    	public void newOutsideTemp(String thermometerId, float value){
    		HouseGateway.this.outsideTempChanged(thermometerId,value);
    	}
    	
    }
	
	public cclass ActuatorPort extends TypePort implements IGeneralHeaterNotify{
		protected ArrayList portsIHeating;
		protected ArrayList portsIThermometerGUINotify;
		protected ArrayList portsIThermometer;
		
        public ActuatorPort (){
        	super();
        	portsIHeating=new ArrayList();
            portsIThermometerGUINotify=new ArrayList();
            portsIThermometer=new ArrayList();
        }
              
        public ArrayList getPortsIHeating(){
        	return portsIHeating;
        }
        
        public ArrayList getPortsIThermometerGUINotify(){
        	return portsIThermometerGUINotify;
        }
        
        public ArrayList getPortsIThermometer(){
        	return portsIThermometer;
        }
        
        public void connectPort(IHeating port){
            portsIHeating.add(port);
        }   
        
        public void connectPort(IThermometerGUINotify port){
        	portsIThermometerGUINotify.add(port);
        }   
        
        public void connectPort(IThermometer port){
            portsIThermometer.add(port);
        }  
        
        public void switchOnAllHeaters(String floorId,String roomId){
        	HouseGateway.this.switchOnAllHeaters(floorId,roomId);
        }
        
    	public void switchOffAllHeaters(String floorId,String roomId){
    	 	HouseGateway.this.switchOffAllHeaters(floorId,roomId);
    	}
    	
    	public void changeAllHeatersTemp(String floorId, String roomId,float temp){
    		HouseGateway.this.changeAllHeatersTemp(floorId,roomId,temp);
    	}
        
	}
	
	public cclass House {
    	
    	public House(){
    		super();
    	}
    	
    	//Search for a heater by the giving id, returns null if not found
    	public Heater getHeaterById(String id){
    		int i=0;
    		Heater heaterAux=null;
    		Floor floorAux;
    		while (i<floors.size()){
    			floorAux=((Floor)floors.get(i));
    			heaterAux=floorAux.getHeaterById(id);
    			i++;
    			if (heaterAux!=null){
    				return heaterAux;
    			}
    		}
    		return null;
    	}
    	
    	//Search for a thermometer by the giving id, returns null if not found
    	public Thermometer getThermometerById(String id){
    		int i=0;
    		Thermometer thermometerAux=null;
    		Floor floorAux;
    		while (i<floors.size()){
    			floorAux=((Floor)floors.get(i));
    			thermometerAux=floorAux.getThermometerById(id);
    			i++;
    			if (thermometerAux!=null){
    				return thermometerAux;
    			}
    		}
    		return null;
    	}
    	
    	//Method that returns a list with all the heaters inside the house structure
    	public ArrayList getAllHeaters(){
    		ArrayList result=new ArrayList();
    		Floor floorAux;
    		ArrayList rooms;
    		Room roomAux;
    		ArrayList heaters;
    		
    		for(int i=0;i<floors.size();i++){
    			floorAux=((Floor)floors.get(i));
    			rooms=floorAux.getRooms();
    			for(int j=0;j<rooms.size();j++){
    				roomAux=((Room)rooms.get(j));
    				heaters=roomAux.getHeaters();
    				for(int k=0;k<heaters.size();k++){
    					result.add(heaters.get(k));
    				}
    			}
    		}
    		return result;
    	}
    	
    	//Method that returns a list with all the thermometers inside the house structure
    	public ArrayList getAllThermometers(){
    		ArrayList result=new ArrayList();
    		Floor floorAux;
    		ArrayList rooms;
    		Room roomAux;
    		ArrayList thermometers;
    		
    		for(int i=0;i<floors.size();i++){
    			floorAux=((Floor)floors.get(i));
    			rooms=floorAux.getRooms();
    			for(int j=0;j<rooms.size();j++){
    				roomAux=((Room)rooms.get(j));
    				thermometers=roomAux.getThermometers();
    				for(int k=0;k<thermometers.size();k++){
    					result.add(thermometers.get(k));
    				}
    			}
    		}
    		return result;
    	}
    }

    public cclass Floor {
        
        public Floor(){
        	super();
        }
               
        //Search for a heater by the giving id, returns null if not found
    	public Heater getHeaterById(String id){
    		int i=0;
    		Heater heaterAux=null;
    		Room roomAux;
    		while (i<rooms.size()){
    			roomAux=((Room)rooms.get(i));
    			heaterAux=roomAux.getHeaterById(id);
    			i++;
    			if (heaterAux!=null){
    				return heaterAux;
    			}
    		}
    		return null;
    	}
    	
    	//Search for a heater by the giving id, returns null if not found
    	public Thermometer getThermometerById(String id){
    		int i=0;
    		Thermometer thermometerAux=null;
    		Room roomAux;
    		while (i<rooms.size()){
    			roomAux=((Room)rooms.get(i));
    			thermometerAux=roomAux.getThermometerById(id);
    			i++;
    			if (thermometerAux!=null){
    				return thermometerAux;
    			}
    		}
    		return null;
    	}
    	
    	//Method that returns a list with all the heaters inside the floor structure
    	public ArrayList getAllHeaters(){
    		ArrayList result=new ArrayList();
    		Room roomAux;
    		ArrayList heaters;
    		
    		for(int i=0;i<rooms.size();i++){
    			roomAux=((Room)rooms.get(i));
    			heaters=roomAux.getHeaters();
    			for(int k=0;k<heaters.size();k++){
    				result.add(heaters.get(k));
    			}
    		}
    		return result;
    	}
    	
    	//Method that returns a list with all the thermometers inside the floor structure
    	public ArrayList getAllThermometers(){
    		ArrayList result=new ArrayList();
    		Room roomAux;
    		ArrayList thermometers;
    		
    		for(int i=0;i<rooms.size();i++){
    			roomAux=((Room)rooms.get(i));
    			thermometers=roomAux.getThermometers();
    			for(int k=0;k<thermometers.size();k++){
    				result.add(thermometers.get(k));
    			}
    		}
    		return result;
    	}
    }

    public cclass Room {
        
    	//List of heaters inside the room
    	public ArrayList heaters;
    	//List of thermometers inside the room
    	public ArrayList thermometers;
    	
        public Room (){
        	super();
        	thermometers=new ArrayList();
        	heaters=new ArrayList();
        }
        
    	public ArrayList getHeaters() {
    		return heaters;
    	}
    	
    	public ArrayList getThermometers() {
    		return thermometers;
    	}

    	public void setHeaters(ArrayList heaters) {
    		this.heaters = heaters;
    	}

    	public void setThermometers(ArrayList thermometers) {
    		this.thermometers = thermometers;
    	}
    	
    	public void addHeatersElement(Heater heater){
    		heaters.add(heater);
    	}
    	
    	public void addThermometersElement(Thermometer thermometer){
    		thermometers.add(thermometer);
    	}
    	
    	//Search for a heater by the giving id, returns null if not found
    	public Heater getHeaterById(String id){
    		int i=0;
    		Heater heaterAux=null;
    		boolean found=false;
    		while ((i<heaters.size())&&(!found)){
    			heaterAux=((Heater)heaters.get(i));
    			i++;
    			if (heaterAux.getHeaterId().equals(id)){
    				found=true;
    			}
    		}
    		if(found){
    			return heaterAux;
    		}else{
    			return null;
    		}
    	}
    	
    	//Search for a thermometer by the giving id, returns null if not found
    	public Thermometer getThermometerById(String id){
    		int i=0;
    		Thermometer thermometerAux=null;
    		boolean found=false;
    		while ((i<thermometers.size())&&(!found)){
    			thermometerAux=((Thermometer)thermometers.get(i));
    			i++;
    			if (thermometerAux.getThermometerId().equals(id)){
    				found=true;
    			}
    		}
    		if(found){
    			return thermometerAux;
    		}else{
    			return null;
    		}
    	}
    }
    
    /*
     * This class contains the information required for a heater, it would be used as a container 
     * and to help the task of the GUIs to retrieve information without the necessity of too much
     * communication
     */
    public cclass Heater {
    	//Unique id for the heater
    	public String heaterId;
    	//String name for the heater
    	public String name;
    	//Actual power value of the heater, between 0 and 100%
    	public int power;
    	//Mode of the heater
    	public HeaterManagement.HeatingModes mode=null;
    	//State of the heater (on or off)
    	public boolean state;
    	//Id of the thermometer associated to the heater
    	public String thermometerId;
    	//Temperature the heater is trying to get
    	public float temperature;
    	
    	public Heater(){
    		this.heaterId="";
    		this.power=0;
    		this.state=false;
    		this.mode=new HeaterManagement.HeatingModes();
    		this.mode.setValue("Cooling");
    		this.temperature=23.0f;
    	}
    	
    	public void setTemperature(float value){
    		this.temperature=value;
    	}
    	
    	public void setTemperature(String value){
    		this.temperature=Float.parseFloat(value);
    	}
    	
    	public float getTemperature(){
    		return temperature;
    	}
    	
    	public void setThermometerId(String id){
    		this.thermometerId=id;
    	}
    	
    	public String getThermometerId(){
    		return this.thermometerId;
    	}
    	
    	public void setState(boolean state){
    		this.state=state;
    	}
    	
    	public String getHeaterId() {
    		return heaterId;
    	}
    	public void setHeaterId(String id) {
    		this.heaterId = id;
    	}
    	public int getPower() {
    		return power;
    	}
    	public void setPower(int power) {
    		this.power = power;
    	}
    	
    	public boolean getState(){
    		return state;
    	}
    	
    	public HeaterManagement.HeatingModes getMode(){
    		return mode;
    	}
    	
    	public void setMode(HeaterManagement.HeatingModes value){
    		this.mode=value;
    	}
    	
    	public String getName() {
    		return name;
    	}
    	public void setName(String name) {
    		this.name = name;
    	}
    }
    
    /*
     * This class contains the information required for a thermometer, it would be used as a container 
     * and to help the task of the GUIs to retrieve information without the necessity of too much
     * communication
     */
    public cclass Thermometer {
    	//Unique id for the heater
    	public String thermometerId;
    	//String name for the heater
    	public String name;
    	//Actual temperature value of the thermometer, between 0 and 100%
    	public float temp;
    	//Actual outside temperature value of the thermometer, between 0 and 100%
    	public float outTemp;
    	
    	public Thermometer(){
    		this.thermometerId="";
    		this.temp=0.0f;
    		this.outTemp=0.0f;
    	}
    	
    	public String getThermometerId() {
    		return thermometerId;
    	}
    	public void setThermometerId(String id) {
    		this.thermometerId = id;
    	}
    	
    	public String getName() {
    		return name;
    	}
    	public void setName(String name) {
    		this.name = name;
    	}
    	
    	public float getTemp(){
    		return temp;
    	}
    	
    	public void setTemp(float value){
    		this.temp=value;
    	}
    	
    	public void setTemp(String value){
    		this.temp=Float.parseFloat(value);
    	}
    	
    	public float getOutTemp(){
    		return outTemp;
    	}
    	
    	public void setOutTemp(float value){
    		this.outTemp=value;
    	}
    	
    	public void setOutTemp(String value){
    		this.outTemp=Float.parseFloat(value);
    	}
    	
    }

    public Heater getHeaterInstance(){
    	Heater heater=new Heater();
    	return heater;
    }
    
    public Thermometer getThermometerInstance(){
    	Thermometer thermometer=new Thermometer();
    	return thermometer;
    }
}
