package windowManagement;

public interface IBlindNotify {
	public void changeBlindAperture(String blindId, int value);
}