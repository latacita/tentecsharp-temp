package windowManagement;

public interface IGeneralWindowNotify {
	public void changeAllWindowsAperture(String floorId,String roomId,int aperture);
}
