package windowManagement;

public interface IWindowDimmerNotify {
	public void windowDimmerValueChanged(int value, String windowId);
}
