cclass windowManagement.WindowManagement;

//This is the component that controls the window directly
//At the moment we are going to suppose that all the controlled windows can vary their aperture
public cclass BlindController extends TypeComponent {

	//Visual class that simulates the windowController
	public VisualBlindController visualBlindController;
	
	public BlindControllerPort request;
	
	//Aperture value for the Blind, the value can vary between 0 and 100
	public int blindAperture;
	//Id of the window that is being controlled
	public String blindId;
	//Floor in witch the dimmer is deployed, null if it is not in any floor
	public String floorId=null;
	//Room in witch the dimmer is deployed, null if it is not in any room
	public String roomId=null;
	//Device Kind
	public DeviceKind deviceKind;
	
	public BlindController(String id){
		super(id);
		deviceKind=new DeviceKind();
		deviceKind.setValue("BlindController");
		blindAperture=0;
		request=new BlindControllerPort();
		visualBlindController=new VisualBlindController();
	}
	
	public DeviceKind getDeviceKind() {
		return deviceKind;
	}

	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floor) {
		this.floorId = floor;
		visualBlindController.setFloorId(floor);
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String room) {
		this.roomId = room;
		visualBlindController.setRoomId(room);
	}

	public String getBlindId() {
		return blindId;
	}

	public void setBlindId(String blindId) {
		visualBlindController.setBlindId(blindId);
		this.blindId = blindId;
	}
	
	public int getBlindAperture() {
		return blindAperture;
	}

	public void setBlindAperture(int blindAperture) {
		visualBlindController.setAperture(blindAperture);
		this.blindAperture = blindAperture;
	}

	public BlindControllerPort getRequest() {
		return request;
	}
	
	public cclass BlindControllerPort extends TypePort implements IBlindController{
		public BlindControllerPort(){
			super();
		}
		
		public void setAperture(int value){
			BlindController.this.setBlindAperture(value);
		}
		public int getAperture(){
			return BlindController.this.getBlindAperture();
		}
		
		public String getId(){
			return BlindController.this.getId();
		}
		
		public String getBlindId(){
			return BlindController.this.getBlindId();
		}
		
		public String getFloorId(){
			return BlindController.this.getFloorId();
		}
		
		public void setFloorId(String value){
			BlindController.this.setFloorId(value);
		}
		
		public String getRoomId(){
			return BlindController.this.getRoomId();
		}
		
		public void setRoomId(String value){
			BlindController.this.setRoomId(value);
		}
	}
}