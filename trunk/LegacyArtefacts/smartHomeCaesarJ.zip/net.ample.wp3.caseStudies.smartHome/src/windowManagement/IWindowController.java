package windowManagement;

public interface IWindowController extends initialModel.IDevice{
	public void setAperture(int value);
	public int getAperture();
	//Get the id of the light controlled by the WindowController
	public String getWindowId();
}
