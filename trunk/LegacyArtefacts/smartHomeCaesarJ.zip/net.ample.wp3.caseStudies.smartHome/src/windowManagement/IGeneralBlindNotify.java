package windowManagement;

public interface IGeneralBlindNotify {
	public void changeAllBlindsAperture(String floorId,String roomId,int aperture);
}
