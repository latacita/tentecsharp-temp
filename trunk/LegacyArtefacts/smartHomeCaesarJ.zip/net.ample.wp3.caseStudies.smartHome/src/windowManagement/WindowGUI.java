cclass windowManagement.WindowManagement;

//WindowGUI controls a panel with some lights
public cclass WindowGUI extends TypeComponent{

	protected RequestPort request;
	protected ServicesPort services;
	public String windowId;
	public String floorId;
	public String roomId;
	
	//Panel that implements all the swing elements needed for the representation
	protected WindowGUIPanel visualGUI;
	
	public WindowGUI(String id){
		super(id);
		visualGUI=new WindowGUIPanel(this);
		request=new RequestPort();
		services=new ServicesPort();
	}
	
	public void setWindowId(String value){
		this.windowId=value;
		visualGUI.setWindowId(value);
	}
	
	public String getWindowId(){
		return windowId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public RequestPort getRequest() {
		return request;
	}

	public ServicesPort getServices() {
		return services;
	}

	public String getId(){
		return id;
	}
	
	public WindowGUIPanel getVisualGUI(){
		return visualGUI;
	}
	
	public void setVisualGUI(WindowGUIPanel panel){
		visualGUI=panel;
	}
	
	public RequestPort getRequestPort(){
		return request;
	}
	
	//Methods to advise the HouseGateway about changes in the GUI
	
	public void notifyWindowApertureChange(String windowId,int value){
		ArrayList ports=services.getPortsIWindowGUINotify();
		IWindowGUINotify port;
		for(int i=0;i<ports.size();i++){
			port=((IWindowGUINotify)ports.get(i));
			port.changeWindowAperture(windowId, value);
		}
	}
	
	//Methods for the IWindowNotify interface
	public void changeWindowAperture(String windowId, int value){
		visualGUI.changeWindowAperture(windowId,value);
	}
	
	public cclass ServicesPort extends TypePort{
		public ArrayList portsIWindowGUINotify; 
		
		public ServicesPort(){
			super();
			portsIWindowGUINotify=new ArrayList();
		}
		
		public ArrayList getPortsIWindowGUINotify() {
			return portsIWindowGUINotify;
		}
		
		public void connectPort(IWindowGUINotify port){
			portsIWindowGUINotify.add(port);
		}
	}
	
	public cclass RequestPort extends TypePort implements IWindowNotify{
		
		public RequestPort(){
			super();
		}

		public void changeWindowAperture(String windowId, int value){
			WindowGUI.this.changeWindowAperture(windowId,value);
		}
	}
}