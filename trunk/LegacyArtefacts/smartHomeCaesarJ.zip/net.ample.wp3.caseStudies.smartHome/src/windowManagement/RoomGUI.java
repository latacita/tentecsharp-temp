cclass windowManagement.WindowManagement;

public cclass RoomGUI extends TypeComponent{
	
	public WindowNotifyPort windowNotifyPort;
	public BlindNotifyPort blindNotifyPort;
	//List of window GUIs controlled by the room GUI
	protected ArrayList listWindowGUI;
	//List of blind GUIs controlled by the room GUI
	protected ArrayList listBlindGUI;
	//Tabbed pane that is added to the main menu of the GUI
	protected WindowGUITabbedPanel windowTabbedPanel;
	//Tabbed pane that is added to the main menu of the GUI
	protected BlindGUITabbedPanel blindTabbedPanel;
	//General control panels
	public RoomGeneralWindowPanel generalWindowPanel;
	public RoomGeneralBlindPanel generalBlindPanel;
	
	public RoomGUI(String id){
		super(id);
		listWindowGUI=new ArrayList();
		listBlindGUI=new ArrayList();
		windowTabbedPanel=new WindowGUITabbedPanel();
		blindTabbedPanel=new BlindGUITabbedPanel();
		visualGUI.addTabbedPanel(windowTabbedPanel,"Windows","/visual/icons/window20.png");
		visualGUI.addTabbedPanel(blindTabbedPanel,"Blinds","/visual/icons/blind20.png");
		generalWindowPanel=new RoomGeneralWindowPanel(this);
		generalBlindPanel=new RoomGeneralBlindPanel(this);
		visualGUI.addPanel(generalWindowPanel,"WindowControl","/visual/icons/windows20.png");
		visualGUI.addPanel(generalBlindPanel,"BlindControl","/visual/icons/blinds20.png");
		windowNotifyPort=new WindowNotifyPort();
		blindNotifyPort=new BlindNotifyPort();
	}
	
	public WindowNotifyPort getWindowNotifyPort(){
		return windowNotifyPort;
	}
	
	public BlindNotifyPort getBlindNotifyPort(){
		return blindNotifyPort;
	}
	
	public cclass WindowNotifyPort extends TypePort{
	    
		public ArrayList portsIGeneralWindowNotify;	
		 
	    public WindowNotifyPort(){
	    	super();
	    	portsIGeneralWindowNotify=new ArrayList();
	    }
	    	
	    public void connectPort(IGeneralWindowNotify port){
	    	portsIGeneralWindowNotify.add(port);
	    }
	      
	    public ArrayList getPortsIGeneralWindowNotify(){
	    	return portsIGeneralWindowNotify;
	    }
	}
	
	public cclass BlindNotifyPort extends TypePort{
	    
		public ArrayList portsIGeneralBlindNotify;	
		 
	    public BlindNotifyPort(){
	    	super();
	    	portsIGeneralBlindNotify=new ArrayList();
	    }
	    	    
	    public void connectPort(IGeneralBlindNotify port){
	    	portsIGeneralBlindNotify.add(port);
	    }
	    
	    public ArrayList getPortsIGeneralBlindNotify(){
	    	return portsIGeneralBlindNotify;
	    }
	}
	
	public ArrayList getListWindowGUI(){
		return listWindowGUI;
	}
	
	public ArrayList getListBlindGUI(){
		return listBlindGUI;
	}
	
	public void setListWindowGUI(ArrayList value){
		listWindowGUI=value;
	}
	
	public void setListBlindGUI(ArrayList value){
		listBlindGUI=value;
	}

	public void addListWindowGUIElement(WindowGUI windowGUI){
		listWindowGUI.add(windowGUI);
		windowTabbedPanel.addWindowGUIPanel("WindowGUI: "+windowGUI.getId(),windowGUI.getVisualGUI());
	}
	
	public void addListBlindGUIElement(BlindGUI blindGUI){
		listBlindGUI.add(blindGUI);
		blindTabbedPanel.addBlindGUIPanel("BlindGUI: "+blindGUI.getId(),blindGUI.getVisualGUI());
	}
	
//Methods used by the visual GUI to notify to CentralGUI
	
	public void openAllWindows(){
		changeAllWindowsAperture(100);
	}
	
	public void openAllBlinds(){
		changeAllBlindsAperture(100);
	}
	
	public void closeAllWindows(){
		changeAllWindowsAperture(0);
	}
	
	public void closeAllBlinds(){
		changeAllBlindsAperture(0);
	}
	
	public void changeAllWindowsAperture(int aperture){
		ArrayList ports=windowNotifyPort.getPortsIGeneralWindowNotify();
		IGeneralWindowNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralWindowNotify)ports.get(i));
			port.changeAllWindowsAperture(null,roomId,aperture);
		}
	}
	
	public void changeAllBlindsAperture(int aperture){
		ArrayList ports=blindNotifyPort.getPortsIGeneralBlindNotify();
		IGeneralBlindNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralBlindNotify)ports.get(i));
			port.changeAllBlindsAperture(null,roomId,aperture);
		}
	}
}

