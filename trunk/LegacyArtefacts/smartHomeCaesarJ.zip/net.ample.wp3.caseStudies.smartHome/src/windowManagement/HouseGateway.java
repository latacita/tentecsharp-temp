cclass windowManagement.WindowManagement;

public cclass HouseGateway extends TypeComponent{
    
    public HouseGateway(String id) {
    	super(id);
    	sensors=new SensorPort();
    }
      
    public void blindApertureChanged(String blindId, int aperture){
    	//First step is to look for the blind which value has changed and reflect the change
    	Blind blindAux=searchBlind(blindId);
    	if(blindAux!=null){
    		blindAux.setAperture(aperture);
    	}
    	   	
    	//Second step is to look for the rest all the dimmers controlling the blind and do the change
    	//Also the blind that initiates the notification, since the value is not changed until setValue is
    	//called by the houseGateway
    	
    	ArrayList blindDimmers=actuators.getPortsIBlindDimmer();
    	IBlindDimmer blindDimmerAux;
    	
    	for(int i=0;i<blindDimmers.size();i++){
    		blindDimmerAux=((IBlindDimmer)blindDimmers.get(i));
    		if(blindDimmerAux.getBlindId().equals(blindId)){
    			//Set value is used since we don't want more notifications from the dimmers about changed
    			blindDimmerAux.setAperture(aperture);	
    		}
    	}
    	
    	//Third step is to refresh the GUIs with the new values, the message is send to all the connected
    	//GUIs, however only the ones controlling the correct blind will do changes
    	ArrayList ports=services.getPortsIBlindNotify();
    	for(int i=0;i<ports.size();i++){
    		((IBlindNotify)ports.get(i)).changeBlindAperture(blindId, aperture);
    	}
    	
    	//The BlindControllers have to be notified too with the new values
    	ports=actuators.getPortsIBlindController();
    	IBlindController controller;
    	for(int i=0;i<ports.size();i++){
    		controller=((IBlindController)ports.get(i));
    		if(controller.getBlindId().equals(blindId)){
    			controller.setAperture(aperture);
    		}
    	}
    	
	}
    
    public void windowApertureChanged(String windowId, int aperture){
    	//First step is to look for the window which value has changed and reflect the change
    	Window windowAux=searchWindow(windowId);
    	if(windowAux!=null){
    		windowAux.setAperture(aperture);
    	}
    	
    	//Second step is to look for the rest all the dimmers controlling the window and do the change
    	//Also the window that initiates the notification, since the value is not changed until setValue is
    	//called by the houseGateway
    	
    	ArrayList windowDimmers=actuators.getPortsIWindowDimmer();
    	IWindowDimmer windowDimmerAux;
    	
    	for(int i=0;i<windowDimmers.size();i++){
    		windowDimmerAux=((IWindowDimmer)windowDimmers.get(i));
    		if(windowDimmerAux.getWindowId().equals(windowId)){
    			//Set value is used since we don't want more notifications from the dimmers about changed
    			windowDimmerAux.setAperture(aperture);	
    		}
    	}
    	
    	//Third step is to refresh the GUIs with the new values, the message is send to all the connected
    	//GUIs, however only the ones controlling the correct window will do changes
    	ArrayList ports=services.getPortsIWindowNotify();
    	for(int i=0;i<ports.size();i++){
    		((IWindowNotify)ports.get(i)).changeWindowAperture(windowId, aperture);
    	}
    	
    	//The WindowControllers have to be notified too with the new values
    	ports=actuators.getPortsIWindowController();
    	IWindowController controller;
    	for(int i=0;i<ports.size();i++){
    		controller=((IWindowController)ports.get(i));
    		if(controller.getWindowId().equals(windowId)){
    			controller.setAperture(aperture);
    		}
    	}
	}
    
    //Methods used by the IGeneralWindowNotify interface
    //If floorId and roomId are null, it means the order is for all the house
    //If roomId is null it means the order is for a floor
    //Other case the order is for the lights of a room
    
	public void changeAllWindowsAperture(String floorId, String roomId,int aperture){
		ArrayList windows=new ArrayList();
		Window windowAux;
		if((floorId==null)&&(roomId==null)){
			windows=houseData.getAllWindows();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				windows=floorAux.getAllWindows();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				windows=roomAux.getWindows();
			}
		}
		for(int i=0;i<windows.size();i++){
			windowAux=((Window)windows.get(i));
			windowApertureChanged(windowAux.getId(),aperture);
		}
	}
	
	//Methods used by the IGeneralBlindNotify interface
    //If floorId and roomId are null, it means the order is for all the house
    //If roomId is null it means the order is for a floor
    //Other case the order is for the lights of a room
    
	public void changeAllBlindsAperture(String floorId, String roomId,int aperture){
		ArrayList blinds=new ArrayList();
		Blind blindAux;
		if((floorId==null)&&(roomId==null)){
			blinds=houseData.getAllBlinds();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				blinds=floorAux.getAllBlinds();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				blinds=roomAux.getBlinds();
			}
		}
		for(int i=0;i<blinds.size();i++){
			blindAux=((Blind)blinds.get(i));
			blindApertureChanged(blindAux.getId(),aperture);
		}
	}
    
    //Method used to search for a windows inside the structure of the house
    //Returns null if there is no window with the given id in the structure
    public Window searchWindow(String id){
    	return houseData.getWindowById(id);
    }
    
    //Method used to search for a blind inside the structure of the house
    //Returns null if there is no window with the given id in the structure
    public Blind searchBlind(String id){
    	return houseData.getBlindById(id);
    }
    
    public cclass SensorPort extends TypePort implements IBlindDimmerNotify,IWindowDimmerNotify{
    	
    	public SensorPort(){
    		super();
    	}
    	
    	//A window dimmer has been manually modified. It is necessary to change the aperture of the window
    	//and to change the status of the GUIs
    	public void windowDimmerValueChanged(int value,String windowId) {
    		HouseGateway.this.windowApertureChanged(windowId,value);
    	}
    	
    	//A blind dimmer device has been manually modified. It is necessary to change the status of the blind
    	//and to change the status of the GUIs
    	public void blindDimmerValueChanged(int value,String blindId){
    		HouseGateway.this.blindApertureChanged(blindId,value);
    	}
    	
    }
    
    public cclass ActuatorPort implements IWindowGUINotify,IBlindGUINotify,IGeneralWindowNotify,IGeneralBlindNotify{
    	
    	public ArrayList portsIWindowDimmer;
    	public ArrayList portsIBlindDimmer;
    	public ArrayList portsIWindowController;
    	public ArrayList portsIBlindController;
    	
    	public ActuatorPort(){
    		super();
    		portsIWindowDimmer=new ArrayList();
    		portsIBlindDimmer=new ArrayList();
    		portsIWindowController=new ArrayList();
    		portsIBlindController=new ArrayList();    	
    	}
    	
    	public void connectPort(IWindowDimmer port){
    		portsIWindowDimmer.add(port);
    	}
    	
    	public void connectPort(IBlindDimmer port){
    		portsIBlindDimmer.add(port);
    	}

    	public void connectPort(IWindowController port){
    		portsIWindowController.add(port);
    	}

    	public void connectPort(IBlindController port){
    		portsIBlindController.add(port);
    	}
    	
		public ArrayList getPortsIWindowDimmer() {
			return portsIWindowDimmer;
		}

		public ArrayList getPortsIBlindDimmer() {
			return portsIBlindDimmer;
		}

		public ArrayList getPortsIWindowController() {
			return portsIWindowController;
		}
		
		public ArrayList getPortsIBlindController() {
			return portsIBlindController;
		}
		
		public void changeBlindAperture(String blindId, int aperture){
			HouseGateway.this.blindApertureChanged(blindId, aperture);
		}
		
		public void changeWindowAperture(String windowId, int aperture){
			HouseGateway.this.windowApertureChanged(windowId, aperture);
		}
		
		public void changeAllWindowsAperture(String floodId, String roomId,int aperture){
			HouseGateway.this.changeAllWindowsAperture(floodId,roomId,aperture);
		}
		
		public void changeAllBlindsAperture(String floodId, String roomId,int aperture){
			HouseGateway.this.changeAllBlindsAperture(floodId,roomId,aperture);
		}
    }
    
    public cclass ServicesPort{
    	
    	public ArrayList portsIBlindNotify;
    	public ArrayList portsIWindowNotify;
    	
    	public ServicesPort(){
    		super();
    		portsIBlindNotify=new ArrayList();
    		portsIWindowNotify=new ArrayList();
    	}
    	
    	public ArrayList getPortsIBlindNotify(){
    		return portsIBlindNotify;
    	}
    	
    	public ArrayList getPortsIWindowNotify(){
    		return portsIWindowNotify;
    	}
    	
    	public void connectPort(IBlindNotify port){
    		portsIBlindNotify.add(port);
    	}
    	
    	public void connectPort(IWindowNotify port){
    		portsIWindowNotify.add(port);
    	}
    }
    
    public cclass House {

    	public ArrayList windows;
    	public ArrayList blinds;
    	
    	public House(){
    		super();
    		windows=new ArrayList();
    		blinds=new ArrayList();
    	}

    	public void addWindow(Window window){
    		this.windows.add(window);
    	}
    	
    	public void addBlind(Blind blind){
    		this.blinds.add(blind);
    	}
    	
    	//Search for a window by the giving id, returns null if not found
        //it search first in the own windows and then in the floors
    	public Window getWindowById(String id){
    		int i=0;
    		Window windowAux=null;
    		Floor floorAux;
    		while (i<windows.size()){
    			windowAux=((Window)windows.get(i));
    			i++;
    			if (windowAux.getId().equals(id)){
    				return windowAux;
    			}
    		}
    		//In this point the light should be in a floor
    		i=0;
    		while (i<floors.size()){
    			floorAux=((Floor)floors.get(i));
    			windowAux=floorAux.getWindowById(id);
    			i++;
    			if (windowAux!=null){
    				return windowAux;
    			}
    		}
    		return null;
    	}
    	
    	//Search for a blind by the giving id, returns null if not found
        //it search first in the own blinds and then in the floors
    	public Blind getBlindById(String id){
    		int i=0;
    		Blind blindAux=null;
    		Floor floorAux;
    		while (i<blinds.size()){
    			blindAux=((Blind)blinds.get(i));
    			i++;
    			if (blindAux.getId().equals(id)){
    				return blindAux;
    			}
    		}
    		//In this point the light should be in a floor
    		i=0;
    		while (i<floors.size()){
    			floorAux=((Floor)floors.get(i));
    			blindAux=floorAux.getBlindById(id);
    			i++;
    			if (blindAux!=null){
    				return blindAux;
    			}
    		}
    		return null;
    	}
    	
    	//Method that returns a list with all the windows inside the house structure
    	public ArrayList getAllWindows(){
    		ArrayList result=new ArrayList();
    		Floor floorAux;
    		ArrayList rooms;
    		Room roomAux;
    		ArrayList windows;
    		
    		for(int i=0;i<floors.size();i++){
    			floorAux=((Floor)floors.get(i));
    			rooms=floorAux.getRooms();
    			for(int j=0;j<rooms.size();j++){
    				roomAux=((Room)rooms.get(j));
    				windows=roomAux.getWindows();
    				for(int k=0;k<windows.size();k++){
    					result.add(windows.get(k));
    				}
    			}
    		}
    		return result;
    	}
    	
    	//Method that returns a list with all the blinds inside the house structure
    	public ArrayList getAllBlinds(){
    		ArrayList result=new ArrayList();
    		Floor floorAux;
    		ArrayList rooms;
    		Room roomAux;
    		ArrayList blinds;
    		
    		for(int i=0;i<floors.size();i++){
    			floorAux=((Floor)floors.get(i));
    			rooms=floorAux.getRooms();
    			for(int j=0;j<rooms.size();j++){
    				roomAux=((Room)rooms.get(j));
    				blinds=roomAux.getBlinds();
    				for(int k=0;k<blinds.size();k++){
    					result.add(blinds.get(k));
    				}
    			}
    		}
    		return result;
    	}
    }

    public cclass Floor {
        
    	//List of blinds that are in the floor but not inside a room
    	public ArrayList blinds;
    	//List of windows that are in the floor but not inside a room
    	public ArrayList windows;
        
        public Floor(){
        	super();
        	blinds=new ArrayList();
        	windows=new ArrayList();
        }
    	
        public void addWindow(Window window){
    		this.windows.add(window);
    	}
    	
    	public void addBlind(Blind blind){
    		this.blinds.add(blind);
    	}
    	
    	//Search for a window by the giving id, returns null if not found
        //it search first in the own windows and then in the rooms
    	public Window getWindowById(String id){
    		int i=0;
    		Window windowAux=null;
    		Room roomAux;
    		while (i<windows.size()){
    			windowAux=((Window)windows.get(i));
    			i++;
    			if (windowAux.getId().equals(id)){
    				return windowAux;
    			}
    		}
    		//In this point the light should be in a room
    		i=0;
    		while (i<rooms.size()){
    			roomAux=((Room)rooms.get(i));
    			windowAux=roomAux.getWindowById(id);
    			i++;
    			if (windowAux!=null){
    				return windowAux;
    			}
    		}
    		return null;
    	}
    	
    	//Search for a blind by the giving id, returns null if not found
        //it search first in the own blinds and then in the floors
    	public Blind getBlindById(String id){
    		int i=0;
    		Blind blindAux=null;
    		Room roomAux;
    		while (i<blinds.size()){
    			blindAux=((Blind)blinds.get(i));
    			i++;
    			if (blindAux.getId().equals(id)){
    				return blindAux;
    			}
    		}
    		//In this point the light should be in a floor
    		i=0;
    		while (i<rooms.size()){
    			roomAux=((Room)rooms.get(i));
    			blindAux=roomAux.getBlindById(id);
    			i++;
    			if (blindAux!=null){
    				return blindAux;
    			}
    		}
    		return null;
    	}
    	
    	public ArrayList getAllWindows(){
    		ArrayList result=new ArrayList();
    		Room roomAux;
    		ArrayList windows;
    		
    		for(int i=0;i<rooms.size();i++){
    			roomAux=((Room)rooms.get(i));
    			windows=roomAux.getWindows();
    			for(int k=0;k<windows.size();k++){
    				result.add(windows.get(k));
    			}
    		}
    		return result;
    	}
    	
    	public ArrayList getAllBlinds(){
    		ArrayList result=new ArrayList();
    		Room roomAux;
    		ArrayList blinds;
    		
    		for(int i=0;i<rooms.size();i++){
    			roomAux=((Room)rooms.get(i));
    			blinds=roomAux.getBlinds();
    			for(int k=0;k<blinds.size();k++){
    				result.add(blinds.get(k));
    			}
    		}
    		return result;
    	}
    }

    public cclass Room {
        
    	//List of blinds that are in the floor but not inside a room
    	public ArrayList blinds;
    	//List of windows that are in the floor but not inside a room
    	public ArrayList windows;
    	
        public Room (){
        	super();
        	blinds=new ArrayList();
        	windows=new ArrayList();
        }
        
        public void addWindowsElement(Window window){
    		this.windows.add(window);
    	}
    	
    	public void addBlindsElement(Blind blind){
    		this.blinds.add(blind);
    	}
    	
    	public ArrayList getWindows(){
    		return windows;
    	}
    	
    	public ArrayList getBlinds(){
    		return blinds;
    	}
    	
    	//Search for a window by the giving id, returns null if not found
    	public Window getWindowById(String id){
    		int i=0;
    		Window windowAux=null;
    		while (i<windows.size()){
    			windowAux=((Window)windows.get(i));
    			i++;
    			if (windowAux.getId().equals(id)){
    				return windowAux;
    			}
    		}
    		return null;
    	}
    	
    	//Search for a blind by the giving id, returns null if not found
        //it search first in the own blinds and then in the floors
    	public Blind getBlindById(String id){
    		int i=0;
    		Blind blindAux=null;
    		Room roomAux;
    		while (i<blinds.size()){
    			blindAux=((Blind)blinds.get(i));
    			i++;
    			if (blindAux.getId().equals(id)){
    				return blindAux;
    			}
    		}
    		return null;
    	}
    }
    
    /*
     * This class contains the information required for a blind, it would be used as a container 
     * and to help the task of the GUIs to retrieve information without the necessity of too much
     * communication
     */
    public cclass Blind {
    	//Unique id for the blind
    	public String id;
    	//String name for the blind
    	public String name;
    	//Actual aperture of the blind, between 0 and 100
    	public int aperture=0;
    	
    	public Blind(){
    		this.id="";
    		this.aperture=0;
    	}
    	
    	public String getId() {
    		return id;
    	}
    	public void setId(String id) {
    		this.id = id;
    	}
    	public int getAperture() {
    		return aperture;
    	}
    	public void setAperture(int aperture) {
    		this.aperture = aperture;
    	}
    	public String getName() {
    		return name;
    	}
    	public void setName(String name) {
    		this.name = name;
    	}
    }

    /*
     * This class contains the information required for a window, it would be used as a container 
     * and to help the task of the GUIs to retrieve information without the necessity of too much
     * communication
     */
    public cclass Window {
    	//Unique id for the blind
    	public String id;
    	//String name for the blind
    	public String name;
    	//Actual aperture of the blind, between 0 and 100
    	public int aperture=0;
    	
    	public Window(){
    		this.id="";
    		this.aperture=0;
    	}
    	
    	public String getId() {
    		return id;
    	}
    	public void setId(String id) {
    		this.id = id;
    	}
    	public int getAperture() {
    		return aperture;
    	}
    	public void setAperture(int aperture) {
    		this.aperture = aperture;
    	}
    	public String getName() {
    		return name;
    	}
    	public void setName(String name) {
    		this.name = name;
    	}
    }
    
    public Blind getBlindInstance(){
    	Blind blind=new Blind();
    	return blind;
    }
    
    public Window getWindowInstance(){
    	Window window=new Window();
    	return window;
    }
   
}