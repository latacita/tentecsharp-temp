cclass lightManagement.LightManagement;

public cclass FloorGUI extends TypeComponent{
	
	public LightNotifyPort lightNotifyPort;
	public FloorGeneralLightPanel generalLightPanel;
	
	public FloorGUI(String id){
		super(id);
		lightNotifyPort=new LightNotifyPort();
		generalLightPanel=new FloorGeneralLightPanel(this);
		visualGUI.addPanel(generalLightPanel,"LightControl","/visual/icons/bulbs20.png");
	}
	
	public LightNotifyPort getLightNotifyPort(){
		return lightNotifyPort;
	}
	
	public cclass LightNotifyPort extends TypePort{
	    
		public ArrayList portsIGeneralLightNotify;	
		 
	    public LightNotifyPort(){
	    	super();
	    	portsIGeneralLightNotify=new ArrayList();
	    }
	    	
	    public void connectPort(IGeneralLightNotify port){
	    	portsIGeneralLightNotify.add(port);
	    }
	    
	    public ArrayList getPortsIGeneralLightNotify(){
	    	return portsIGeneralLightNotify;
	    }
	}
	
	//Methods used by the visual GUI to notify to CentralGUI
	
	public void switchOffAllLights(){
		ArrayList ports=lightNotifyPort.getPortsIGeneralLightNotify();
		IGeneralLightNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralLightNotify)ports.get(i));
			port.switchOffAllLights(floorId,null);
		}
	}
	
	public void switchOnAllLights(){
		ArrayList ports=lightNotifyPort.getPortsIGeneralLightNotify();
		IGeneralLightNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralLightNotify)ports.get(i));
			port.switchOnAllLights(floorId,null);
		}
	}
	
	public void changeAllLightsIntensity(int intensity){
		ArrayList ports=lightNotifyPort.getPortsIGeneralLightNotify();
		IGeneralLightNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralLightNotify)ports.get(i));
			port.changeAllLightsIntensity(floorId,null,intensity);
		}
	}
	
}

