package lightManagement;
import java.util.*;

public interface IGateway {
	public String addDevice(LightManagement.DeviceKind device,String floor, String room);
	public void removeDevice(String id);
	public void getDevices(ArrayList devices,ArrayList floor,ArrayList room);
}
