cclass lightManagement.LightManagement;


public cclass HouseGateway extends TypeComponent{
    
    public HouseGateway(String id) {
    	super(id);
    }
    
    public void switchValueChanged(String lightId, SwitchStatus status){
		
    	//First step is to look for the light which value has changed and reflect the change in the
    	//data structure
    	Light lightAux=searchLight(lightId);
    	if(lightAux!=null){
	    	if(status.getStringValue().equals("SwitchOn")){
	    		lightAux.setLightOn(true);
	    	}else{
	    		lightAux.setLightOn(false);
	    	}
    	}
    	/*Second step is to look for all the switches controlling the same light and do the change
    	Dimmers can be controled through the actuators port and the IDimmer conected port list*/
    	
    	ArrayList switches=actuators.getPortsISwitch();
    	ISwitch switchAux;
    	
    	for(int i=0;i<switches.size();i++){
    		switchAux=((ISwitch)switches.get(i));
    		if(switchAux.getLightId().equals(lightId)){
    			switchAux.setStatus(status);	
    		}
    	}
    	
    	//Third step is to refresh the GUIs with the new values, the message is send to all the connected
    	//GUIs, howerver only the ones controlling the correct light will do changes
    	ArrayList ports=services.getPortsILightNotify();
    	boolean state;
    	if(status.getStringValue().equals("SwitchOn")){
    		state=true;
    	}else{
    		state=false;
    	}
    	for(int i=0;i<ports.size();i++){
    		((ILightNotify)ports.get(i)).changeLightState(lightId, state);
    	}
    	
    	// The LightControllers have to be notified to with the new values
    	ports=actuators.getPortsILightController();
    	ILightController controller;
    	for(int i=0;i<ports.size();i++){
    		controller=((ILightController)ports.get(i));
    		if(controller.getLightId().equals(lightId)){
    			if(state){
    				controller.switchOn();
    			}else{
    				controller.switchOff();
    			}
    		}
    	}
    	
	}
    
    public void dimmerValueChanged(String lightId, int value){  	
    	//First step is to look for the light which value has changed and reflect the change
    	Light lightAux=searchLight(lightId);
    	if(lightAux!=null){
    		lightAux.setIntensity(value);
    	}
    	
    	//Second step is to look for the rest all the dimmers controlling the light and do the change
    	//Also the dimmer that initiates the notification, since the value is not changed until setValue is
    	//called by the houseGateway
    	
    	ArrayList dimmers=actuators.getPortsIDimmer();
    	IDimmer dimmerAux;
    	
    	for(int i=0;i<dimmers.size();i++){
    		dimmerAux=((IDimmer)dimmers.get(i));
    		if(dimmerAux.getLightId().equals(lightId)){
    			//Set value is used since we dont want more notifications from the dimmers about changed
    			dimmerAux.setValue(value);	
    		}
    	}
    	
    	//Third step is to refresh the GUIs with the new values, the message is send to all the connected
    	//GUIs, howerver only the ones controlling the correct light will do changes
    	ArrayList ports=services.getPortsILightNotify();
    	for(int i=0;i<ports.size();i++){
    		((ILightNotify)ports.get(i)).changeLightIntensity(lightId, value);
    	}
    	
    	//The LightControllers have to be notified to with the new values
    	ports=actuators.getPortsILightController();
    	ILightController controller;
    	for(int i=0;i<ports.size();i++){
    		controller=((ILightController)ports.get(i));
    		if(controller.getLightId().equals(lightId)){
    			controller.setValue(value);
    		}
    	}
	}
    
    //Method used to search for a light inside the structure of the house
    //Returns null if there is no light with the given id in the structure
    public Light searchLight(String id){
    	return houseData.getLightById(id);
    }
    
    //Methods used by the IGeneralLightNotify interface
    //If floorId and roomId are null, it means the order is for all the house
    //If roomId is null it means the order is for a floor
    //Other case the order is for the lights of a room
    public void switchOffAllLights(String floorId, String roomId){
    	ArrayList lights=new ArrayList();
		Light lightAux;
		SwitchStatus status=new SwitchStatus();
		status.setValue("SwitchOff");
		if((floorId==null)&&(roomId==null)){
			lights=houseData.getAllLights();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				lights=floorAux.getAllLights();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				lights=roomAux.getLights();
			}
		}
		for(int i=0;i<lights.size();i++){
			lightAux=((Light)lights.get(i));
			switchValueChanged(lightAux.getId(),status);
		}
	}
	
	public void switchOnAllLights(String floorId, String roomId){
		ArrayList lights=new ArrayList();
		Light lightAux;
		SwitchStatus status=new SwitchStatus();
		status.setValue("SwitchOn");
		if((floorId==null)&&(roomId==null)){
			lights=houseData.getAllLights();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				lights=floorAux.getAllLights();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				lights=roomAux.getLights();
			}
		}
		for(int i=0;i<lights.size();i++){
			lightAux=((Light)lights.get(i));
			switchValueChanged(lightAux.getId(),status);
		}
	}
	
	public void changeAllLightIntensity(String floorId, String roomId,int intensity){
		ArrayList lights=new ArrayList();
		Light lightAux;
		SwitchStatus status=new SwitchStatus();
		status.setValue("SwitchOn");
		if((floorId==null)&&(roomId==null)){
			lights=houseData.getAllLights();
		}else if(roomId==null){
			Floor floorAux=houseData.getFloorById(floorId);
			if(floorAux!=null){
				lights=floorAux.getAllLights();
			}
		}else{
			Room roomAux=houseData.getRoomById(roomId);
			if(roomAux!=null){
				lights=roomAux.getLights();
			}
		}
		for(int i=0;i<lights.size();i++){
			lightAux=((Light)lights.get(i));
			dimmerValueChanged(lightAux.getId(),intensity);
		}
	}
    
    public cclass SensorPort extends TypePort implements IDimmerNotify,ISwitchNotify{
    	 	
    	public SensorPort(){
    		super();
    	}
	
    	//A switch device has been manually modified. It is necesary to change the status of the light
    	//and to change the status of the GUIs
    	public void switchValueChanged(String lightId, SwitchStatus status) {
    		HouseGateway.this.switchValueChanged(lightId,status);
    	}
    	
    	//A dimmer device has been manually modified. It is necesary to change the status of the light
    	//and to change the status of the GUIs
    	public void dimmerValueChanged(String lightId, int value){
    		HouseGateway.this.dimmerValueChanged(lightId,value);
    	}
    }
    
    public cclass ActuatorPort implements ILightGUINotify, IGeneralLightNotify{
    	
    	public ArrayList portsIDimmer;
    	public ArrayList portsISwitch;
    	public ArrayList portsILightController;
    	
    	public ActuatorPort(){
    		super();
    		portsIDimmer=new ArrayList();
    		portsISwitch=new ArrayList();
    		portsILightController=new ArrayList();
    	}
    	
    	public void connectPort(IDimmer port){
    		portsIDimmer.add(port);
    	}
    	
    	public void connectPort(ISwitch port){
    		portsISwitch.add(port);
    	}

    	public void connectPort(ILightController port){
    		portsILightController.add(port);
    	}

		public ArrayList getPortsIDimmer() {
			return portsIDimmer;
		}

		public ArrayList getPortsILightController() {
			return portsILightController;
		}

		public ArrayList getPortsISwitch() {
			return portsISwitch;
		}
		
		public void changeLightIntensity(String lightId, int value){
			HouseGateway.this.dimmerValueChanged(lightId,value);
		}
		
		public void changeLightState(String lightId, boolean state){
			SwitchStatus status=new SwitchStatus();
			if(state){
				status.setValue("SwitchOn");
			}else{
				status.setValue("SwitchOff");
			}
			HouseGateway.this.switchValueChanged(lightId, status);
		}
		
		public void switchOffAllLights(String floodId, String roomId){
			HouseGateway.this.switchOffAllLights(floodId,roomId);
		}
		
		public void switchOnAllLights(String floodId, String roomId){
			HouseGateway.this.switchOnAllLights(floodId,roomId);
		}
		
		public void changeAllLightsIntensity(String floodId, String roomId,int intensity){
			HouseGateway.this.changeAllLightIntensity(floodId,roomId,intensity);
		}
    }
    
    public cclass ServicesPort{
    	
    	public ArrayList portsILightNotify;
    	
    	public ServicesPort(){
    		super();
    		portsILightNotify=new ArrayList();
    	}
    	
    	public ArrayList getPortsILightNotify(){
    		return portsILightNotify;
    	}
    	
    	public void connectPort(ILightNotify port){
    		portsILightNotify.add(port);
    	}
    }
    
    /*
     * In the lightManagement package the House class contain methods to search for lights
     * 
     */

    public cclass House {
    	
    	public House(){
    		super();
    	}
    	
    	//Search for a light by the giving id, returns null if not found
        //it search first in the own lights and then in the floors
    	public Light getLightById(String id){
    		int i=0;
    		Light lightAux=null;
    		Floor floorAux;
    		while (i<floors.size()){
    			floorAux=((Floor)floors.get(i));
    			lightAux=floorAux.getLightById(id);
    			i++;
    			if (lightAux!=null){
    				return lightAux;
    			}
    		}
    		return null;
    	}
    	
    	//Method that returns a list with all the lights inside the house structure
    	public ArrayList getAllLights(){
    		ArrayList result=new ArrayList();
    		Floor floorAux;
    		ArrayList rooms;
    		Room roomAux;
    		ArrayList lights;
    		
    		for(int i=0;i<floors.size();i++){
    			floorAux=((Floor)floors.get(i));
    			rooms=floorAux.getRooms();
    			for(int j=0;j<rooms.size();j++){
    				roomAux=((Room)rooms.get(j));
    				lights=roomAux.getLights();
    				for(int k=0;k<lights.size();k++){
    					result.add(lights.get(k));
    				}
    			}
    		}
    		return result;
    	}
    }

    public cclass Floor {
        
        public Floor(){
        	super();
        }
               
        //Search for a light by the giving id, returns null if not found
        //it search first in the own lights and then in the rooms
    	public Light getLightById(String id){
    		int i=0;
    		Light lightAux=null;
    		Room roomAux;
    		while (i<rooms.size()){
    			roomAux=((Room)rooms.get(i));
    			lightAux=roomAux.getLightById(id);
    			i++;
    			if (lightAux!=null){
    				return lightAux;
    			}
    		}
    		return null;
    	}
    	
    	//Method that returns a list with all the lights inside the floor structure
    	public ArrayList getAllLights(){
    		ArrayList result=new ArrayList();
    		Room roomAux;
    		ArrayList lights;
    		
    		for(int i=0;i<rooms.size();i++){
    			roomAux=((Room)rooms.get(i));
    			lights=roomAux.getLights();
    			for(int k=0;k<lights.size();k++){
    				result.add(lights.get(k));
    			}
    		}
    		return result;
    	}
    }

    /*
     * In the lightManagement package the Room class would also contains a list
     * with the id of the lights that are controlled inside a the room
     * 
     */
    public cclass Room {
        
    	//List of lights inside the room
    	public ArrayList lights;
    	
        public Room (){
        	super();
        	lights=new ArrayList();
        }
        
        public void addLightsElement(Light value){
        	lights.add(value);
        }
        
    	public ArrayList getLights() {
    		return lights;
    	}

    	public void setLights(ArrayList lights) {
    		this.lights = lights;
    	}

    	public void addLight(Light light){
    		lights.add(light);
    	}
    	
    	//Search for a light by the giving id, returns null if not found
    	public Light getLightById(String id){
    		int i=0;
    		Light lightAux=null;
    		boolean found=false;
    		while ((i<lights.size())&&(!found)){
    			lightAux=((Light)lights.get(i));
    			i++;
    			if (lightAux.getId().equals(id)){
    				found=true;
    			}
    		}
    		if(found){
    			return lightAux;
    		}else{
    			return null;
    		}
    	}
    }
    
    /*
     * This class contains the information required for a light, it would be used as a container 
     * and to help the task of the GUIs to retrieve information without the necesity of too much
     * communication
     */
    public cclass Light {
    	//Unique id for the light
    	public String id;
    	//String name for the light
    	public String name;
    	//Actual intensity value of the light
    	public int intensity=0;
    	//State of the light, false means off, and true means off
    	public boolean lightOn=false;
    	
    	public Light(){
    		this.id="";
    		this.intensity=0;
    		this.lightOn=false;
    	}
    	
    	public String getId() {
    		return id;
    	}
    	public void setId(String id) {
    		this.id = id;
    	}
    	public int getIntensity() {
    		return intensity;
    	}
    	public void setIntensity(int intensity) {
    		this.intensity = intensity;
    	}
    	public boolean isLightOn() {
    		return lightOn;
    	}
    	public void setLightOn(boolean value) {
    		this.lightOn = value;
    	}
    	public String getName() {
    		return name;
    	}
    	public void setName(String name) {
    		this.name = name;
    	}
    }

    public Light getLightInstance(){
    	Light light=new Light();
    	return light;
    }
    
}



