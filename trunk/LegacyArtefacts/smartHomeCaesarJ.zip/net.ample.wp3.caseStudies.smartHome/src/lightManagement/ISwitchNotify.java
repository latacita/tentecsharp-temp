package lightManagement;

public interface ISwitchNotify {
	//It is used to notify the HouseGateway when a switch device is touched, the String parameter
	//id of the light and the parameter is the new status for the switch
	public void switchValueChanged(String lightId, LightManagement.SwitchStatus status);
}
