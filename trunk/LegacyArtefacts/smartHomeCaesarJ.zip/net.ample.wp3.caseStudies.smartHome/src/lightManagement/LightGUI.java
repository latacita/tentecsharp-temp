cclass lightManagement.LightManagement;

//LightGUI controls a Light
public cclass LightGUI extends TypeComponent{

	protected RequestPort request;
	protected ServicesPort services;
	public String lightId;
	public String floorId;
	public String roomId;
	
	//Pannel that implements all the swing elements needed for the representation
	protected LightGUIPanel visualGUI;
	
	public LightGUI(String id){
		super(id);
		visualGUI=new LightGUIPanel(this);
		request=new RequestPort();
		services=new ServicesPort();
	}
	
	public void setLightId(String value){
		this.lightId=value;
		visualGUI.setLightId(value);
	}
	
	public String getLightId(){
		return lightId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public RequestPort getRequest() {
		return request;
	}

	public ServicesPort getServices() {
		return services;
	}
	
	public LightGUIPanel getVisualGUI(){
		return visualGUI;
	}
	
	public void setVisualGUI(LightGUIPanel panel){
		visualGUI=panel;
	}
	
	public RequestPort getRequestPort(){
		return request;
	}
	
	//Methods to advise the HouseGateway about changes in the GUI
	
	public void notifyLightIntensityChange(String lightId,int value){
		ArrayList ports=services.getPortsILightGUINotify();
		ILightGUINotify port;
		for(int i=0;i<ports.size();i++){
			port=((ILightGUINotify)ports.get(i));
			port.changeLightIntensity(lightId, value);
		}
	}
	
	public void notifyLightStateChange(String lightId,boolean state){
		ArrayList ports=services.getPortsILightGUINotify();
		ILightGUINotify port;
		for(int i=0;i<ports.size();i++){
			port=((ILightGUINotify)ports.get(i));
			port.changeLightState(lightId, state);
		}
	}
	
	//Methods for the ILightNotify interface
	public void changeLightIntensity(String lightId, int value){
		if(this.lightId.equals(lightId)){
			visualGUI.changeLightIntensity(lightId,value);
		}
	}
	
	public void changeLightState(String lightId, boolean state){
		if(this.lightId.equals(lightId)){
			visualGUI.changeLightState(lightId,state);
		}
	}
	
	public cclass ServicesPort extends TypePort{
		public ArrayList portsILightGUINotify; 
		
		public ServicesPort(){
			super();
			portsILightGUINotify=new ArrayList();
		}
		
		public ArrayList getPortsILightGUINotify() {
			return portsILightGUINotify;
		}
		
		public void connectPort(ILightGUINotify port){
			portsILightGUINotify.add(port);
		}
	}
	
	public cclass RequestPort extends TypePort implements ILightNotify{
		
		public RequestPort(){
			super();
		}
		public void changeLightIntensity(String lightId, int value){
			LightGUI.this.changeLightIntensity(lightId,value);
		}
		public void changeLightState(String lightId, boolean state){
			LightGUI.this.changeLightState(lightId, state);
		}
	}
	
}
