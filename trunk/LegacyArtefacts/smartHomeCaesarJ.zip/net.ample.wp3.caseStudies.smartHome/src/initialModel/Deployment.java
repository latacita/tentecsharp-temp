cclass initialModel.InitialModel;

public cclass Deployment extends TypeEnum{
    
	public Deployment(){
		super();
		values.add("lightWeight");
		values.add("heavyWeight");
	}
}
