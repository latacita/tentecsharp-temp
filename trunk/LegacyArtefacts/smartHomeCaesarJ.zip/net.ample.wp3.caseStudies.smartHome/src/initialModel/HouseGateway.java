cclass initialModel.InitialModel;

public cclass HouseGateway extends TypeComponent{
    
    protected ServicesPort services;
    protected ActuatorPort actuators;
    protected SensorPort sensors;
    
    //Structure with the information of the house
    protected House houseData;
    
    public HouseGateway(String id) {
    	super(id);
        services=new ServicesPort();
        actuators=new ActuatorPort();
        sensors=new SensorPort();
        houseData=new House();
    }
    
    public SensorPort getSensors(){
    	return sensors;
    }
    
    /**
     * Method that initiate the component behaviour, since this component control the others it will initiate
     * the others too
     */
    public void init(){
    	//First step is to initialize the GUIs
    	services.initGUIs();  
    	services.showGUIs();
    }
    
    public House getHouseData() {
		return houseData;
	}

	public void setHouseData(HouseGateway.House value) {
		this.houseData = value;
	}

	public ServicesPort getServices(){
        return services;
    }
    
    public ActuatorPort getActuators(){
        return actuators;
    }
    
    public cclass ActuatorPort extends TypePort{
        public ActuatorPort(){
        	super();
        }
    }

    public cclass SensorPort extends TypePort{
	 	
    	public SensorPort(){
    		super();
    	}
    	
    }
    
    public cclass ServicesPort extends TypePort{
        
        protected ArrayList portsINotify;
        public ArrayList portsIGUI;
        
        public ServicesPort (){
        	super();
            portsINotify=new ArrayList();
            portsIGUI=new ArrayList();
        }
              
        public void connectPort(INotify port){
            portsINotify.add(port);
        }   
        
        public void connectPort(IGUI port){
            portsIGUI.add(port);
        }      
        
        
        //Methods to initialize and show all the GUI's that are connected to the port through the IGUI interface
        public void initGUIs(){
        	for (int i=0;i<portsIGUI.size();i++){
        		((IGUI)portsIGUI.get(i)).initGUI();
        	}
        }
        
        public void showGUIs(){
        	for (int i=0;i<portsIGUI.size();i++){
        		((IGUI)portsIGUI.get(i)).showGUI();
        	}
        }
    }  
    
    //Classes for the data structure that is stored inside HouseGateway
    
    public cclass House {

    	public String name;
    	public ArrayList floors;
    	public String id;
    	
    	public House(){
    		this.id="";
    		floors=new ArrayList();
    	}

    	 public void addFloorsElement(Floor value){
         	floors.add(value);
         }
    	
    	public ArrayList getFloors() {
    		return floors;
    	}

    	public void setFloors(ArrayList floors) {
    		this.floors = floors;
    	}

    	public String getName() {
    		return name;
    	}

    	public void setName(String name) {
    		this.name = name;
    	}

    	public String getId() {
    		return id;
    	}

    	public void setId(String id) {
    		this.id = id;
    	}
    	
    	public void addFloor(Floor floor){
    		floors.add(floor);
    	}
    	
    	//Search a floor by the floor id inside the structure, returns null if not found
    	public Floor getFloorById(String id){
    		Floor floorAux;
    		int i=0;
    		while(i<floors.size()){
    			floorAux=((Floor)floors.get(i));
    			if(floorAux.getId().equals(id)){
    				return floorAux;
    			}
    			i++;
    		}
    		return null;
    	}
    	//Search a room by the room id inside the structure, returns null if not found
    	public Room getRoomById(String id){
    		Floor floorAux;
    		Room roomAux;
    		int i=0;
    		while(i<floors.size()){
    			floorAux=((Floor)floors.get(i));
    			roomAux=floorAux.getRoomById(id);
    			if(roomAux!=null){
    				return roomAux;
    			}
    			i++;
    		}
    		return null;
    	}
    	
    	//Obtains all the rooms of the house
    	public ArrayList getAllRooms(){
    		ArrayList result=new ArrayList();
    		Floor floorAux;
    		Room roomAux;
    		for(int i=0;i<floors.size();i++){
    			floorAux=((Floor)floors.get(i));
    			for(int j=0;j<floorAux.rooms.size();j++){
    				roomAux=((Room)floorAux.rooms.get(j));
    				result.add(roomAux);
    			}
    		}
    		return result;
    	}
    }
    
    public cclass Floor {
        
        public ArrayList rooms;
        public String name;
    	public String id;
        
        public Floor(){
        	rooms=new ArrayList();
        	this.id="";
        }
        
        public void addRoomsElement(Room value){
        	rooms.add(value);
        }
        
        public String getId() {
    		return id;
    	}

    	public void setId(String id) {
    		this.id = id;
    	}

    	public String getName() {
    		return name;
    	}
    	
    	public void setName(String name) {
    		this.name = name;
    	}

    	public ArrayList getRooms(){
            return this.rooms;
        }
        public void setRooms(ArrayList value){
            rooms=value;
        }
        
        public void addRoom(Room room){
        	rooms.add(room);
        }
        
        public Room getRoomById(String id){
        	int i=0;
    		Room roomAux=null;
    		while (i<rooms.size()){
    			roomAux=((Room)rooms.get(i));
    			i++;
    			if (roomAux.getId().equals(id)){
    				return roomAux;
    			}
    		}
    		return null;
        }
        
    }
    
    public cclass Room {
        
    	public String name;
    	public String id;
    	
        public Room (){
        	this.id="";
        }

    	public String getId() {
    		return id;
    	}

    	public void setId(String id) {
    		this.id = id;
    	}


    	public String getName() {
    		return name;
    	}

    	public void setName(String name) {
    		this.name = name;
    	}
    }
    
    //Some helping methods to get instances of the internal classes
    
    public House getHouseInstance(){
    	House house=new House();
    	return house;
    }
    
    public Floor getFloorInstance(){
    	Floor floor=new Floor();
    	return floor;
    }
    
    public Room getRoomInstance(){
    	Room room=new Room();
    	return room;
    }

}
