package myHouse;

import lightManagement.*;
import smartEnergyControl.*;

public cclass MyHouse extends LightManagement & SmartEnergyControl  {

	public CentralGUI centralGUI1;

	public FloorGUI floorGUI1;

	public FloorGUI floorGUI2;

	public RoomGUI roomGUI1;

	public HouseGateway houseGateway1;

	public RoomGUI roomGUI2;

	public RoomGUI roomGUI3;

	public RoomGUI roomGUI4;

	public HouseGateway.Floor floor1;	

	public HouseGateway.Room room1;	

	public HouseGateway.House house1;	

	public HouseGateway.Floor floor2;	

	public HouseGateway.Light light1;	

	public HouseGateway.Light light2;	

	public HouseGateway.Light light3;	

	public HouseGateway.Light light4;	

	public HouseGateway.Light light5;	

	public HouseGateway.Light light6;	

	public HouseGateway.Room room2;	

	public HouseGateway.Room room3;	

	public HouseGateway.Room room4;	

	public LightGUI lightGUI1;

	public LightGUI lightGUI2;

	public LightGUI lightGUI3;

	public LightGUI lightGUI4;

	public LightGUI lightGUI5;

	public LightGUI lightGUI6;

	public LightController lightController1;

	public LightController lightController2;

	public LightController lightController3;

	public LightController lightController4;

	public LightController lightController5;

	public LightController lightController6;

	public Switch switch1;

	public Switch switch2;

	public Switch switch3;

	public Switch switch4;

	public Switch switch5;

	public Switch switch6;

	public Dimmer dimmer1;

	public Dimmer dimmer2;

	public Dimmer dimmer3;

	public Dimmer dimmer4;

	public Dimmer dimmer5;

	public Dimmer dimmer6;

	public HouseGateway.Window window1;	

	public HouseGateway.Window window2;	

	public HouseGateway.Window window3;	

	public HouseGateway.Window window4;	

	public HouseGateway.Window window5;	

	public HouseGateway.Window window6;	

	public HouseGateway.Blind blind1;	

	public HouseGateway.Blind blind2;	

	public HouseGateway.Blind blind3;	

	public HouseGateway.Blind blind4;	

	public HouseGateway.Blind blind5;	

	public HouseGateway.Blind blind6;	

	public WindowGUI windowGUI1;

	public WindowGUI windowGUI2;

	public WindowGUI windowGUI3;

	public WindowGUI windowGUI4;

	public WindowGUI windowGUI5;

	public WindowGUI windowGUI6;

	public BlindGUI blindGUI1;

	public BlindGUI blindGUI2;

	public BlindGUI blindGUI3;

	public BlindGUI blindGUI4;

	public BlindGUI blindGUI5;

	public BlindGUI blindGUI6;

	public BlindController blindController1;

	public BlindController blindController2;

	public BlindController blindController3;

	public BlindController blindController4;

	public BlindController blindController5;

	public BlindController blindController6;

	public BlindDimmer blindDimmer1;

	public BlindDimmer blindDimmer2;

	public BlindDimmer blindDimmer3;

	public BlindDimmer blindDimmer4;

	public BlindDimmer blindDimmer5;

	public BlindDimmer blindDimmer6;

	public WindowController windowController1;

	public WindowController windowController2;

	public WindowController windowController3;

	public WindowController windowController4;

	public WindowController windowController5;

	public WindowController windowController6;

	public WindowDimmer windowDimmer1;

	public WindowDimmer windowDimmer2;

	public WindowDimmer windowDimmer3;

	public WindowDimmer windowDimmer4;

	public WindowDimmer windowDimmer5;

	public WindowDimmer windowDimmer6;

	public HouseGateway.Heater heater1;	

	public HouseGateway.Heater heater2;	

	public HouseGateway.Heater heater3;	

	public HouseGateway.Heater heater4;	

	public HouseGateway.Thermometer thermometer1;	

	public HouseGateway.Thermometer thermometer2;	

	public HouseGateway.Thermometer thermometer3;	

	public HouseGateway.Thermometer thermometer4;	

	public HeatingController heatingController1;

	public HeatingController heatingController2;

	public HeatingController heatingController3;

	public HeatingController heatingController4;

	public Thermometer thermometerComp1;

	public Thermometer thermometerComp2;

	public Thermometer thermometerComp3;

	public Thermometer thermometerComp4;

	public ThermometerGUI thermometerGUI1;

	public ThermometerGUI thermometerGUI2;

	public ThermometerGUI thermometerGUI3;

	public ThermometerGUI thermometerGUI4;

	public HeaterGUI heaterGUI1;

	public HeaterGUI heaterGUI2;

	public HeaterGUI heaterGUI3;

	public HeaterGUI heaterGUI4;

	public MyHouse(){
		super();
		TypeEnum enumAux;
	
		centralGUI1=new CentralGUI("centralGUI1");
		floorGUI1=new FloorGUI("floorGUI1");
		floorGUI2=new FloorGUI("floorGUI2");
		roomGUI1=new RoomGUI("roomGUI1");
		houseGateway1=new HouseGateway("houseGateway1");
		roomGUI2=new RoomGUI("roomGUI2");
		roomGUI3=new RoomGUI("roomGUI3");
		roomGUI4=new RoomGUI("roomGUI4");
		floor1=houseGateway1.getFloorInstance();
		room1=houseGateway1.getRoomInstance();
		house1=houseGateway1.getHouseInstance();
		floor2=houseGateway1.getFloorInstance();
		light1=houseGateway1.getLightInstance();
		light2=houseGateway1.getLightInstance();
		light3=houseGateway1.getLightInstance();
		light4=houseGateway1.getLightInstance();
		light5=houseGateway1.getLightInstance();
		light6=houseGateway1.getLightInstance();
		room2=houseGateway1.getRoomInstance();
		room3=houseGateway1.getRoomInstance();
		room4=houseGateway1.getRoomInstance();
		lightGUI1=new LightGUI("lightGUI1");
		lightGUI2=new LightGUI("lightGUI2");
		lightGUI3=new LightGUI("lightGUI3");
		lightGUI4=new LightGUI("lightGUI4");
		lightGUI5=new LightGUI("lightGUI5");
		lightGUI6=new LightGUI("lightGUI6");
		lightController1=new LightController("lightController1");
		lightController2=new LightController("lightController2");
		lightController3=new LightController("lightController3");
		lightController4=new LightController("lightController4");
		lightController5=new LightController("lightController5");
		lightController6=new LightController("lightController6");
		switch1=new Switch("switch1");
		switch2=new Switch("switch2");
		switch3=new Switch("switch3");
		switch4=new Switch("switch4");
		switch5=new Switch("switch5");
		switch6=new Switch("switch6");
		dimmer1=new Dimmer("dimmer1");
		dimmer2=new Dimmer("dimmer2");
		dimmer3=new Dimmer("dimmer3");
		dimmer4=new Dimmer("dimmer4");
		dimmer5=new Dimmer("dimmer5");
		dimmer6=new Dimmer("dimmer6");
		window1=houseGateway1.getWindowInstance();
		window2=houseGateway1.getWindowInstance();
		window3=houseGateway1.getWindowInstance();
		window4=houseGateway1.getWindowInstance();
		window5=houseGateway1.getWindowInstance();
		window6=houseGateway1.getWindowInstance();
		blind1=houseGateway1.getBlindInstance();
		blind2=houseGateway1.getBlindInstance();
		blind3=houseGateway1.getBlindInstance();
		blind4=houseGateway1.getBlindInstance();
		blind5=houseGateway1.getBlindInstance();
		blind6=houseGateway1.getBlindInstance();
		windowGUI1=new WindowGUI("windowGUI1");
		windowGUI2=new WindowGUI("windowGUI2");
		windowGUI3=new WindowGUI("windowGUI3");
		windowGUI4=new WindowGUI("windowGUI4");
		windowGUI5=new WindowGUI("windowGUI5");
		windowGUI6=new WindowGUI("windowGUI6");
		blindGUI1=new BlindGUI("blindGUI1");
		blindGUI2=new BlindGUI("blindGUI2");
		blindGUI3=new BlindGUI("blindGUI3");
		blindGUI4=new BlindGUI("blindGUI4");
		blindGUI5=new BlindGUI("blindGUI5");
		blindGUI6=new BlindGUI("blindGUI6");
		blindController1=new BlindController("blindController1");
		blindController2=new BlindController("blindController2");
		blindController3=new BlindController("blindController3");
		blindController4=new BlindController("blindController4");
		blindController5=new BlindController("blindController5");
		blindController6=new BlindController("blindController6");
		blindDimmer1=new BlindDimmer("blindDimmer1");
		blindDimmer2=new BlindDimmer("blindDimmer2");
		blindDimmer3=new BlindDimmer("blindDimmer3");
		blindDimmer4=new BlindDimmer("blindDimmer4");
		blindDimmer5=new BlindDimmer("blindDimmer5");
		blindDimmer6=new BlindDimmer("blindDimmer6");
		windowController1=new WindowController("windowController1");
		windowController2=new WindowController("windowController2");
		windowController3=new WindowController("windowController3");
		windowController4=new WindowController("windowController4");
		windowController5=new WindowController("windowController5");
		windowController6=new WindowController("windowController6");
		windowDimmer1=new WindowDimmer("windowDimmer1");
		windowDimmer2=new WindowDimmer("windowDimmer2");
		windowDimmer3=new WindowDimmer("windowDimmer3");
		windowDimmer4=new WindowDimmer("windowDimmer4");
		windowDimmer5=new WindowDimmer("windowDimmer5");
		windowDimmer6=new WindowDimmer("windowDimmer6");
		heater1=houseGateway1.getHeaterInstance();
		heater2=houseGateway1.getHeaterInstance();
		heater3=houseGateway1.getHeaterInstance();
		heater4=houseGateway1.getHeaterInstance();
		thermometer1=houseGateway1.getThermometerInstance();
		thermometer2=houseGateway1.getThermometerInstance();
		thermometer3=houseGateway1.getThermometerInstance();
		thermometer4=houseGateway1.getThermometerInstance();
		heatingController1=new HeatingController("heatingController1");
		heatingController2=new HeatingController("heatingController2");
		heatingController3=new HeatingController("heatingController3");
		heatingController4=new HeatingController("heatingController4");
		thermometerComp1=new Thermometer("thermometerComp1");
		thermometerComp2=new Thermometer("thermometerComp2");
		thermometerComp3=new Thermometer("thermometerComp3");
		thermometerComp4=new Thermometer("thermometerComp4");
		thermometerGUI1=new ThermometerGUI("thermometerGUI1");
		thermometerGUI2=new ThermometerGUI("thermometerGUI2");
		thermometerGUI3=new ThermometerGUI("thermometerGUI3");
		thermometerGUI4=new ThermometerGUI("thermometerGUI4");
		heaterGUI1=new HeaterGUI("heaterGUI1");
		heaterGUI2=new HeaterGUI("heaterGUI2");
		heaterGUI3=new HeaterGUI("heaterGUI3");
		heaterGUI4=new HeaterGUI("heaterGUI4");


		centralGUI1.setHouseId("house1");
		
		centralGUI1.addFloorGUIsElement(floorGUI1);		
		centralGUI1.addFloorGUIsElement(floorGUI2);

		floorGUI1.setFloorId("floor1");
		
		floorGUI1.addRoomGUIsElement(roomGUI1);		
		floorGUI1.addRoomGUIsElement(roomGUI2);

		floorGUI2.setFloorId("floor2");
		
		floorGUI2.addRoomGUIsElement(roomGUI3);		
		floorGUI2.addRoomGUIsElement(roomGUI4);

		roomGUI1.setFloorId("floor1");
		roomGUI1.setRoomId("room1");
		
		roomGUI1.addListLightGUIElement(lightGUI1);		
		roomGUI1.addListLightGUIElement(lightGUI2);
		
		roomGUI1.addListBlindGUIElement(blindGUI1);		
		roomGUI1.addListBlindGUIElement(blindGUI2);
		
		roomGUI1.addListWindowGUIElement(windowGUI1);		
		roomGUI1.addListWindowGUIElement(windowGUI2);
		
		roomGUI1.addListHeaterGUIElement(heaterGUI1);
		
		roomGUI1.addListThermometerGUIElement(thermometerGUI1);

		houseGateway1.setHouseData(house1);

		roomGUI2.setFloorId("floor1");
		roomGUI2.setRoomId("room2");
		
		roomGUI2.addListLightGUIElement(lightGUI3);		
		roomGUI2.addListLightGUIElement(lightGUI4);
		
		roomGUI2.addListBlindGUIElement(blindGUI3);		
		roomGUI2.addListBlindGUIElement(blindGUI4);
		
		roomGUI2.addListWindowGUIElement(windowGUI3);		
		roomGUI2.addListWindowGUIElement(windowGUI4);
		
		roomGUI2.addListHeaterGUIElement(heaterGUI2);
		
		roomGUI2.addListThermometerGUIElement(thermometerGUI2);

		roomGUI3.setFloorId("floor2");
		
		roomGUI3.addListLightGUIElement(lightGUI5);
		roomGUI3.setRoomId("room3");
		
		roomGUI3.addListBlindGUIElement(blindGUI5);
		
		roomGUI3.addListWindowGUIElement(windowGUI5);
		
		roomGUI3.addListHeaterGUIElement(heaterGUI3);
		
		roomGUI3.addListThermometerGUIElement(thermometerGUI3);

		roomGUI4.setFloorId("floor2");
		
		roomGUI4.addListLightGUIElement(lightGUI6);
		roomGUI4.setRoomId("room4");
		
		roomGUI4.addListBlindGUIElement(blindGUI6);
		
		roomGUI4.addListWindowGUIElement(windowGUI6);
		
		roomGUI4.addListHeaterGUIElement(heaterGUI4);
		
		roomGUI4.addListThermometerGUIElement(thermometerGUI4);

		floor1.setId("floor1");
		floor1.setName("First Floor");
		
		floor1.addRoomsElement(room1);		
		floor1.addRoomsElement(room2);
		floor1.setSmartControlActive(false);

		
		room1.addLightsElement(light1);		
		room1.addLightsElement(light2);
		room1.setId("room1");
		room1.setName("Living Room");
		
		room1.addBlindsElement(blind1);		
		room1.addBlindsElement(blind2);
		
		room1.addWindowsElement(window1);		
		room1.addWindowsElement(window2);
		
		room1.addHeatersElement(heater1);
		
		room1.addThermometersElement(thermometer1);
		room1.setSmartControlActive(false);

		
		house1.addFloorsElement(floor1);		
		house1.addFloorsElement(floor2);
		house1.setId("house1");
		house1.setName("test house");
		house1.setSmartControlActive(false);

		floor2.setId("floor2");
		floor2.setName("Second Floor");
		
		floor2.addRoomsElement(room3);		
		floor2.addRoomsElement(room4);
		floor2.setSmartControlActive(false);

		light1.setId("light1");
		light1.setIntensity(0);
		light1.setLightOn(false);
		light1.setName("main light");

		light2.setId("light2");
		light2.setIntensity(0);
		light2.setLightOn(false);
		light2.setName("small light");

		light3.setId("light3");
		light3.setIntensity(0);
		light3.setLightOn(false);
		light3.setName("main light");

		light4.setId("light4");
		light4.setIntensity(0);
		light4.setLightOn(false);
		light4.setName("small light");

		light5.setId("light5");
		light5.setIntensity(0);
		light5.setLightOn(false);
		light5.setName("main light");

		light6.setId("light6");
		light6.setIntensity(0);
		light6.setLightOn(false);
		light6.setName("main light");

		room2.setId("room2");
		
		room2.addLightsElement(light3);		
		room2.addLightsElement(light4);
		room2.setName("Kitchen");
		
		room2.addBlindsElement(blind3);		
		room2.addBlindsElement(blind4);
		
		room2.addWindowsElement(window3);		
		room2.addWindowsElement(window4);
		
		room2.addHeatersElement(heater2);
		
		room2.addThermometersElement(thermometer2);
		room2.setSmartControlActive(false);

		room3.setId("room3");
		
		room3.addLightsElement(light5);
		room3.setName("Bedroom");
		
		room3.addBlindsElement(blind5);
		
		room3.addWindowsElement(window5);
		
		room3.addHeatersElement(heater3);
		
		room3.addThermometersElement(thermometer3);
		room3.setSmartControlActive(false);

		room4.setId("room4");
		
		room4.addLightsElement(light6);
		room4.setName("Toilet");
		
		room4.addBlindsElement(blind6);
		
		room4.addWindowsElement(window6);
		
		room4.addHeatersElement(heater4);
		
		room4.addThermometersElement(thermometer4);
		room4.setSmartControlActive(false);

		lightGUI1.setFloorId("floor1");
		lightGUI1.setLightId("light1");
		lightGUI1.setRoomId("room1");

		lightGUI2.setFloorId("floor1");
		lightGUI2.setLightId("light2");
		lightGUI2.setRoomId("room1");

		lightGUI3.setFloorId("floor1");
		lightGUI3.setLightId("light2");
		lightGUI3.setRoomId("room2");

		lightGUI4.setFloorId("floor1");
		lightGUI4.setLightId("light4");
		lightGUI4.setRoomId("room2");

		lightGUI5.setFloorId("floor2");
		lightGUI5.setLightId("light5");
		lightGUI5.setRoomId("room3");

		lightGUI6.setFloorId("floor2");
		lightGUI6.setLightId("light6");
		lightGUI6.setRoomId("room4");

		lightController1.setFloorId("floor1");
		lightController1.setLightId("light1");
		lightController1.setRoomId("room1");

		lightController2.setFloorId("floor1");
		lightController2.setLightId("light2");
		lightController2.setRoomId("room1");

		lightController3.setFloorId("floor1");
		lightController3.setLightId("light3");
		lightController3.setRoomId("room2");

		lightController4.setFloorId("floor1");
		lightController4.setLightId("light4");
		lightController4.setRoomId("room2");

		lightController5.setFloorId("floor2");
		lightController5.setLightId("light5");
		lightController5.setRoomId("room3");

		lightController6.setFloorId("floor2");
		lightController6.setLightId("light6");
		lightController6.setRoomId("room4");

		enumAux=new SwitchStatus();
		enumAux.setValue("SwitchOff");
		switch1.setStatus((SwitchStatus)enumAux);

		switch1.setFloorId("floor1");
		switch1.setLightId("light1");
		switch1.setRoomId("room1");

		switch2.setFloorId("floor1");
		switch2.setLightId("light2");
		switch2.setRoomId("room1");
		enumAux=new SwitchStatus();
		enumAux.setValue("SwitchOff");
		switch2.setStatus((SwitchStatus)enumAux);


		switch3.setFloorId("floor1");
		switch3.setLightId("light3");
		switch3.setRoomId("room2");
		enumAux=new SwitchStatus();
		enumAux.setValue("SwitchOff");
		switch3.setStatus((SwitchStatus)enumAux);


		switch4.setFloorId("floor1");
		switch4.setLightId("light4");
		switch4.setRoomId("room2");
		enumAux=new SwitchStatus();
		enumAux.setValue("SwitchOff");
		switch4.setStatus((SwitchStatus)enumAux);


		switch5.setFloorId("floor2");
		switch5.setLightId("light5");
		switch5.setRoomId("room3");
		enumAux=new SwitchStatus();
		enumAux.setValue("SwitchOff");
		switch5.setStatus((SwitchStatus)enumAux);


		switch6.setFloorId("floor2");
		switch6.setLightId("light6");
		switch6.setRoomId("room4");
		enumAux=new SwitchStatus();
		enumAux.setValue("SwitchOff");
		switch6.setStatus((SwitchStatus)enumAux);


		dimmer1.setFloorId("floor1");
		dimmer1.setLightId("light1");
		dimmer1.setRoomId("room1");

		dimmer2.setFloorId("floor1");
		dimmer2.setLightId("light2");
		dimmer2.setRoomId("room1");

		dimmer3.setFloorId("floor1");
		dimmer3.setLightId("light3");
		dimmer3.setRoomId("room2");

		dimmer4.setFloorId("floor1");
		dimmer4.setLightId("light4");
		dimmer4.setRoomId("room2");

		dimmer5.setFloorId("floor2");
		dimmer5.setLightId("light5");
		dimmer5.setRoomId("room3");

		dimmer6.setFloorId("floor2");
		dimmer6.setLightId("light6");
		dimmer6.setRoomId("room4");

		window1.setId("window1");
		window1.setName("big window");

		window2.setId("window2");
		window2.setName("small window");

		window3.setId("window3");
		window3.setName("big window");

		window4.setId("window4");
		window4.setName("small window");

		window5.setId("window5");
		window5.setName("big window");

		window6.setId("window6");
		window6.setName("main window");
  
		blind1.setId("blind1");
		blind1.setName("main window blind");

		blind2.setId("blind2");
		blind2.setName("small blind");

		blind3.setId("blind3");
		blind3.setName("main window blind");

		blind4.setId("blind4");
		blind4.setName("small blind");

		blind5.setId("blind5");
		blind5.setName("main blind");

		blind6.setId("blind6");
		blind6.setName("main blind");

		windowGUI1.setFloorId("floor1");
		windowGUI1.setRoomId("room1");
		windowGUI1.setWindowId("window1");

		windowGUI2.setFloorId("floor1");
		windowGUI2.setRoomId("room1");
		windowGUI2.setWindowId("window2");

		windowGUI3.setFloorId("floor1");
		windowGUI3.setRoomId("room2");
		windowGUI3.setWindowId("window3");

		windowGUI4.setFloorId("floor1");
		windowGUI4.setRoomId("room2");
		windowGUI4.setWindowId("window4");

		windowGUI5.setFloorId("floor2");
		windowGUI5.setRoomId("room3");
		windowGUI5.setWindowId("window5");

		windowGUI6.setFloorId("floor2");
		windowGUI6.setRoomId("room4");
		windowGUI6.setWindowId("window6");

		blindGUI1.setBlindId("blind1");
		blindGUI1.setFloorId("floor1");
		blindGUI1.setRoomId("room1");

		blindGUI2.setBlindId("blind2");
		blindGUI2.setFloorId("floor1");
		blindGUI2.setRoomId("room1");

		blindGUI3.setBlindId("blind3");
		blindGUI3.setFloorId("floor1");
		blindGUI3.setRoomId("room2");

		blindGUI4.setBlindId("blind4");
		blindGUI4.setFloorId("floor1");
		blindGUI4.setRoomId("room2");

		blindGUI5.setBlindId("blind5");
		blindGUI5.setFloorId("floor2");
		blindGUI5.setRoomId("room3");

		blindGUI6.setBlindId("blind6");
		blindGUI6.setFloorId("floor2");
		blindGUI6.setRoomId("room4");

		blindController1.setBlindId("blind1");
		blindController1.setFloorId("floor1");
		blindController1.setRoomId("room1");

		blindController2.setBlindId("blind2");
		blindController2.setFloorId("floor1");
		blindController2.setRoomId("room1");

		blindController3.setBlindId("blind3");
		blindController3.setFloorId("floor1");
		blindController3.setRoomId("room2");

		blindController4.setBlindId("blind4");
		blindController4.setFloorId("floor1");
		blindController4.setRoomId("room2");

		blindController5.setBlindId("blind5");
		blindController5.setFloorId("floor2");
		blindController5.setRoomId("room3");

		blindController6.setBlindId("blind6");
		blindController6.setFloorId("floor2");
		blindController6.setRoomId("room4");

		blindDimmer1.setFloorId("floor1");
		blindDimmer1.setBlindId("blind1");
		blindDimmer1.setRoomId("room1");

		blindDimmer2.setBlindId("blind2");
		blindDimmer2.setFloorId("floor1");
		blindDimmer2.setRoomId("room1");

		blindDimmer3.setBlindId("blind3");
		blindDimmer3.setFloorId("floor1");
		blindDimmer3.setRoomId("room2");

		blindDimmer4.setBlindId("blind4");
		blindDimmer4.setFloorId("floor1");
		blindDimmer4.setRoomId("room2");

		blindDimmer5.setBlindId("blind5");
		blindDimmer5.setFloorId("floor2");
		blindDimmer5.setRoomId("room3");

		blindDimmer6.setBlindId("blind6");
		blindDimmer6.setFloorId("floor2");
		blindDimmer6.setRoomId("room4");

		windowController1.setFloorId("floor1");
		windowController1.setRoomId("room1");
		windowController1.setWindowId("window1");

		windowController2.setFloorId("floor1");
		windowController2.setRoomId("room1");
		windowController2.setWindowId("window2");

		windowController3.setFloorId("floor1");
		windowController3.setRoomId("room2");
		windowController3.setWindowId("window3");

		windowController4.setFloorId("floor1");
		windowController4.setRoomId("room2");
		windowController4.setWindowId("window4");

		windowController5.setFloorId("floor2");
		windowController5.setRoomId("room3");
		windowController5.setWindowId("window5");

		windowController6.setFloorId("floor2");
		windowController6.setRoomId("room4");
		windowController6.setWindowId("window6");

		windowDimmer1.setFloorId("floor1");
		windowDimmer1.setRoomId("room1");
		windowDimmer1.setWindowId("window1");

		windowDimmer2.setFloorId("floor1");
		windowDimmer2.setRoomId("room1");
		windowDimmer2.setWindowId("window2");

		windowDimmer3.setFloorId("floor1");
		windowDimmer3.setRoomId("room2");
		windowDimmer3.setWindowId("window3");

		windowDimmer4.setFloorId("floor1");
		windowDimmer4.setRoomId("room2");
		windowDimmer4.setWindowId("window4");

		windowDimmer5.setFloorId("floor2");
		windowDimmer5.setRoomId("room3");
		windowDimmer5.setWindowId("window5");

		windowDimmer6.setFloorId("floor2");
		windowDimmer6.setRoomId("room4");
		windowDimmer6.setWindowId("window6");

		heater1.setHeaterId("heater1");
		enumAux=new HeatingModes();
		enumAux.setValue("Cooling");
		heater1.setMode((HeatingModes)enumAux);

		heater1.setName("main heater");
		heater1.setPower(0);
		heater1.setState(false);
		heater1.setTemperature("24");
		heater1.setThermometerId("thermometer1");

		heater2.setHeaterId("heater2");
		enumAux=new HeatingModes();
		enumAux.setValue("Cooling");
		heater2.setMode((HeatingModes)enumAux);

		heater2.setName("main heater");
		heater2.setPower(0);
		heater2.setState(false);
		heater2.setTemperature("24");
		heater2.setThermometerId("thermometer2");

		heater3.setHeaterId("heater3");
		enumAux=new HeatingModes();
		enumAux.setValue("Cooling");
		heater3.setMode((HeatingModes)enumAux);

		heater3.setName("main heater");
		heater3.setPower(0);
		heater3.setState(false);
		heater3.setTemperature("24");
		heater3.setThermometerId("thermometer3");

		heater4.setHeaterId("heater4");
		enumAux=new HeatingModes();
		enumAux.setValue("Cooling");
		heater4.setMode((HeatingModes)enumAux);

		heater4.setName("main heater");
		heater4.setPower(0);
		heater4.setState(false);
		heater4.setTemperature("24");
		heater4.setThermometerId("thermometer4");

		thermometer1.setName("main thermometer");
		thermometer1.setOutTemp("30");
		thermometer1.setTemp("25");
		thermometer1.setThermometerId("thermometer1");

		thermometer2.setName("main thermometer");
		thermometer2.setOutTemp("30");
		thermometer2.setTemp("25");
		thermometer2.setThermometerId("thermometer2");

		thermometer3.setName("main thermometer");
		thermometer3.setOutTemp("30");
		thermometer3.setTemp("25");
		thermometer3.setThermometerId("thermometer3");

		thermometer4.setName("main thermometer");
		thermometer4.setOutTemp("30");
		thermometer4.setTemp("25");
		thermometer4.setThermometerId("thermometer4");

		heatingController1.setFloorId("floor1");
		heatingController1.setHeaterId("heater1");
		heatingController1.setRoomId("room1");

		heatingController2.setFloorId("floor1");
		heatingController2.setHeaterId("heater2");
		heatingController2.setRoomId("room2");

		heatingController3.setFloorId("floor2");
		heatingController3.setHeaterId("heater3");
		heatingController3.setRoomId("room3");

		heatingController4.setFloorId("floor2");
		heatingController4.setHeaterId("heater4");
		heatingController4.setRoomId("room4");

		thermometerComp1.setFloorId("floor1");
		thermometerComp1.setRoomId("room1");
		thermometerComp1.setThermometerId("thermometer1");

		thermometerComp2.setFloorId("floor1");
		thermometerComp2.setRoomId("room2");
		thermometerComp2.setThermometerId("thermometer2");

		thermometerComp3.setFloorId("floor2");
		thermometerComp3.setRoomId("room3");
		thermometerComp3.setThermometerId("thermometer3");

		thermometerComp4.setFloorId("floor2");
		thermometerComp4.setRoomId("room4");
		thermometerComp4.setThermometerId("thermometer4");

		thermometerGUI1.setFloorId("floor1");
		thermometerGUI1.setRoomId("room1");
		thermometerGUI1.setThermometerId("thermometer1");

		thermometerGUI2.setFloorId("floor1");
		thermometerGUI2.setRoomId("room2");
		thermometerGUI2.setThermometerId("thermometer2");

		thermometerGUI3.setFloorId("floor2");
		thermometerGUI3.setRoomId("room3");
		thermometerGUI3.setThermometerId("thermometer3");

		thermometerGUI4.setFloorId("floor2");
		thermometerGUI4.setRoomId("room4");
		thermometerGUI4.setThermometerId("thermometer4");

		heaterGUI1.setFloorId("floor1");
		heaterGUI1.setHeaterId("heater1");
		heaterGUI1.setRoomId("room1");

		heaterGUI2.setFloorId("floor1");
		heaterGUI2.setHeaterId("heater2");
		heaterGUI2.setRoomId("room2");

		heaterGUI3.setFloorId("floor2");
		heaterGUI3.setHeaterId("heater3");
		heaterGUI3.setRoomId("room3");

		heaterGUI4.setFloorId("floor2");
		heaterGUI4.setHeaterId("heater4");
		heaterGUI4.setRoomId("room4");

		houseGateway1.getServices().connectPort(roomGUI1.getGui());
		houseGateway1.getServices().connectPort(roomGUI1.getRequest());
		houseGateway1.getServices().connectPort(roomGUI2.getGui());
		houseGateway1.getServices().connectPort(roomGUI2.getRequest());
		houseGateway1.getServices().connectPort(roomGUI3.getGui());
		houseGateway1.getServices().connectPort(roomGUI3.getRequest());
		houseGateway1.getServices().connectPort(roomGUI4.getGui());
		houseGateway1.getServices().connectPort(roomGUI4.getRequest());
		houseGateway1.getServices().connectPort(centralGUI1.getRequest());
		houseGateway1.getServices().connectPort(centralGUI1.getGui());
		houseGateway1.getServices().connectPort(floorGUI1.getRequest());
		houseGateway1.getServices().connectPort(floorGUI1.getGui());
		houseGateway1.getServices().connectPort(floorGUI2.getRequest());
		houseGateway1.getServices().connectPort(floorGUI2.getGui());
		centralGUI1.getLightNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI1.getLightNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI2.getLightNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI1.getLightNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI2.getLightNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI3.getLightNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI4.getLightNotifyPort().connectPort(houseGateway1.getActuators());
		houseGateway1.getServices().connectPort(lightGUI1.getRequest());
		houseGateway1.getServices().connectPort(lightGUI2.getRequest());
		houseGateway1.getServices().connectPort(lightGUI3.getRequest());
		houseGateway1.getServices().connectPort(lightGUI4.getRequest());
		houseGateway1.getServices().connectPort(lightGUI5.getRequest());
		houseGateway1.getServices().connectPort(lightGUI6.getRequest());
		lightGUI1.getServices().connectPort(houseGateway1.getActuators());
		lightGUI2.getServices().connectPort(houseGateway1.getActuators());
		lightGUI3.getServices().connectPort(houseGateway1.getActuators());
		lightGUI4.getServices().connectPort(houseGateway1.getActuators());
		lightGUI5.getServices().connectPort(houseGateway1.getActuators());
		lightGUI6.getServices().connectPort(houseGateway1.getActuators());
		houseGateway1.getActuators().connectPort(lightController1.getRequest());
		houseGateway1.getActuators().connectPort(lightController2.getRequest());
		houseGateway1.getActuators().connectPort(lightController3.getRequest());
		houseGateway1.getActuators().connectPort(lightController4.getRequest());
		houseGateway1.getActuators().connectPort(lightController5.getRequest());
		houseGateway1.getActuators().connectPort(lightController6.getRequest());
		houseGateway1.getActuators().connectPort(switch1.getRequest());
		houseGateway1.getActuators().connectPort(switch2.getRequest());
		houseGateway1.getActuators().connectPort(switch3.getRequest());
		houseGateway1.getActuators().connectPort(switch4.getRequest());
		houseGateway1.getActuators().connectPort(switch5.getRequest());
		houseGateway1.getActuators().connectPort(switch6.getRequest());
		switch1.getRequest().connectPort(houseGateway1.getSensors());
		switch2.getRequest().connectPort(houseGateway1.getSensors());
		switch3.getRequest().connectPort(houseGateway1.getSensors());
		switch4.getRequest().connectPort(houseGateway1.getSensors());
		switch5.getRequest().connectPort(houseGateway1.getSensors());
		switch6.getRequest().connectPort(houseGateway1.getSensors());
		houseGateway1.getActuators().connectPort(dimmer1.getRequest());
		houseGateway1.getActuators().connectPort(dimmer2.getRequest());
		houseGateway1.getActuators().connectPort(dimmer3.getRequest());
		houseGateway1.getActuators().connectPort(dimmer4.getRequest());
		houseGateway1.getActuators().connectPort(dimmer5.getRequest());
		houseGateway1.getActuators().connectPort(dimmer6.getRequest());
		dimmer1.getRequest().connectPort(houseGateway1.getSensors());
		dimmer2.getRequest().connectPort(houseGateway1.getSensors());
		dimmer3.getRequest().connectPort(houseGateway1.getSensors());
		dimmer4.getRequest().connectPort(houseGateway1.getSensors());
		dimmer5.getRequest().connectPort(houseGateway1.getSensors());
		dimmer6.getRequest().connectPort(houseGateway1.getSensors());
		windowGUI1.getServices().connectPort(houseGateway1.getActuators());
		windowGUI2.getServices().connectPort(houseGateway1.getActuators());
		windowGUI3.getServices().connectPort(houseGateway1.getActuators());
		windowGUI4.getServices().connectPort(houseGateway1.getActuators());
		windowGUI5.getServices().connectPort(houseGateway1.getActuators());
		windowGUI6.getServices().connectPort(houseGateway1.getActuators());
		houseGateway1.getServices().connectPort(windowGUI1.getRequest());
		houseGateway1.getServices().connectPort(windowGUI2.getRequest());
		houseGateway1.getServices().connectPort(windowGUI4.getRequest());
		houseGateway1.getServices().connectPort(windowGUI5.getRequest());
		houseGateway1.getServices().connectPort(windowGUI6.getRequest());
		houseGateway1.getServices().connectPort(windowGUI3.getRequest());
		houseGateway1.getServices().connectPort(blindGUI1.getRequest());
		houseGateway1.getServices().connectPort(blindGUI2.getRequest());
		houseGateway1.getServices().connectPort(blindGUI3.getRequest());
		houseGateway1.getServices().connectPort(blindGUI4.getRequest());
		houseGateway1.getServices().connectPort(blindGUI5.getRequest());
		houseGateway1.getServices().connectPort(blindGUI6.getRequest());
		blindGUI1.getServices().connectPort(houseGateway1.getActuators());
		blindGUI2.getServices().connectPort(houseGateway1.getActuators());
		blindGUI3.getServices().connectPort(houseGateway1.getActuators());
		blindGUI4.getServices().connectPort(houseGateway1.getActuators());
		blindGUI5.getServices().connectPort(houseGateway1.getActuators());
		blindGUI6.getServices().connectPort(houseGateway1.getActuators());
		centralGUI1.getWindowNotifyPort().connectPort(houseGateway1.getActuators());
		centralGUI1.getBlindNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI1.getWindowNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI1.getBlindNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI2.getWindowNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI2.getBlindNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI1.getWindowNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI1.getBlindNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI2.getWindowNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI2.getBlindNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI3.getWindowNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI3.getBlindNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI4.getWindowNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI4.getBlindNotifyPort().connectPort(houseGateway1.getActuators());
		windowDimmer1.getRequest().connectPort(houseGateway1.getSensors());
		windowDimmer2.getRequest().connectPort(houseGateway1.getSensors());
		windowDimmer3.getRequest().connectPort(houseGateway1.getSensors());
		windowDimmer4.getRequest().connectPort(houseGateway1.getSensors());
		windowDimmer5.getRequest().connectPort(houseGateway1.getSensors());
		windowDimmer6.getRequest().connectPort(houseGateway1.getSensors());
		houseGateway1.getActuators().connectPort(windowDimmer1.getRequest());
		houseGateway1.getActuators().connectPort(windowDimmer2.getRequest());
		houseGateway1.getActuators().connectPort(windowDimmer3.getRequest());
		houseGateway1.getActuators().connectPort(windowDimmer4.getRequest());
		houseGateway1.getActuators().connectPort(windowDimmer5.getRequest());
		houseGateway1.getActuators().connectPort(windowDimmer6.getRequest());
		blindDimmer1.getRequest().connectPort(houseGateway1.getSensors());
		blindDimmer2.getRequest().connectPort(houseGateway1.getSensors());
		blindDimmer3.getRequest().connectPort(houseGateway1.getSensors());
		blindDimmer4.getRequest().connectPort(houseGateway1.getSensors());
		blindDimmer5.getRequest().connectPort(houseGateway1.getSensors());
		blindDimmer6.getRequest().connectPort(houseGateway1.getSensors());
		houseGateway1.getActuators().connectPort(blindDimmer1.getRequest());
		houseGateway1.getActuators().connectPort(blindDimmer2.getRequest());
		houseGateway1.getActuators().connectPort(blindDimmer3.getRequest());
		houseGateway1.getActuators().connectPort(blindDimmer4.getRequest());
		houseGateway1.getActuators().connectPort(blindDimmer5.getRequest());
		houseGateway1.getActuators().connectPort(blindDimmer6.getRequest());
		houseGateway1.getActuators().connectPort(windowController1.getRequest());
		houseGateway1.getActuators().connectPort(windowController2.getRequest());
		houseGateway1.getActuators().connectPort(windowController3.getRequest());
		houseGateway1.getActuators().connectPort(windowController4.getRequest());
		houseGateway1.getActuators().connectPort(windowController5.getRequest());
		houseGateway1.getActuators().connectPort(windowController6.getRequest());
		houseGateway1.getActuators().connectPort(blindController1.getRequest());
		houseGateway1.getActuators().connectPort(blindController2.getRequest());
		houseGateway1.getActuators().connectPort(blindController3.getRequest());
		houseGateway1.getActuators().connectPort(blindController4.getRequest());
		houseGateway1.getActuators().connectPort(blindController5.getRequest());
		houseGateway1.getActuators().connectPort(blindController6.getRequest());
		houseGateway1.getActuators().connectPort(heatingController1.getRequest());
		houseGateway1.getActuators().connectPort(heatingController2.getRequest());
		houseGateway1.getActuators().connectPort(heatingController3.getRequest());
		houseGateway1.getActuators().connectPort(heatingController4.getRequest());
		thermometerComp1.getRequest().connectPort(houseGateway1.getSensors());
		houseGateway1.getActuators().connectPort(thermometerComp1.getRequest());
		houseGateway1.getActuators().connectPort(thermometerComp2.getRequest());
		thermometerComp2.getRequest().connectPort(houseGateway1.getSensors());
		houseGateway1.getActuators().connectPort(thermometerComp3.getRequest());
		thermometerComp3.getRequest().connectPort(houseGateway1.getSensors());
		houseGateway1.getActuators().connectPort(thermometerComp4.getRequest());
		thermometerComp4.getRequest().connectPort(houseGateway1.getSensors());
		houseGateway1.getActuators().connectPort(heaterGUI1.getRequest());
		houseGateway1.getActuators().connectPort(heaterGUI2.getRequest());
		houseGateway1.getActuators().connectPort(heaterGUI3.getRequest());
		houseGateway1.getActuators().connectPort(heaterGUI4.getRequest());
		houseGateway1.getActuators().connectPort(thermometerGUI1.getRequest());
		houseGateway1.getActuators().connectPort(thermometerGUI2.getRequest());
		houseGateway1.getActuators().connectPort(thermometerGUI3.getRequest());
		houseGateway1.getActuators().connectPort(thermometerGUI4.getRequest());
		heaterGUI1.getServices().connectPort(houseGateway1.getServices());
		heaterGUI2.getServices().connectPort(houseGateway1.getServices());
		heaterGUI3.getServices().connectPort(houseGateway1.getServices());
		heaterGUI4.getServices().connectPort(houseGateway1.getServices());
		centralGUI1.getHeaterNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI1.getHeaterNotifyPort().connectPort(houseGateway1.getActuators());
		floorGUI2.getHeaterNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI1.getHeaterNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI2.getHeaterNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI3.getHeaterNotifyPort().connectPort(houseGateway1.getActuators());
		roomGUI4.getHeaterNotifyPort().connectPort(houseGateway1.getActuators());
		houseGateway1.getSmartEnergyNotifyPort().connectPort(centralGUI1.getSmartEnergyNotifyPort());
		houseGateway1.getSmartEnergyNotifyPort().connectPort(floorGUI1.getSmartEnergyNotifyPort());
		houseGateway1.getSmartEnergyNotifyPort().connectPort(floorGUI2.getSmartEnergyNotifyPort());
		houseGateway1.getSmartEnergyNotifyPort().connectPort(roomGUI1.getSmartEnergyNotifyPort());
		houseGateway1.getSmartEnergyNotifyPort().connectPort(roomGUI2.getSmartEnergyNotifyPort());
		houseGateway1.getSmartEnergyNotifyPort().connectPort(roomGUI3.getSmartEnergyNotifyPort());
		houseGateway1.getSmartEnergyNotifyPort().connectPort(roomGUI4.getSmartEnergyNotifyPort());
		centralGUI1.getSmartEnergyPort().connectPort(houseGateway1.getSmartEnergyPort());
		floorGUI1.getSmartEnergyPort().connectPort(houseGateway1.getSmartEnergyPort());
		floorGUI2.getSmartEnergyPort().connectPort(houseGateway1.getSmartEnergyPort());
		roomGUI1.getSmartEnergyPort().connectPort(houseGateway1.getSmartEnergyPort());
		roomGUI2.getSmartEnergyPort().connectPort(houseGateway1.getSmartEnergyPort());
		roomGUI3.getSmartEnergyPort().connectPort(houseGateway1.getSmartEnergyPort());
		roomGUI4.getSmartEnergyPort().connectPort(houseGateway1.getSmartEnergyPort());


		centralGUI1.init();
		floorGUI1.init();
		floorGUI2.init();
		roomGUI1.init();
		houseGateway1.init();
		roomGUI2.init();
		roomGUI3.init();
		roomGUI4.init();
		lightGUI1.init();
		lightGUI2.init();
		lightGUI3.init();
		lightGUI4.init();
		lightGUI5.init();
		lightGUI6.init();
		lightController1.init();
		lightController2.init();
		lightController3.init();
		lightController4.init();
		lightController5.init();
		lightController6.init();
		switch1.init();
		switch2.init();
		switch3.init();
		switch4.init();
		switch5.init();
		switch6.init();
		dimmer1.init();
		dimmer2.init();
		dimmer3.init();
		dimmer4.init();
		dimmer5.init();
		dimmer6.init();
		windowGUI1.init();
		windowGUI2.init();
		windowGUI3.init();
		windowGUI4.init();
		windowGUI5.init();
		windowGUI6.init();
		blindGUI1.init();
		blindGUI2.init();
		blindGUI3.init();
		blindGUI4.init();
		blindGUI5.init();
		blindGUI6.init();
		blindController1.init();
		blindController2.init();
		blindController3.init();
		blindController4.init();
		blindController5.init();
		blindController6.init();
		blindDimmer1.init();
		blindDimmer2.init();
		blindDimmer3.init();
		blindDimmer4.init();
		blindDimmer5.init();
		blindDimmer6.init();
		windowController1.init();
		windowController2.init();
		windowController3.init();
		windowController4.init();
		windowController5.init();
		windowController6.init();
		windowDimmer1.init();
		windowDimmer2.init();
		windowDimmer3.init();
		windowDimmer4.init();
		windowDimmer5.init();
		windowDimmer6.init();
		heatingController1.init();
		heatingController2.init();
		heatingController3.init();
		heatingController4.init();
		thermometerComp1.init();
		thermometerComp2.init();
		thermometerComp3.init();
		thermometerComp4.init();
		thermometerGUI1.init();
		thermometerGUI2.init();
		thermometerGUI3.init();
		thermometerGUI4.init();
		heaterGUI1.init();
		heaterGUI2.init();
		heaterGUI3.init();
		heaterGUI4.init();
	}
	
	public static void main (String [] args){
		MyHouse finalProduct=new MyHouse();
	}
}