using System;
using System.Collections;
using System.Text;

namespace SmartHome
{
	public interface IGUI
	{
		void showGUI();
		void initGUI();

	}
}
