using System;
using System.Collections;
using System.Text;

namespace SmartHome
{
	public interface IBlindNotifiy
	{
		void changeBlindAperture(String blindId, int value);

	}
}
