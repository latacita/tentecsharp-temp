package smartEnergyControl;
import windowManagement.*;
import heaterManagement.*;

import java.util.ArrayList; 
		
public cclass SmartEnergyControl extends  WindowManagement & HeaterManagement {
	public SmartEnergyControl (){
		super();
	}
}