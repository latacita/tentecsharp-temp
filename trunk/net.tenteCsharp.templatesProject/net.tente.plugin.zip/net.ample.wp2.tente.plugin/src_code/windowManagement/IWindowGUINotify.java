package windowManagement;
import windowManagement.WindowManagement.*;

public interface IWindowGUINotify{
	
	public void changeWindowAperture(String windowId,int value);

}
