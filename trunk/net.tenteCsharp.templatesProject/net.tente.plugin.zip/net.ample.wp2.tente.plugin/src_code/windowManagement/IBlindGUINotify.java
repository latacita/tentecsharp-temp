package windowManagement;
import windowManagement.WindowManagement.*;

public interface IBlindGUINotify{
	
	public void changeBlindAperture(String blindId,int value);

}
