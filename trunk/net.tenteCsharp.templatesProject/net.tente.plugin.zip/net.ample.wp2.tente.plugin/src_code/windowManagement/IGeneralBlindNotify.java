package windowManagement;
import windowManagement.WindowManagement.*;

public interface IGeneralBlindNotify{
	
	public void changeAllBlindsAperture(int aperture,String floorId,String roomId);

}
