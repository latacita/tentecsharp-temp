package windowManagement;
import windowManagement.WindowManagement.*;

public interface IBlindNotifiy{
	
	public void changeBlindAperture(String blindId,int value);

}
