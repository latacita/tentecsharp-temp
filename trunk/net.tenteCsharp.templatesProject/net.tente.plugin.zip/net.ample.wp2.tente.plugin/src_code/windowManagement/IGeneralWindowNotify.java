package windowManagement;
import windowManagement.WindowManagement.*;

public interface IGeneralWindowNotify{
	
	public void changeAllWindowsAperture(int aperture,String floorId,String roomId);

}
