package windowManagement;
import windowManagement.WindowManagement.*;

public interface IWindowNotifiy{
	
	public void changeWindowAperture(String windowId,int value);

}
