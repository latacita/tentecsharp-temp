package windowManagement;
import initialModel.*;

import java.util.ArrayList; 
		
public cclass WindowManagement extends  InitialModel {
	public WindowManagement (){
		super();
	}
}