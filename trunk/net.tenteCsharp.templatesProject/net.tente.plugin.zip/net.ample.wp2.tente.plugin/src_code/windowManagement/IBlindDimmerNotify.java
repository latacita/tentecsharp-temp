package windowManagement;
import windowManagement.WindowManagement.*;

public interface IBlindDimmerNotify{
	
	public void blindDimmerValueChanged(int value,String blindId);

}
