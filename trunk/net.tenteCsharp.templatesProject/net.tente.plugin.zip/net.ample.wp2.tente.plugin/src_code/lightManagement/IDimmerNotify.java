package lightManagement;
import lightManagement.LightManagement.*;

public interface IDimmerNotify{
	
	public void dimmerValueChanged(String lightId,int value);

}
