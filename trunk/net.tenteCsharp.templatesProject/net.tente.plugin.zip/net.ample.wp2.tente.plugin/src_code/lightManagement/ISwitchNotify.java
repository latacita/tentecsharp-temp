package lightManagement;
import lightManagement.LightManagement.*;

public interface ISwitchNotify{
	
	public void switchValueChanged(String lightId,SwitchStatus value);

}
