package initialModel;
import initialModel.InitialModel.*;

public interface IDevice{
	
	public String getId();	
	public void setRoomId(String roomId);	
	public String getRoomId();	
	public void setFloorId(String floorId);	
	public String getFloorId();

}
