package initialModel;
import initialModel.InitialModel.*;

public interface INotify{
	
	public String getId();

}
