package initialModel;
import initialModel.InitialModel.*;

public interface IGUI{
	
	public void showGUI();	
	public void initGUI();

}
