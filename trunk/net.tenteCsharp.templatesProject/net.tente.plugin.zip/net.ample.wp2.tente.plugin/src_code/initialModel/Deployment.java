cclass initialModel.InitialModel;

public cclass Deployment extends TypeEnum {
	
	public Deployment (){
		super();		
		values.add("Lightweight");		
		values.add("Heavyweight");
	}
	
}