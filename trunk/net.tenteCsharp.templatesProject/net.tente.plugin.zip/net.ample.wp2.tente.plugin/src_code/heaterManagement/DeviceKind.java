cclass heaterManagement.HeaterManagement;

public cclass DeviceKind extends TypeEnum {
	
	public DeviceKind (){
		super();		
		values.add("Heating");		
		values.add("Thermometer");
	}
	
}