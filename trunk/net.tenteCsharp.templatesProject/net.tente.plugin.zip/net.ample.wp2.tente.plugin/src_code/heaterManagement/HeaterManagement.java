package heaterManagement;
import initialModel.*;

import java.util.ArrayList; 
		
public cclass HeaterManagement extends  InitialModel {
	public HeaterManagement (){
		super();
	}
}