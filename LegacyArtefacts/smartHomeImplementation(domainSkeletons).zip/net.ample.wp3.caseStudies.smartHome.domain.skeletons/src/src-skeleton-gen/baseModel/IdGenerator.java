package initialModel;
/**
 * Static class used to create unique identifiers for the component instances 
 * @author Carlos Nebrera Cuevas
 */
public class IdGenerator {
	
	private static int actualInstance=0;
	
	/**
	 * Method that returns a unique identifier by attaching the given base String with a number that
	 * is increased each time the method is called. The base string is given to help in the identification
	 * of the component 
	 * 
	 * @param base The base String for the identifier
	 * @return A String with the full identifier
	 */
	public static String getId(String base){
		actualInstance+=1;
		return ""+base+"_"+Integer.toString(actualInstance);
	}
}