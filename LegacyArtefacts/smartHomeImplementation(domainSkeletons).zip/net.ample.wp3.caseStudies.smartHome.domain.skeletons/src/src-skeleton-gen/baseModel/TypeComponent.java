cclass initialModel.InitialModel;

public cclass TypeComponent {
	public String id;
	public TypeComponent(String id){
		this.id=id;
	}
	public String getID(){
		return id;
	}
	//Method that initializate the component
	public void init(){}
	public cclass TypePort{
		public TypeComponent comp;
		public TypePort(TypeComponent comp){
			this.comp=comp;
		}
	}
}
