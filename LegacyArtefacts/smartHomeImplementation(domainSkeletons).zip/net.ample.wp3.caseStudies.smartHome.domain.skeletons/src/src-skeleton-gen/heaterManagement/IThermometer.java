package heaterManagement;

public interface IThermometer{
	
	public float getTemparature(String thermometerId);	
	public float getOutdoorTemparature(String thermometerId);

}
