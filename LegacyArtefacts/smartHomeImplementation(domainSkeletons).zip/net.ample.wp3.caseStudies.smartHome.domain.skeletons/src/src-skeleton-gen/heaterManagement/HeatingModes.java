cclass heaterManagement.HeaterManagement;

public cclass HeatingModes extends TypeEnum {
	
	public HeatingModes (){
		super();		
		values.add("Heating");		
		values.add("Cooling");
	}
	
}