cclass initialModel.InitialModel; 

public cclass CentralGUI extends TypeComponent{

	public NotifyPort request;
	public GUIPort gui;
	public String houseId;
	public ArrayList floorGUIs;

	
	public CentralGUI (String id){
		super(id);
	}
	
	public NotifyPort getRequest(){
		return request;
	}
	
	public void setRequest(NotifyPort value){
		this.request=value;
	}
	
	public GUIPort getGui(){
		return gui;
	}
	
	public void setGui(GUIPort value){
		this.gui=value;
	}
	
	public String getHouseId(){
		return houseId;
	}
	
	public void setHouseId(String value){
		this.houseId=value;
	}
	
	public ArrayList getFloorGUIs(){
		return floorGUIs;
	}
	
	public void setFloorGUIs(ArrayList value){
		this.floorGUIs=value;
	}
	
	public void addFloorGUIsElement(FloorGUI value){
		this.floorGUIs.add(value);
	}
	
	
	
	public cclass NotifyPort extends TypePort implements INotify{


		public NotifyPort (TypeComponent comp){
			super(comp);

		}

		public String getId(){
		
		}

	}	
	
	public cclass GUIPort extends TypePort implements IGUI{


		public GUIPort (TypeComponent comp){
			super(comp);

		}

		public void showGUI(){
		
		}

		public void initGUI(){
		
		}

	}

}