package initialModel;

public interface INotify{
	
	public String getId();

}
