package initialModel;
import baseModel.*;
import java.util.ArrayList; 
		
public cclass InitialModel extends BaseModel{
	public InitialModel (){
		super();
	}
}