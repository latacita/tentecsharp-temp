cclass initialModel.InitialModel;

public cclass DeviceKind extends TypeEnum {
	
	public DeviceKind (){
		super();
	}
	
}