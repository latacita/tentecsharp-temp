package lightManagement;

public interface IDimmerNotify{
	
	public void dimmerValueChanged(String lightId,int value);

}
