package lightManagement;

public interface ISwitchNotify{
	
	public void switchValueChanged(String lightId,SwitchStatus value);

}
