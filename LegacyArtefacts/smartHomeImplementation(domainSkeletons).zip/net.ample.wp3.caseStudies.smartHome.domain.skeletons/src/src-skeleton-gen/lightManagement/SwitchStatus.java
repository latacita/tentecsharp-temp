cclass lightManagement.LightManagement;

public cclass SwitchStatus extends TypeEnum {
	
	public SwitchStatus (){
		super();		
		values.add("SwitchOn");		
		values.add("SwitchOff");
	}
	
}