package lightManagement;
import initialModel.*;

import java.util.ArrayList; 
		
public cclass LightManagement extends  InitialModel {
	public LightManagement (){
		super();
	}
}