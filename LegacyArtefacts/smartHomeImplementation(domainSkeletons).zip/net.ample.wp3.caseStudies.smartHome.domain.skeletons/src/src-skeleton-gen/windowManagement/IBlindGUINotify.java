package windowManagement;

public interface IBlindGUINotify{
	
	public void changeBlindAperture(String blindId,int value);

}
