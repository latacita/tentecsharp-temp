cclass windowManagement.WindowManagement; 

public cclass RoomGUI extends TypeComponent{

	public BlindNotifyPort blindNotifyPort;
	public WindowNotifyPort windowNotifyPort;
	public ArrayList listWindowGUI;
	public ArrayList listBlindGUI;

	
	public RoomGUI (String id){
		super(id);
	}
	
	public BlindNotifyPort getBlindNotifyPort(){
		return blindNotifyPort;
	}
	
	public void setBlindNotifyPort(BlindNotifyPort value){
		this.blindNotifyPort=value;
	}
	
	public WindowNotifyPort getWindowNotifyPort(){
		return windowNotifyPort;
	}
	
	public void setWindowNotifyPort(WindowNotifyPort value){
		this.windowNotifyPort=value;
	}
	
	public ArrayList getListWindowGUI(){
		return listWindowGUI;
	}
	
	public void setListWindowGUI(ArrayList value){
		this.listWindowGUI=value;
	}
	
	public void addListWindowGUIElement(WindowGUI value){
		this.listWindowGUI.add(value);
	}
	
	public ArrayList getListBlindGUI(){
		return listBlindGUI;
	}
	
	public void setListBlindGUI(ArrayList value){
		this.listBlindGUI=value;
	}
	
	public void addListBlindGUIElement(BlindGUI value){
		this.listBlindGUI.add(value);
	}
	
	
	
	public cclass WindowNotifyPort extends TypePort{

		public ArrayList portsIGeneralWindowNotify;

		public WindowNotifyPort (TypeComponent comp){
			super(comp);
			portsIGeneralWindowNotify=new ArrayList();

		}

			
		public void connectPort(IGeneralWindowNotify port){
			portsIGeneralWindowNotify.add(port);
		}
	}	
	
	public cclass BlindNotifyPort extends TypePort{

		public ArrayList portsIGeneralBlindNotify;

		public BlindNotifyPort (TypeComponent comp){
			super(comp);
			portsIGeneralBlindNotify=new ArrayList();

		}

			
		public void connectPort(IGeneralBlindNotify port){
			portsIGeneralBlindNotify.add(port);
		}
	}

}