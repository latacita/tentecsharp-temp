cclass windowManagement.WindowManagement; 

public cclass BlindController extends TypeComponent{

	public BlindControllerPort request;
	public String floorId;
	public String blindId;
	public String roomId;

	
	public BlindController (String id){
		super(id);
	}
	
	public BlindControllerPort getRequest(){
		return request;
	}
	
	public void setRequest(BlindControllerPort value){
		this.request=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getBlindId(){
		return blindId;
	}
	
	public void setBlindId(String value){
		this.blindId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	
	
	public cclass BlindControllerPort extends TypePort implements IBlindController{


		public BlindControllerPort (TypeComponent comp){
			super(comp);

		}

		public int getAperture(){
		
		}

		public void setAperture(int value){
		
		}

		public String getBlindId(){
		
		}

	}

}