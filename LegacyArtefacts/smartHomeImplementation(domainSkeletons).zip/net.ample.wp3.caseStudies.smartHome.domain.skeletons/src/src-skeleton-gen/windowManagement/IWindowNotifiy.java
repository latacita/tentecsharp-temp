package windowManagement;

public interface IWindowNotifiy{
	
	public void changeWindowAperture(String windowId,int value);

}
