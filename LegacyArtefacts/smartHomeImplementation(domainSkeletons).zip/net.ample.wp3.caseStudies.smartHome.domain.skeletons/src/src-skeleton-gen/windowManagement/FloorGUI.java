cclass windowManagement.WindowManagement; 

public cclass FloorGUI extends TypeComponent{

	public BlindNotifyPort blindNotifyPort;
	public WindowNotifyPort windowNotifyPort;

	
	public FloorGUI (String id){
		super(id);
	}
	
	public BlindNotifyPort getBlindNotifyPort(){
		return blindNotifyPort;
	}
	
	public void setBlindNotifyPort(BlindNotifyPort value){
		this.blindNotifyPort=value;
	}
	
	public WindowNotifyPort getWindowNotifyPort(){
		return windowNotifyPort;
	}
	
	public void setWindowNotifyPort(WindowNotifyPort value){
		this.windowNotifyPort=value;
	}
	
	
	
	public cclass WindowNotifyPort extends TypePort{

		public ArrayList portsIGeneralWindowNotify;

		public WindowNotifyPort (TypeComponent comp){
			super(comp);
			portsIGeneralWindowNotify=new ArrayList();

		}

			
		public void connectPort(IGeneralWindowNotify port){
			portsIGeneralWindowNotify.add(port);
		}
	}	
	
	public cclass BlindNotifyPort extends TypePort{

		public ArrayList portsIGeneralBlindNotify;

		public BlindNotifyPort (TypeComponent comp){
			super(comp);
			portsIGeneralBlindNotify=new ArrayList();

		}

			
		public void connectPort(IGeneralBlindNotify port){
			portsIGeneralBlindNotify.add(port);
		}
	}

}