cclass windowManagement.WindowManagement; 

public cclass WindowDimmer extends TypeComponent{

	public WindowDimmerPort request;
	public String floorId;
	public String windowId;
	public String roomId;

	
	public WindowDimmer (String id){
		super(id);
	}
	
	public WindowDimmerPort getRequest(){
		return request;
	}
	
	public void setRequest(WindowDimmerPort value){
		this.request=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getWindowId(){
		return windowId;
	}
	
	public void setWindowId(String value){
		this.windowId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	
	
	public cclass WindowDimmerPort extends TypePort implements IWindowDimmer{

		public ArrayList portsIWindowDimmerNotify;

		public WindowDimmerPort (TypeComponent comp){
			super(comp);
			portsIWindowDimmerNotify=new ArrayList();

		}

		public int getAperture(){
		
		}

		public void setAperture(int value){
		
		}

		public String getWindowId(){
		
		}

			
		public void connectPort(IWindowDimmerNotify port){
			portsIWindowDimmerNotify.add(port);
		}
	}

}