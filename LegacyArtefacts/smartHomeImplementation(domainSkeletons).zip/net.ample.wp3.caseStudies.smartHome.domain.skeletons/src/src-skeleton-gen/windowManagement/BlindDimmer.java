cclass windowManagement.WindowManagement; 

public cclass BlindDimmer extends TypeComponent{

	public BlindDimmerPort request;
	public String floorId;
	public String blindId;
	public String roomId;

	
	public BlindDimmer (String id){
		super(id);
	}
	
	public BlindDimmerPort getRequest(){
		return request;
	}
	
	public void setRequest(BlindDimmerPort value){
		this.request=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getBlindId(){
		return blindId;
	}
	
	public void setBlindId(String value){
		this.blindId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	
	
	public cclass BlindDimmerPort extends TypePort implements IBlindDimmer{

		public ArrayList portsIBlindDimmerNotify;

		public BlindDimmerPort (TypeComponent comp){
			super(comp);
			portsIBlindDimmerNotify=new ArrayList();

		}

		public int getAperture(){
		
		}

		public void setAperture(int value){
		
		}

		public String getBlindId(){
		
		}

			
		public void connectPort(IBlindDimmerNotify port){
			portsIBlindDimmerNotify.add(port);
		}
	}

}