package windowManagement;

public interface IGeneralWindowNotify{
	
	public void changeAllWindowsAperture(int aperture,String floorId,String roomId);

}
