package windowManagement;

public interface IBlindNotifiy{
	
	public void changeBlindAperture(String blindId,int value);

}
