package windowManagement;

public interface IBlindDimmerNotify{
	
	public void blindDimmerValueChanged(int value,String blindId);

}
