cclass smartEnergyControl.SmartEnergyControl; 

public cclass HouseGateway extends TypeComponent{

	public SmartPort smartEnergyPort;
	public SmartNotifyPort smartEnergyNotifyPort;

	
	public HouseGateway (String id){
		super(id);
	}
	
	public SmartPort getSmartEnergyPort(){
		return smartEnergyPort;
	}
	
	public void setSmartEnergyPort(SmartPort value){
		this.smartEnergyPort=value;
	}
	
	public SmartNotifyPort getSmartEnergyNotifyPort(){
		return smartEnergyNotifyPort;
	}
	
	public void setSmartEnergyNotifyPort(SmartNotifyPort value){
		this.smartEnergyNotifyPort=value;
	}
	
	
	
	public cclass Room {
		public boolean smartControlActive;

		public Room (){
				
		}
		public boolean getSmartControlActive(){
			return smartControlActive;
		}
	
		public void setSmartControlActive(boolean value){
			this.smartControlActive=value;
		}
	



	}
	
	public Room getRoomInstance(String id){
		Room room=new Room(id);
		return room;
	}	
	
	public cclass Floor {
		public boolean smartControlActive;

		public Floor (){
				
		}
		public boolean getSmartControlActive(){
			return smartControlActive;
		}
	
		public void setSmartControlActive(boolean value){
			this.smartControlActive=value;
		}
	



	}
	
	public Floor getFloorInstance(String id){
		Floor floor=new Floor(id);
		return floor;
	}	
	
	public cclass House {
		public boolean smartControlActive;

		public House (){
				
		}
		public boolean getSmartControlActive(){
			return smartControlActive;
		}
	
		public void setSmartControlActive(boolean value){
			this.smartControlActive=value;
		}
	



	}
	
	public House getHouseInstance(String id){
		House house=new House(id);
		return house;
	}	
	
	public cclass SmartPort extends TypePort implements ISmartEnergy{


		public SmartPort (TypeComponent comp){
			super(comp);

		}

		public void activateSmartControl(String floorId,String roomId){
		
		}

		public void deactivateSmartControl(String floorId,String roomId){
		
		}

	}	
	
	public cclass SmartNotifyPort extends TypePort{

		public ArrayList portsISmartEnergyNotify;

		public SmartNotifyPort (TypeComponent comp){
			super(comp);
			portsISmartEnergyNotify=new ArrayList();

		}

			
		public void connectPort(ISmartEnergyNotify port){
			portsISmartEnergyNotify.add(port);
		}
	}

}