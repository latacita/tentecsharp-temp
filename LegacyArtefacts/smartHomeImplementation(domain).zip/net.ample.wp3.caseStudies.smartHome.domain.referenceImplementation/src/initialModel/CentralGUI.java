cclass initialModel.InitialModel;
import javax.swing.*;

public cclass CentralGUI extends TypeComponent {
    
	public String houseId;
	
	//Visual elements for the GUI, to wrap java Swing
	public CentralGUIPanel visualGUI;
	
	//Swing frame, it is used to show the GUI in a separate frame.
	public JFrame frame;
	
    public Deployment dep;
    public NotifyPort request;
    public GUIPort gui;
    
    //List of floorGUIs that are inside the central one
    public ArrayList floorGUIs;

	public CentralGUI(String id) {
        super(id);
    	dep=new Deployment();
        request=new NotifyPort();
        gui=new GUIPort();
        visualGUI=new CentralGUIPanel("CentralGUI: "+id);
        floorGUIs=new ArrayList();
    }
    
	public void setHouseId(String value){
		this.houseId=value;
	}
	
	public String getHouseId(){
		return houseId;
	}
	
	//Method to add a FloorGUI to the ones controlled by the CentralGUI
	public void addFloorGUIsElement(FloorGUI fgui){
		//First the new GUI component is added to the list
		floorGUIs.add(fgui);
		//Second it is necessary to add it too into the swing visual gui components
		visualGUI.addFloorGUI(fgui.getVisualGUI());
	}
	
    public CentralGUIPanel getVisualGUI() {
		return visualGUI;
	}

	public void setVisualGui(CentralGUIPanel visualGUI) {
		this.visualGUI = visualGUI;
	}
	
	public JFrame getFrame() {
		return frame;
	}    
	
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	
	public GUIPort getGui() {
		return gui;
	}
    
    public void setDep (Deployment value){
        dep=value;
    }
    
    public Deployment getDep(){
        return dep;
    }
    
    public NotifyPort getRequest(){
        return request;
    }
    
    public cclass GUIPort extends TypePort implements IGUI {
    	
    	public GUIPort(){
    		super();
    	}
    	
    	public void showGUI(){
    		CentralGUI.this.getFrame().setSize(800,600);
    		CentralGUI.this.getFrame().setVisible(true);
    	}
    	
    	public void initGUI(){
    		JFrame newFrame=new JFrame("Smart Home Central GUI");
    		newFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    		java.net.URL imgURL = getClass().getResource("/visual/icons/house20.png");
    		if(imgURL!=null){
    			java.awt.Image icon = java.awt.Toolkit.getDefaultToolkit().getImage(imgURL);
        		newFrame.setIconImage(icon);
    		}else{
    			System.err.println("Couldn't find file: /visual/icons/house20.png");
    		}
    		
    		CentralGUI.this.setFrame(newFrame);
    		CentralGUI.this.getFrame().getContentPane().add(visualGUI);
    		
    	}
    	
    	/** Returns an ImageIcon, or null if the path was invalid. */
    	protected ImageIcon createImageIcon(String path) {
    		java.net.URL imgURL = getClass().getResource(path);
    		if (imgURL != null) {
    			return new ImageIcon(imgURL);
    		} else {
    			System.err.println("Couldn't find file: " + path);
    			return null;
    		}
    	}
    }    
    
    public cclass NotifyPort extends TypePort implements INotify{
    	
    	public NotifyPort(){
    		
    	}
    	
    	public String getId(){
    		return id;
    	}  	
    } 
}