cclass initialModel.InitialModel;

public cclass RoomGUI extends TypeComponent{
    
	//RoomId of the room controlled by this GUI
	public String roomId;
	
	//FloorId of the floor in which the GUI is setted
	public String floorId;
	
	//Visual elements for the GUI, to wrap java Swing
	public RoomGUIPanel visualGUI;
	
	//Swing frame, it is used to show the GUI in a separate frame if it is neccesary
	public JFrame frame;
	
    
    public GUIPort gui;
    public NotifyPort request;
    public Deployment dep;
    
    public RoomGUI(String id) {
    	super(id);
        request=new NotifyPort();
        gui=new GUIPort();
        dep=new Deployment();
        visualGUI=new RoomGUIPanel("RoomGUI: "+id);
    }

    public void setRoomId(String roomId){
    	this.roomId=roomId;
    }
    
    public String getRoomId(){
    	return this.roomId;
    }
    
	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public RoomGUIPanel getVisualGUI() {
		return visualGUI;
	}

	public void setVisualGUI(RoomGUIPanel visualGUI) {
		this.visualGUI = visualGUI;
	}

	public GUIPort getGui() {
		return gui;
	}
    
    public String getFloorId() {
        return this.floorId;
    }

    public void setFloorId(String floorId) {
        this.floorId = floorId;
    }

    public void setDep (Deployment value){
        dep=value;
    }
    
    public Deployment getDep(){
        return dep;
    }
    
    public NotifyPort getRequest(){
        return request;
    }
    
    public cclass GUIPort extends TypePort implements IGUI {
    	
    	public GUIPort(){
    		super();
    	}
    	
    	public void showGUI(){
    		//((RoomGUI)comp).getFrame().setSize(800,600);
    		//((RoomGUI)comp).getFrame().setVisible(true);
    	}
    	
    	public void initGUI(){
    		//((RoomGUI)comp).setFrame(new JFrame("ROOM_GUI"));
    		//((RoomGUI)comp).getFrame().getContentPane().add(visualGUI);
    	}
    	
    }    
    
    public cclass NotifyPort extends TypePort implements INotify{
    	
    	public NotifyPort(){
    		super();
    	}
    	
    	public String getId(){
    		return id;
    	}  	
    }    
}
