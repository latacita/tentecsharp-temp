package initialModel;

/**
 * Interface that allows to obtain the id of the component which provides it
 * @author Carlos Nebrera Cuevas
 *
 */
public interface INotify {
    public String getId(); 
}
