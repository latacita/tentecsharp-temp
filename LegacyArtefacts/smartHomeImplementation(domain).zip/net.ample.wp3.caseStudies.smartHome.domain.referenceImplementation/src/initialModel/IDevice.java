package initialModel;

public interface IDevice {
	public String getId();
    public String getRoomId();
    public void setRoomId(String roomId);
    public String getFloorId();
    public void setFloorId(String floorId);  
}
