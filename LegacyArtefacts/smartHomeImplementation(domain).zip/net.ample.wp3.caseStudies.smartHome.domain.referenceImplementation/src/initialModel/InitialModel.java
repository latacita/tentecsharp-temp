package initialModel;

import baseModel.*;
import java.util.ArrayList;
import javax.swing.*;
import visual.initial.*;

/**
 * Base family class for the whole SmartHome
 * It contains the instance of the HouseGateway, and lists for the Cental, Room and Floor GUIs
 * There should be at least 1 CentralGUI component instance so it is instantiated here 
 * @author Carlos Nebrera Cuevas
 *
 */
public cclass InitialModel extends BaseModel{
	
	public ArrayList CentralGUIList;
	public ArrayList RoomGUIList;
	public ArrayList FloorGUIList;
	public HouseGateway houseGateway;
	
	//This static variable is used to simulate the physical devices in the screen
	public static DeviceSimulator deviceSimulator=new DeviceSimulator("Device GUI Simulator");
	
	public InitialModel(){
		CentralGUIList=new ArrayList();
		RoomGUIList=new ArrayList();
		FloorGUIList=new ArrayList();	
	}
	
	public static void addDevice(String floorId,String roomId,String type,String id,JPanel devicePanel){
		deviceSimulator.addDevice(floorId,roomId,type,id,devicePanel);
	}
}