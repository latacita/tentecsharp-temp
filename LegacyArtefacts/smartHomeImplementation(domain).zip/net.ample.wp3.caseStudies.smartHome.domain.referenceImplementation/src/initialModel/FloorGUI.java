cclass initialModel.InitialModel;

public cclass FloorGUI extends TypeComponent{
    
	//FloorId of the floor controlled by this GUI
	public String floorId;
	
	//Visual elements for the GUI, to wrap java Swing
	public FloorGUIPanel visualGUI;
	
	//Swing frame, it is used to show the GUI in a separate frame if it is neccesary
	public JFrame frame;
	
    public Deployment dep;
    public GUIPort gui;
    public NotifyPort request;
    
    //List of roomGUIs inside the floor
    public ArrayList roomGUIs;
    
    
    public FloorGUI(String id){
    	super(id);
        request=new NotifyPort();
        gui=new GUIPort();
        dep=new Deployment();
        roomGUIs=new ArrayList();
        visualGUI=new FloorGUIPanel("FloorGUI: "+id);
    }
    
    public void setFloorId(String floorId){
    	this.floorId=floorId;
    }
    
    public String getFloorId(){
    	return this.floorId;
    }
    
    public FloorGUIPanel getVisualGUI() {
		return visualGUI;
	}

	public void setVisualGui(FloorGUIPanel visualGUI) {
		this.visualGUI = visualGUI;
	}
	
	public JFrame getFrame() {
		return frame;
	}    
	
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
    
	public GUIPort getGui() {
		return gui;
	}
    
     public void setDep (Deployment dep){
        this.dep=dep;
    }
    
    public Deployment getDep(){
        return dep;
    }
    
    public NotifyPort getRequest(){
        return request;
    }
    
    //Method to add a RoomGUI to the ones controlled by the CentralGUI
	public void addRoomGUIsElement(RoomGUI fgui){
		//Firt the new GUI component is added to the list
		roomGUIs.add(fgui);
		//Second it is necesary to add it too into the swing visual gui components
		visualGUI.addRoomGUI(fgui.getVisualGUI());
	}
    
    public cclass GUIPort extends TypePort implements IGUI {
    	
    	public GUIPort(){
    		super();
    	}
    	
    	public void showGUI(){
    		//((FloorGUI)comp).getFrame().setSize(800,600);
    		//((FloorGUI)comp).getFrame().setVisible(true);
    	}
    	
    	public void initGUI(){
    		//((FloorGUI)comp).setFrame(new JFrame("FLOOR_GUI"));
    		//((FloorGUI)comp).getFrame().getContentPane().add(visualGUI);
    	}
    	
    }    
    
    public cclass NotifyPort extends TypePort implements INotify{
    	
    	public NotifyPort(){
    		super();
    	}
    	
    	public String getId(){
    		return id;
    	}  	
    }    
}
