package initialModel;

public interface IGUI {
	public void showGUI();
	public void initGUI();
}
