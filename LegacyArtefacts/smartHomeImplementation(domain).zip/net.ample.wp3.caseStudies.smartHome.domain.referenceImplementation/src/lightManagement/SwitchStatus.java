cclass lightManagement.LightManagement;

public cclass SwitchStatus extends TypeEnum{
    
	public SwitchStatus(){
    	values.add("SwitchOn");
    	values.add("SwitchOff");
    	
    }
}

