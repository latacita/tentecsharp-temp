package lightManagement;

public interface ILightGUINotify {
	public void changeLightIntensity(String lightId, int intensity);
	public void changeLightState(String lightId,boolean state);
}
