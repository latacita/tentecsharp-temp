package lightManagement;

public interface IDimmerNotify {
	//It is used to notify the HouseGateway when a dimmer is modified, String parameter is the
	//id of the light and the integer parameter is the new value for the dimmer
	public void dimmerValueChanged(String lightId,int value);
}
