cclass lightManagement.LightManagement;

public cclass Dimmer extends TypeComponent {

	public RequestPort request;
	//FloorId in witch the Switch is deployed
	public String floorId=null;
	//Room in witch the Switch is deployed, null if it is not in any room
	public String roomId=null;
	//Id of the light that is controled by the dimmer
	public String lightId;
	//Value of the dimmer regulator
	public int dimmerValue;
	//Device Kind
	public DeviceKind deviceKind;
	
	//Elements to made the dimmer visible since we have no real devices
	public VisualDimmer visualDimmer;
	
	public Dimmer(String id){
		super(id);
		deviceKind=new DeviceKind();
		deviceKind.setValue("LightDimmer");
		request=new RequestPort();
		visualDimmer=new VisualDimmer(this);
	}
	
	public DeviceKind getDeviceKind() {
		return deviceKind;
	}

	public String getLightId() {
		return lightId;
	}

	public void setLightId(String lightId) {
		this.lightId = lightId;
		visualDimmer.setLightId(lightId);
	}

	public int getDimmerValue() {
		return dimmerValue;
	}

	//This method doens't notify about the change
	public void setDimmerValue(int value) {
		this.dimmerValue=value;
		visualDimmer.setIntensity(value);
	}
	
	//This method is called when the dimmer is changed manually by the user
	//The internal value of the dimmer is not changed here, since it will be done by the houseGateway
	public void changeDimmerValue(int value){
		ArrayList ports=request.getPortsIDimmerNotify();
		//Tell all the connected components that the value has changed
		for(int i=0;i<ports.size();i++){
			((IDimmerNotify)ports.get(i)).dimmerValueChanged(lightId, value);
		}
	}

	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floor) {
		this.floorId = floor;
		visualDimmer.setFloorId(floor);
	}

	public RequestPort getRequest() {
		return request;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String room) {
		this.roomId = room;
		visualDimmer.setRoomId(room);
	}

	public cclass RequestPort extends TypePort implements IDimmer{
		
		public ArrayList portsIDimmerNotify;
		
		public RequestPort(){
			portsIDimmerNotify=new ArrayList();
		}
		
		public ArrayList getPortsIDimmerNotify() {
			return portsIDimmerNotify;
		}

		public void connectPort(IDimmerNotify port){
			portsIDimmerNotify.add(port);
		}
		
		public String getId(){
			return Dimmer.this.getId();
		}
		
		public String getFloorId(){
			return Dimmer.this.getFloorId();
		}
		
		public void setFloorId(String value){
			Dimmer.this.setFloorId(value);
		}
		
		public String getRoomId(){
			return Dimmer.this.getRoomId();
		}
		
		public void setRoomId(String value){
			Dimmer.this.setRoomId(value);
		}
		
		public int getValue(){
			return Dimmer.this.getDimmerValue();
		}
		
		public void setValue(int value){
			Dimmer.this.setDimmerValue(value);
		}
		
		public String getLightId(){
			return Dimmer.this.getLightId();
		}		
	}
}
