cclass lightManagement.LightManagement;

public cclass RoomGUI extends TypeComponent{
	
	public LightNotifyPort lightNotifyPort;
	//List of light GUIs controlled by the room GUI
	protected ArrayList listLightGUI;
	//Tabbed pane that is added to the main menu of the GUI
	protected LightGUITabbedPanel lightTabbedPanel;
	//Panel with the general options for lights inside the room
	public RoomGeneralLightPanel generalLightPanel;
	
	public RoomGUI(String id){
		super(id);
		lightNotifyPort=new LightNotifyPort();
		listLightGUI=new ArrayList();
		lightTabbedPanel=new LightGUITabbedPanel();
		visualGUI.addTabbedPanel(lightTabbedPanel,"Lights","/visual/icons/bulb20.png");
		generalLightPanel=new RoomGeneralLightPanel(this);
		visualGUI.addPanel(generalLightPanel,"LightControl","/visual/icons/bulbs20.png");
	}
	
	public LightNotifyPort getLightNotifyPort(){
		return lightNotifyPort;
	}
	
	public ArrayList getListLightGUI(){
		return listLightGUI;
	}
	
	public void setListLightGUI(ArrayList value){
		listLightGUI=value;
	}

	public void addListLightGUIElement(LightGUI lightGUI){
		listLightGUI.add(lightGUI);
		lightTabbedPanel.addLightGUIPanel("LightGUI: "+lightGUI.getId(),lightGUI.getVisualGUI());
	}
	
	public cclass LightNotifyPort extends TypePort{
	    
		public ArrayList portsIGeneralLightNotify;	
		 
	    public LightNotifyPort(){
	    	super();
	    	portsIGeneralLightNotify=new ArrayList();
	    }
	    	
	    public void connectPort(IGeneralLightNotify port){
	    	portsIGeneralLightNotify.add(port);
	    }
	    
	    public ArrayList getPortsIGeneralLightNotify(){
	    	return portsIGeneralLightNotify;
	    }
	}
	//Methods used by the visual GUI to notify to CentralGUI
	
	public void switchOffAllLights(){
		ArrayList ports=lightNotifyPort.getPortsIGeneralLightNotify();
		IGeneralLightNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralLightNotify)ports.get(i));
			port.switchOffAllLights(null,roomId);
		}
	}
	
	public void switchOnAllLights(){
		ArrayList ports=lightNotifyPort.getPortsIGeneralLightNotify();
		IGeneralLightNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralLightNotify)ports.get(i));
			port.switchOnAllLights(null,roomId);
		}
	}
	
	public void changeAllLightsIntensity(int intensity){
		ArrayList ports=lightNotifyPort.getPortsIGeneralLightNotify();
		IGeneralLightNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralLightNotify)ports.get(i));
			port.changeAllLightsIntensity(null,roomId,intensity);
		}
	}
}