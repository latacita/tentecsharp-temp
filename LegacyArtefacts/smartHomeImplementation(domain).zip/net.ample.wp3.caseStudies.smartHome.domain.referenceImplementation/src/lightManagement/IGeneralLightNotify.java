package lightManagement;

public interface IGeneralLightNotify {
	public void switchOffAllLights(String floorId,String roomId);
	public void switchOnAllLights(String floorId,String roomId);
	public void changeAllLightsIntensity(String floorId,String roomId,int intensity);
}
