package lightManagement;

/*Note: There could be several switches for the same light, so when a value is changed,
the change has to be reflected in the rest of the switches if it is neccesary */
public interface ISwitch extends initialModel.IDevice{
	//Returns the actual Status of the switch.
	public LightManagement.SwitchStatus getStatus();
	//Change the actual status of the switch
	public void setStatus(LightManagement.SwitchStatus value);
	//Get the if of the light controlled by the switch
	public String getLightId();
}
