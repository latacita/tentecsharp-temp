package lightManagement;

/*Note: There could be several dimmers for the same light, so when a value is changed,
the change has to be reflected in the rest of the dimmers if it is neccesary */
public interface IDimmer extends initialModel.IDevice {
	//Returns the actual value of the dimmer
	public int getValue();
	//Set the value of the dimmer
	public void setValue(int value);
	//Get the if of the light controlled by the dimmer
	public String getLightId();
	
}
