cclass lightManagement.LightManagement;

//This is the component that controls the light directly
//At the moment we are going to suppose that all the controled lights can vary their intensity
public cclass LightController extends TypeComponent {

	//Visual class that simulates the lightController
	public VisualLightController visualLightController;
	
	public LightControllerPort request;
	
	//Intensity value for the Light, the value can oscile between 0 and 100
	public int lightIntensity;
	//State of the light, this is used to switch it on and off and still keep the intensity value
	//when the state is restored, since the dimmers and switches could be independent
	public boolean switchedOn;
	//Id of the light that is being controled
	public String lightId;
	//Floor in witch the Switch is deployed
	public String floorId=null;
	//Room in witch the Switch is deployed, null if it is not in any room
	public String roomId=null;
	//Device Kind
	public DeviceKind deviceKind;
	
	public LightController(String id){
		super(id);
		deviceKind=new DeviceKind();
		deviceKind.setValue("LightController");
		lightIntensity=0;
		switchedOn=false;
		request=new LightControllerPort();
		visualLightController=new VisualLightController();
	}
	
	public DeviceKind getDeviceKind() {
		return deviceKind;
	}

	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floor) {
		this.floorId = floor;
		visualLightController.setFloorId(floor);
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String room) {
		visualLightController.setRoomId(room);
		this.roomId = room;
	}

	public String getLightId() {
		return lightId;
	}

	public void setLightId(String lightId) {
		visualLightController.setLightId(lightId);
		this.lightId = lightId;
	}

	public boolean isSwitchedOn() {
		return switchedOn;
	}

	public void setSwitchedOn(boolean switchedOn) {
		visualLightController.setState(switchedOn);
		this.switchedOn = switchedOn;
	}
	
	public int getLightIntensity() {
		return lightIntensity;
	}

	public void setLightIntensity(int lightIntensity) {
		visualLightController.setIntensity(lightIntensity);
		this.lightIntensity = lightIntensity;
	}

	public LightControllerPort getRequest() {
		return request;
	}
	
	public cclass LightControllerPort extends TypePort implements ILightController{
		public LightControllerPort(){
			super();
		}
		
		public void setValue(int value){
			LightController.this.setLightIntensity(value);
		}
		public int getValue(){
			return LightController.this.getLightIntensity();
		}
		public void switchOn(){
			LightController.this.setSwitchedOn(true);
		}
		public void switchOff(){
			LightController.this.setSwitchedOn(false);
		}
		public String getLightId(){
			return LightController.this.getLightId();
		}
		public String getId(){
			return LightController.this.getId();
		}
		
		public String getFloorId(){
			return LightController.this.getFloorId();
		}
		
		public void setFloorId(String value){
			LightController.this.setFloorId(value);
		}
		
		public String getRoomId(){
			return LightController.this.getRoomId();
		}
		
		public void setRoomId(String value){
			LightController.this.setRoomId(value);
		}
	}
}

