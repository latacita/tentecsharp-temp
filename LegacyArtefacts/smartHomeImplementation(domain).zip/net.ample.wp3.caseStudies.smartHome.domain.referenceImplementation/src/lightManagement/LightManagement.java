package lightManagement;
import initialModel.InitialModel;
import java.util.*;
import visual.lights.*;

public cclass LightManagement extends InitialModel{

	public ArrayList switchList;
	public ArrayList lightControllerList;
	public ArrayList dimmerList;
	
	public LightManagement(){
		super();
		switchList=new ArrayList();
		lightControllerList=new ArrayList();
		dimmerList=new ArrayList();
	}
	
	public ArrayList getSwitchList(){
		return switchList;
	}
	
	public ArrayList getLightControllerList(){
		return lightControllerList;
	}
	
	public ArrayList getDimmerList(){
		return dimmerList;
	}
}
