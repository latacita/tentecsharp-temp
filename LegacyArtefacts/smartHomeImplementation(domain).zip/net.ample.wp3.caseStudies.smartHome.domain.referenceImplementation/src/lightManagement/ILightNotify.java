package lightManagement;

public interface ILightNotify {
	public void changeLightIntensity(String lightId, int intensity);
	public void changeLightState(String lightId,boolean state);
}
