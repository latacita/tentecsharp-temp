cclass lightManagement.LightManagement;

public cclass DeviceKind {
    
	public DeviceKind(){
		values.add("LightSwitch");
		values.add("LightDimmer");
		values.add("LightController");
	}     
}
