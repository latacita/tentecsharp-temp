cclass lightManagement.LightManagement;
import java.util.*;

public cclass Switch extends TypeComponent{

	public SwitchPort request;
	
	//Status of the switch
	public SwitchStatus status;
	
	//Floor in witch the Switch is deployed
	public String floorId=null;
	//Room in witch the Switch is deployed, null if it is not in any room
	public String roomId=null;
	
	//Id of the light that is controled by the switch
	public String lightId;
	//Device Kind
	public DeviceKind deviceKind;
	
	//Elements to made the switch visible since we have no real devices
	public VisualSwitch visualSwitch;
	
	public Switch(String id){
		super(id);
		deviceKind=new DeviceKind();
		deviceKind.setValue("LightDimmer");
		request=new SwitchPort();
		status=new SwitchStatus();
		visualSwitch=new VisualSwitch(this);
	}
	
	public DeviceKind getDeviceKind() {
		return deviceKind;
	}

	public String getLightId() {
		return lightId;
	}


	public void setLightId(String lightId) {
		this.lightId = lightId;
		visualSwitch.setLightId(lightId);
	}


	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floor) {
		this.floorId = floor;
		visualSwitch.setFloorId(floor);
	}

	public SwitchPort getRequest() {
		return request;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String room) {
		this.roomId = room;
		visualSwitch.setRoomId(room);
	}

	public SwitchStatus getStatus(){
		return status;
	}
	
	//Change the status of the switch withot notifications
	public void setStatus(SwitchStatus value){	
		status=value;	
		if(value.getStringValue().equals("SwitchOn")){
			visualSwitch.setState(true);
		}else{
			visualSwitch.setState(false);
		}
	}
	
	//Change the status of the switch by notifing the houseGateway
	public void changeSwitchStatus(SwitchStatus value){
		//Notify to the HouseGateway that the state has been externally modified
		ArrayList ports=request.getPortsISwitchNotify();
		for(int i=0;i<ports.size();i++){
			((ISwitchNotify)ports.get(i)).switchValueChanged(lightId,value);
		}
	}
	
	//Change the status of the switch by notifing the houseGateway, it will be only used by the VisualDimmer class
	public void changeSwitchStatus(boolean newStatus){
		SwitchStatus status=new SwitchStatus();
		if(newStatus){
			status.setValue("SwitchOn");
		}else{
			status.setValue("SwitchOff");
		}
		changeSwitchStatus(status);
	}
	
	public cclass SwitchPort extends TypePort implements ISwitch{
		
		public ArrayList portsISwitchNotify;
		
		public SwitchPort(){
			super();
			portsISwitchNotify=new ArrayList();
		}
		
		public ArrayList getPortsISwitchNotify() {
			return portsISwitchNotify;
		}

		public void connectPort(ISwitchNotify port){
			portsISwitchNotify.add(port);
		}
		
		public SwitchStatus getStatus(){
			return Switch.this.getStatus();
		}
		
		public void setStatus(SwitchStatus value){
			Switch.this.setStatus(value);
		}
		
		public String getId(){
			return Switch.this.getId();
		}
		
		public String getFloorId(){
			return Switch.this.getFloorId();
		}
		
		public void setFloorId(String value){
			Switch.this.setFloorId(value);
		}
		
		public String getRoomId(){
			return Switch.this.getRoomId();
		}
		
		public void setRoomId(String value){
			Switch.this.setRoomId(value);
		}
		
		public String getLightId(){
			return Switch.this.getLightId();
		}
	}
}
