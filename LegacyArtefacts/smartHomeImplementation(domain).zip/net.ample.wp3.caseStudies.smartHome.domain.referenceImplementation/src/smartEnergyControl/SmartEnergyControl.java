package smartEnergyControl;

import heaterManagement.HeaterManagement;
import heaterManagement.*;
import windowManagement.WindowManagement;
import java.util.ArrayList;
import visual.smartEnergy.*;

public cclass SmartEnergyControl extends HeaterManagement & WindowManagement {
		
	public SmartEnergyControl(){
		super();
	}
}
