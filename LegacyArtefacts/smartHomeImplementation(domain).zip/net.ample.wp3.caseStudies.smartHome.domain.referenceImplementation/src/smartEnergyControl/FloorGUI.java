cclass smartEnergyControl.SmartEnergyControl;

public cclass FloorGUI extends TypeComponent{
       
	public SmartPort smartEnergyPort;
	public SmartNotifyPort smartEnergyNotifyPort;
	
	public FloorSmartEnergyPanel smartEnergyPanel;
    
    public FloorGUI(String id) {
    	super(id);
    	smartEnergyPort=new SmartPort();
    	smartEnergyNotifyPort=new SmartNotifyPort();
    	smartEnergyPanel=new FloorSmartEnergyPanel(this);
    	visualGUI.addPanel(smartEnergyPanel,"SmartEnergySaver","/visual/icons/energySaver20.png");
    }
    
    public SmartPort getSmartEnergyPort(){
    	return smartEnergyPort;
    }
    
    public SmartNotifyPort getSmartEnergyNotifyPort(){
    	return smartEnergyNotifyPort;
    }
    
  //This method calls comes from the visual GUI
    public void switchOnEnergySaver(){
    	ArrayList ports=smartEnergyPort.getPortsISmartEnergy();
    	ISmartEnergy port;
    	for(int i=0;i<ports.size();i++){
    		port=((ISmartEnergy)ports.get(i));
    		port.activateSmartControl(floorId,null);
    	}
    }
    
    public void switchOffEnergySaver(){
    	ArrayList ports=smartEnergyPort.getPortsISmartEnergy();
    	ISmartEnergy port;
    	for(int i=0;i<ports.size();i++){
    		port=((ISmartEnergy)ports.get(i));
    		port.deactivateSmartControl(floorId,null);
    	}
    }
    
    //This method calls comes from the houseGateway, if both parameters are null the command is general
    //For all the GUIs, so it has to be applied here
    public void activateSmartControl(String floorId,String roomId){
    	if((floorId==null)&&(roomId==null)){
			this.smartEnergyPanel.switchOnEnergySaver();
    	}
		else if((floorId!=null)&&(floorId.equals(this.floorId))){
    		this.smartEnergyPanel.switchOnEnergySaver();
    	}
    }
    
	public void deactivateSmartControl(String floorId,String roomId){
		if((floorId==null)&&(roomId==null)){
			this.smartEnergyPanel.switchOffEnergySaver();
    	}
		else if((floorId!=null)&&(floorId.equals(this.floorId))){
    		this.smartEnergyPanel.switchOffEnergySaver();
    	}
	}
    
    public cclass SmartPort extends TypePort{
    	
    	protected ArrayList portsISmartEnergy;
    	
    	public SmartPort(){
    		super();
    		portsISmartEnergy=new ArrayList();
    	}
    	
    	public void connectPort(ISmartEnergy port){
    		portsISmartEnergy.add(port);
    	}
    	
    	public ArrayList getPortsISmartEnergy(){
    		return portsISmartEnergy;
    	}
    }
    
    public cclass SmartNotifyPort extends TypePort implements ISmartEnergyNotify{
    	
    	public SmartNotifyPort(){
    		super();
    	}
    	
    	public void activateSmartControl(String floorId,String roomId){
    		FloorGUI.this.activateSmartControl(floorId,roomId);
    	}
    	
    	public void deactivateSmartControl(String floorId,String roomId){
    		FloorGUI.this.deactivateSmartControl(floorId,roomId);
    	}
    }
}
