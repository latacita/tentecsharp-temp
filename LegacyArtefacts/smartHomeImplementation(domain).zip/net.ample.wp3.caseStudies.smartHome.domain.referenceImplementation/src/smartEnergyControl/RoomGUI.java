cclass smartEnergyControl.SmartEnergyControl;
import initialModel.InitialModel;

public cclass RoomGUI extends TypeComponent{
    
	public SmartPort smartEnergyPort;
	public SmartNotifyPort smartEnergyNotifyPort;
	
	public RoomSmartEnergyPanel smartEnergyPanel;
    public VisualSmartEnergyPanel visualEnergyPanel;
	
    public RoomGUI(String id) {
    	super(id);
    	floorId=null;
    	roomId=null;
    	smartEnergyPort=new SmartPort();
    	smartEnergyNotifyPort=new SmartNotifyPort();
    	smartEnergyPanel=new RoomSmartEnergyPanel(this);
    	visualGUI.addPanel(smartEnergyPanel,"SmartEnergySaver","/visual/icons/energySaver20.png");
    	visualEnergyPanel=new VisualSmartEnergyPanel();
    }

    public void setRoomId(String roomId){
    	this.roomId=roomId;
    	if((roomId!=null)&&(floorId!=null)){
    		InitialModel.addDevice(floorId,roomId,"SmartEnergyControl",roomId+"SmartControl",visualEnergyPanel);
    	}
    }
    
    public void setFloorId(String floorId){
    	this.floorId=floorId;
    	if((roomId!=null)&&(floorId!=null)){
    		InitialModel.addDevice(floorId,roomId,"SmartEnergyControl",roomId+"SmartControl",visualEnergyPanel);
    	}
    }
    
    public SmartPort getSmartEnergyPort(){
    	return smartEnergyPort;
    }
    
    public SmartNotifyPort getSmartEnergyNotifyPort(){
    	return smartEnergyNotifyPort;
    }
    
    //This method calls comes from the visual GUI
    public void switchOnEnergySaver(){
    	ArrayList ports=smartEnergyPort.getPortsISmartEnergy();
    	ISmartEnergy port;
    	for(int i=0;i<ports.size();i++){
    		port=((ISmartEnergy)ports.get(i));
    		port.activateSmartControl(null,roomId);
    	}
    }
    
    public void switchOffEnergySaver(){
    	ArrayList ports=smartEnergyPort.getPortsISmartEnergy();
    	ISmartEnergy port;
    	for(int i=0;i<ports.size();i++){
    		port=((ISmartEnergy)ports.get(i));
    		port.deactivateSmartControl(null,roomId);
    	}
    }
    
    //This method calls comes from the houseGateway, if both parameters are null the command is general
    //For all the GUIs, so it has to be applied here
    public void activateSmartControl(String floorId,String roomId){
    	if((floorId==null)&&(roomId==null)){
    		this.smartEnergyPanel.switchOnEnergySaver();
    		visualEnergyPanel.activate();
    	}
    	else if((floorId!=null)&&(floorId.equals(this.floorId))){
    		this.smartEnergyPanel.switchOnEnergySaver();
    		visualEnergyPanel.activate();
    	}
    	else if((roomId!=null)&&(roomId.equals(this.roomId))){
    		this.smartEnergyPanel.switchOnEnergySaver();
    		visualEnergyPanel.activate();
    	}
    }
    
	public void deactivateSmartControl(String floorId,String roomId){
		if((floorId==null)&&(roomId==null)){
			this.smartEnergyPanel.switchOffEnergySaver();
			visualEnergyPanel.deactivate();
    	}
		else if((floorId!=null)&&(floorId.equals(this.floorId))){
    		this.smartEnergyPanel.switchOffEnergySaver();
    		visualEnergyPanel.deactivate();
    	}
    	else if((roomId!=null)&&(roomId.equals(this.roomId))){
    		this.smartEnergyPanel.switchOffEnergySaver();
    		visualEnergyPanel.deactivate();
    	}
	}
    
    public cclass SmartPort extends TypePort{
    	
    	protected ArrayList portsISmartEnergy;
    	
    	public SmartPort(){
    		super();
    		portsISmartEnergy=new ArrayList();
    	}
    	
    	public void connectPort(ISmartEnergy port){
    		portsISmartEnergy.add(port);
    	}
    	
    	public ArrayList getPortsISmartEnergy(){
    		return portsISmartEnergy;
    	}
    }
    
    public cclass SmartNotifyPort extends TypePort implements ISmartEnergyNotify{
    	
    	public SmartNotifyPort(){
    		super();
    	}
    	
    	public void activateSmartControl(String floorId,String roomId){
    		RoomGUI.this.activateSmartControl(floorId,roomId);
    	}
    	
    	public void deactivateSmartControl(String floorId,String roomId){
    		RoomGUI.this.deactivateSmartControl(floorId,roomId);
    	}
    }
}
