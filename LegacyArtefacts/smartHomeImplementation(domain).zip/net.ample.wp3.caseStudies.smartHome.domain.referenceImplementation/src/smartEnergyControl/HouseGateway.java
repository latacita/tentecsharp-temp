cclass smartEnergyControl.SmartEnergyControl;

public cclass HouseGateway extends TypeComponent{
       
	public SmartPort smartEnergyPort;
	public SmartNotifyPort smartEnergyNotifyPort;
    
    public HouseGateway(String id) {
    	super(id);
    	smartEnergyPort=new SmartPort();
    	smartEnergyNotifyPort=new SmartNotifyPort();
    }

    public SmartPort getSmartEnergyPort(){
    	return smartEnergyPort;
    }
    
    public SmartNotifyPort getSmartEnergyNotifyPort(){
    	return smartEnergyNotifyPort;
    }
    
    //This methods correspond to a temperature change in a thermometers, if the SmartControll is active it has to check it
    public void insideTempChanged(String thermometerId,float value){
    	super.insideTempChanged(thermometerId,value);
    	smartEnergyActualization();
    }
    
    public void outsideTempChanged(String thermometerId,float value){
    	super.outsideTempChanged(thermometerId,value);
    	smartEnergyActualization();
    }
    
    //This method correspond to a heater temperature change
    public void heaterTemperatureChanged(String heaterId,float newTemp){
    	super.heaterTemperatureChanged(heaterId,newTemp);
    	smartEnergyActualization();
    }
    
    //This method corresponds to a heater state changed
    public void heaterSwitchChanged(String heaterId,boolean on){
    	super.heaterSwitchChanged(heaterId,on);
    	smartEnergyActualization();
    }
    
    //This method activate the smart control and actualize the state of the windows and heaters
    public void activateSmartControl(String floorId,String roomId){
    	if((floorId==null)&&(roomId==null)){ //It has to be activated in the full house
    		//First we change the information in the structure
    		houseData.activateSmartControl();
    		//Second step is to reflect the changed in the GUIs
    		ArrayList ports=getSmartEnergyNotifyPort().getPortsISmartEnergyNotify();
    		for(int i=0;i<ports.size();i++){
    			((ISmartEnergyNotify)ports.get(i)).activateSmartControl(floorId,roomId);
    		}
    		//Third step is to actualize the house heaters and windows state
    		smartEnergyActualization();
    		
    	}else if(floorId!=null){ //It has to be activated in the giving floor and their rooms
    		//First we change the information in the structure
    		Floor floor=houseData.getFloorById(floorId);
    		floor.activateSmartControl();
    		//Second step is to reflect the changed in the GUIs
    		ArrayList ports=getSmartEnergyNotifyPort().getPortsISmartEnergyNotify();
    		for(int i=0;i<ports.size();i++){
    			((ISmartEnergyNotify)ports.get(i)).activateSmartControl(floorId,roomId);
    		}
    		//Third step is to actualize the house heaters and windows state
    		smartEnergyActualization();
    	}else if(roomId!=null){ //It has to be activated in the giving room
    		//First we change the information in the structure
    		Room room=houseData.getRoomById(roomId);
    		room.setSmartControlActive(true);
    		//Second step is to reflect the changed in the GUIs
    		ArrayList ports=getSmartEnergyNotifyPort().getPortsISmartEnergyNotify();
    		for(int i=0;i<ports.size();i++){
    			((ISmartEnergyNotify)ports.get(i)).activateSmartControl(floorId,roomId);
    		}
    		//Third step is to actualize the house heaters and windows state
    		smartEnergyActualization();
    	}
    }
    
    //In this method we only modify the structure. This way when there are changes in the thermometers
    //it check if the control is active and don't modify the windows and heaters
	public void deactivateSmartControl(String floorId,String roomId){
		if((floorId==null)&&(roomId==null)){ //It has to be activated in the full house
    		//First we change the information in the structure
    		houseData.deactivateSmartControl();
    		//Second step is to reflect the changed in the GUIs
    		ArrayList ports=getSmartEnergyNotifyPort().getPortsISmartEnergyNotify();
    		for(int i=0;i<ports.size();i++){
    			((ISmartEnergyNotify)ports.get(i)).deactivateSmartControl(floorId,roomId);
    		}
    	}else if(floorId!=null){ //It has to be activated in the giving floor and their rooms
    		//First we change the information in the structure
    		Floor floor=houseData.getFloorById(floorId);
    		floor.deactivateSmartControl();
    		//Second step is to reflect the changed in the GUIs
    		ArrayList ports=getSmartEnergyNotifyPort().getPortsISmartEnergyNotify();
    		for(int i=0;i<ports.size();i++){
    			((ISmartEnergyNotify)ports.get(i)).deactivateSmartControl(floorId,roomId);
    		}
    	}else if(roomId!=null){ //It has to be activated in the giving room
    		//First we change the information in the structure
    		Room room=houseData.getRoomById(roomId);
    		room.setSmartControlActive(false);
    		//Second step is to reflect the changed in the GUIs
    		ArrayList ports=getSmartEnergyNotifyPort().getPortsISmartEnergyNotify();
    		for(int i=0;i<ports.size();i++){
    			((ISmartEnergyNotify)ports.get(i)).deactivateSmartControl(floorId,roomId);
    		}
    	}
	}
    
	//Method that actualize the House components when the smart energy system is activated 
	public void smartEnergyActualization(){
		ArrayList rooms=houseData.getAllRooms();
		ArrayList thermometers;
		ArrayList heaters;
		ArrayList windows;
		Window window;
		Heater heater;
		float averageInsideTemp=0;
		float averageOutsideTemp=0;
		float averageSelectedTemperature=0;
		float differenceInOut;
		float differenceInSelected;
		
		
		Room room;
		for(int i=0;i<rooms.size();i++){
			room=((Room)rooms.get(i));
			//If the room has the smart control active we have to actualized the devices and GUIs of the room
			if(room.getSmartControlActive()){
				thermometers=room.getThermometers();
				windows=room.getWindows();
				heaters=room.getHeaters();
				
				//Check if there are heaters in the room, and if any of them is active, and calculate the average temperature
				//selected in the active heaters
				boolean active=false;
				int j=0;
				while (j<heaters.size()){
					heater=((Heater)heaters.get(j));
					if(heater.getState()){
						active=true;
						averageSelectedTemperature+=heater.getTemperature();
					}
					j++;
				}
				if(active){
					averageSelectedTemperature=averageSelectedTemperature/j;
				}
				
				//Only if there is a heater active in the room we continue with the actualization
				if (active){
					//Second we calculate the average temperature of the thermometers
					j=0;
					Thermometer thermometer;
					while (j<thermometers.size()){
						thermometer=((Thermometer)thermometers.get(j));
						averageInsideTemp+=thermometer.getTemp();
						averageOutsideTemp+=thermometer.getOutTemp();
						j++;
					}
					if(j>0){
						averageInsideTemp=averageInsideTemp/j;
						averageOutsideTemp=averageOutsideTemp/j;
					}
					
					//Depending on the difference between average outside, inside and heater selected temperature the windows are open
					//more or less and the heaters powered more or less.
					differenceInOut=averageInsideTemp-averageOutsideTemp;	
					differenceInSelected=averageInsideTemp-averageSelectedTemperature;
				
					//If there is a difference between the selected temperature and the internal temperature
					if(differenceInSelected>0){//There is more temperature inside than the selected one
						//Check if outside is cooler than inside, in that case open the windows and reduce the heater power
						if(differenceInOut>0){
							//Open the windows
							for(int k=0;k<windows.size();k++){
								window=((Window)windows.get(k));
								windowApertureChanged(window.getId(),100);
							}
							//Set the heaters power to 0
							for(int k=0;k<heaters.size();k++){
								heater=((Heater)heaters.get(k));
								heater.setPower(0);
								//Now it is necessary to modify the information of the HeatingController component and HeaterGUI
								ArrayList ports=getActuators().getPortsIHeating();
								for(int l=0;l<ports.size();l++){
									((IHeating)ports.get(l)).setPower(heater.getHeaterId(),0);
								}
							}
						}
					}else if(differenceInSelected<0){//There is less temperature outside than the selected one
						//Check if outside is hotter than inside, in that case open the windows and reduce the heater power
						if(differenceInOut<0){
							//Open the windows
							for(int k=0;k<windows.size();k++){
								window=((Window)windows.get(k));
								windowApertureChanged(window.getId(),100);
							}
							//Set the heaters power to 0
							for(int k=0;k<heaters.size();k++){
								heater=((Heater)heaters.get(k));
								heater.setPower(0);
								//Now it is necessary to modify the information of the HeatingController component and HeaterGUI
								ArrayList ports=getActuators().getPortsIHeating();
								for(int l=0;l<ports.size();l++){
									((IHeating)ports.get(l)).setPower(heater.getHeaterId(),0);
								}
							}
						}
					}//Any other case let the heaters work normally
				}
			}
		}
	}
	
    public cclass SmartPort extends TypePort implements ISmartEnergy{
    	
    	public SmartPort(){
    		super();
    	}
    	
    	public void activateSmartControl(String floorId,String roomId){
    		HouseGateway.this.activateSmartControl(floorId,roomId);
    	}
    	
    	public void deactivateSmartControl(String floorId,String roomId){
    		HouseGateway.this.deactivateSmartControl(floorId,roomId);
    	}
    }
    
    public cclass SmartNotifyPort extends TypePort{
    	
    	public ArrayList portsISmartEnergyNotify;
    	
    	public SmartNotifyPort(){
    		super();
    		portsISmartEnergyNotify=new ArrayList();
    	}
    	
    	public void connectPort(ISmartEnergyNotify port){
    		portsISmartEnergyNotify.add(port);
    	}
    	
    	public ArrayList getPortsISmartEnergyNotify(){
    		return portsISmartEnergyNotify;
    	}
    	
    }
    
    public cclass House {
    	
    	public boolean smartControlActive;
    	
    	public House(){
    		super();
    		smartControlActive=false;
    	}
    	
    	//Activates the smart control for the full house, activating it in cascade in all the structure
    	public void activateSmartControl(){
    		this.setSmartControlActive(true);
    		for(int i=0;i<floors.size();i++){
    			((Floor)floors.get(i)).activateSmartControl();
    		}
    	}
    	
    	//Deactivate the smart control for the full house, activating it in cascade in all the structure
    	public void deactivateSmartControl(){
    		this.setSmartControlActive(false);
    		for(int i=0;i<floors.size();i++){
    			((Floor)floors.get(i)).deactivateSmartControl();
    		}
    	}
    	
    	//Get the smart control variable
    	public boolean getSmartControlActive(){
    		return smartControlActive;
    	}
    	
    	//Set the smart control variable
    	public void setSmartControlActive(boolean value){
    		smartControlActive=value;
    	}
    	
    	
    	
    }

    public cclass Floor {
        
    	public boolean smartControlActive;
    	
        public Floor(){
        	super();
        	smartControlActive=false;
        }
             
        //Activates the smart control for a floor, activating it in cascade in the rest of the structure
    	public void activateSmartControl(){
    		this.setSmartControlActive(true);
    		for(int i=0;i<rooms.size();i++){
    			((Room)rooms.get(i)).setSmartControlActive(true);
    		}
    	}
    	
    	//Deactivate the smart control for a floor, activating it in cascade in the rest of the structure
    	public void deactivateSmartControl(){
    		this.setSmartControlActive(false);
    		for(int i=0;i<rooms.size();i++){
    			((Room)rooms.get(i)).setSmartControlActive(false);
    		}
    	}
    	
    	//Get the smart control variable
    	public boolean getSmartControlActive(){
    		return smartControlActive;
    	}
    	
    	//Set the smart control variable
    	public void setSmartControlActive(boolean value){
    		smartControlActive=value;
    	}
        
    }

    public cclass Room {
        	
    	public boolean smartControlActive;
    	
        public Room (){
        	super();    	
        	smartControlActive=false;
        }
        
        public boolean getSmartControlActive(){
    		return smartControlActive;
    	}
    	
    	public void setSmartControlActive(boolean value){
    		smartControlActive=value;
    	}
    }
}
