cclass smartEnergyControl.SmartEnergyControl;
import javax.swing.*;

public cclass CentralGUI extends TypeComponent {
    
	public SmartPort smartEnergyPort;
	public SmartNotifyPort smartEnergyNotifyPort;
	
	public GeneralSmartEnergyPanel smartEnergyPanel;
	
    public CentralGUI(String id) {
    	super(id);
    	smartEnergyPort=new SmartPort();
    	smartEnergyNotifyPort=new SmartNotifyPort();
    	smartEnergyPanel=new GeneralSmartEnergyPanel(this);
    	visualGUI.addPanel(smartEnergyPanel,"SmartEnergySaver","/visual/icons/energySaver20.png");
    }

    public SmartPort getSmartEnergyPort(){
    	return smartEnergyPort;
    }
    
    public SmartNotifyPort getSmartEnergyNotifyPort(){
    	return smartEnergyNotifyPort;
    }
    
    //This method calls comes from the visual GUI
    public void switchOnEnergySaver(){
    	ArrayList ports=smartEnergyPort.getPortsISmartEnergy();
    	ISmartEnergy port;
    	for(int i=0;i<ports.size();i++){
    		port=((ISmartEnergy)ports.get(i));
    		port.activateSmartControl(null,null);
    	}
    }
    
    public void switchOffEnergySaver(){
    	ArrayList ports=smartEnergyPort.getPortsISmartEnergy();
    	ISmartEnergy port;
    	for(int i=0;i<ports.size();i++){
    		port=((ISmartEnergy)ports.get(i));
    		port.deactivateSmartControl(null,null);
    	}
    }
    
    //This method calls comes from the houseGateway, if both parameters are null the command is general
    //For all the GUIs, so it has to be applied here
    public void activateSmartControl(String floorId,String roomId){
    	if((floorId==null)&&(roomId==null)){
    		this.smartEnergyPanel.switchOnEnergySaver();
    	}
    }
    
	public void deactivateSmartControl(String floorId,String roomId){
		if((floorId==null)&&(roomId==null)){
			this.smartEnergyPanel.switchOffEnergySaver();
    	}
	}
    
    public cclass SmartPort extends TypePort{
    	
    	protected ArrayList portsISmartEnergy;
    	
    	public SmartPort(){
    		super();
    		portsISmartEnergy=new ArrayList();
    	}
    	
    	public void connectPort(ISmartEnergy port){
    		portsISmartEnergy.add(port);
    	}
    	
    	public ArrayList getPortsISmartEnergy(){
    		return portsISmartEnergy;
    	}
    }
    
    public cclass SmartNotifyPort extends TypePort implements ISmartEnergyNotify{
    	
    	public SmartNotifyPort(){
    		super();
    	}
    	
    	public void activateSmartControl(String floorId,String roomId){
    		CentralGUI.this.activateSmartControl(floorId,roomId);
    	}
    	
    	public void deactivateSmartControl(String floorId,String roomId){
    		CentralGUI.this.deactivateSmartControl(floorId,roomId);
    	}
    }
    
}
