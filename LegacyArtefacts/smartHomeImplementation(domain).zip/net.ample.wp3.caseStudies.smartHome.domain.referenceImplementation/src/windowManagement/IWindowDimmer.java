package windowManagement;

/*Note: There could be several dimmers for the same window, so when a value is changed,
the change has to be reflected in the rest of the dimmers if it is necessary */
public interface IWindowDimmer extends initialModel.IDevice {
	//Returns the actual value of the dimmer
	public int getAperture();
	//Set the value of the dimmer
	public void setAperture(int value);
	//Get the Id of the window controller by the dimmer
	public String getWindowId();
	
}
