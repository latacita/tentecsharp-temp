cclass windowManagement.WindowManagement;

//BlindGUI controls a panel with some lights
public cclass BlindGUI extends TypeComponent{

	protected RequestPort request;
	protected ServicesPort services;
	public String blindId;
	public String floorId;
	public String roomId;
	
	
	//Panel that implements all the swing elements needed for the representation
	protected BlindGUIPanel visualGUI;
	
	public BlindGUI(String id){
		super(id);
		visualGUI=new BlindGUIPanel(this);
		request=new RequestPort();
		services=new ServicesPort();
	}
	
	public void setBlindId(String value){
		this.blindId=value;
		this.visualGUI.setBlindId(value);
	}
	
	public String getBlindId(){
		return blindId;
	}
	
	public void setFloorId(String value){
		this.floorId=value;
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public void setRoomId(String value){
		this.roomId=value;
	}
	
	public String getRoomId(){
		return roomId;
	}
	
	public RequestPort getRequest() {
		return request;
	}

	public ServicesPort getServices() {
		return services;
	}

	public String getId(){
		return id;
	}
	
	public BlindGUIPanel getVisualGUI(){
		return visualGUI;
	}
	
	public void setVisualGUI(BlindGUIPanel panel){
		visualGUI=panel;
	}
	
	public RequestPort getRequestPort(){
		return request;
	}
	
	//Methods to advise the HouseGateway about changes in the GUI
	
	public void notifyBlindApertureChange(String blindId,int value){
		ArrayList ports=services.getPortsIBlindGUINotify();
		IBlindGUINotify port;
		for(int i=0;i<ports.size();i++){
			port=((IBlindGUINotify)ports.get(i));
			port.changeBlindAperture(blindId, value);
		}
	}
	
	//Methods for the IBlindNotify interface
	public void changeBlindAperture(String blindId, int value){
		visualGUI.changeBlindAperture(blindId,value);
	}
	
	public cclass ServicesPort extends TypePort{
		public ArrayList portsIBlindGUINotify; 
		
		public ServicesPort(){
			super();
			portsIBlindGUINotify=new ArrayList();
		}
		
		public ArrayList getPortsIBlindGUINotify() {
			return portsIBlindGUINotify;
		}
		
		public void connectPort(IBlindGUINotify port){
			portsIBlindGUINotify.add(port);
		}
	}
	
	public cclass RequestPort extends TypePort implements IBlindNotify{
		
		public RequestPort(){
			super();
		}

		public void changeBlindAperture(String blindId, int value){
			BlindGUI.this.changeBlindAperture(blindId,value);
		}
	}
}