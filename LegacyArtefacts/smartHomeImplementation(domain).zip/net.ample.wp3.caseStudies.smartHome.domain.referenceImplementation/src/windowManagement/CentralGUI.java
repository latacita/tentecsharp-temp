cclass windowManagement.WindowManagement;

public cclass CentralGUI extends TypeComponent{

	public WindowNotifyPort windowNotifyPort;
	public BlindNotifyPort blindNotifyPort;
	
	public CentralGeneralWindowPanel generalWindowPanel;
	public CentralGeneralBlindPanel generalBlindPanel;
	
	public CentralGUI(String id){
		super(id);
		windowNotifyPort=new WindowNotifyPort();
		blindNotifyPort=new BlindNotifyPort();
		generalWindowPanel=new CentralGeneralWindowPanel(this);
		generalBlindPanel=new CentralGeneralBlindPanel(this);
		visualGUI.addPanel(generalWindowPanel,"WindowControl","/visual/icons/windows20.png");
		visualGUI.addPanel(generalBlindPanel,"BlindControl","/visual/icons/blinds20.png");
	}
	
	public WindowNotifyPort getWindowNotifyPort(){
		return windowNotifyPort;
	}
	
	public BlindNotifyPort getBlindNotifyPort(){
		return blindNotifyPort;
	}
	
    public cclass WindowNotifyPort extends TypePort{
	    
		public ArrayList portsIGeneralWindowNotify;	
		 
	    public WindowNotifyPort(){
	    	super();
	    	portsIGeneralWindowNotify=new ArrayList();
	    }
	    	
	    public void connectPort(IGeneralWindowNotify port){
	    	portsIGeneralWindowNotify.add(port);
	    }
	      
	    public ArrayList getPortsIGeneralWindowNotify(){
	    	return portsIGeneralWindowNotify;
	    }
	}
	
    public cclass BlindNotifyPort extends TypePort{
	    
		public ArrayList portsIGeneralBlindNotify;	
		 
	    public BlindNotifyPort(){
	    	super();
	    	portsIGeneralBlindNotify=new ArrayList();
	    }
	    	    
	    public void connectPort(IGeneralBlindNotify port){
	    	portsIGeneralBlindNotify.add(port);
	    }
	    
	    public ArrayList getPortsIGeneralBlindNotify(){
	    	return portsIGeneralBlindNotify;
	    }
	}
    
	//Methods used by the visual GUI to notify to CentralGUI
	
	public void openAllWindows(){
		changeAllWindowsAperture(100);
	}
	
	public void openAllBlinds(){
		changeAllBlindsAperture(100);
	}
	
	public void closeAllWindows(){
		changeAllWindowsAperture(0);
	}
	
	public void closeAllBlinds(){
		changeAllBlindsAperture(0);
	}
	
	public void changeAllWindowsAperture(int aperture){
		ArrayList ports=windowNotifyPort.getPortsIGeneralWindowNotify();
		IGeneralWindowNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralWindowNotify)ports.get(i));
			port.changeAllWindowsAperture(null,null,aperture);
		}
	}
	
	public void changeAllBlindsAperture(int aperture){
		ArrayList ports=blindNotifyPort.getPortsIGeneralBlindNotify();
		IGeneralBlindNotify port;
		for(int i=0;i<ports.size();i++){
			port=((IGeneralBlindNotify)ports.get(i));
			port.changeAllBlindsAperture(null,null,aperture);
		}
	}
}