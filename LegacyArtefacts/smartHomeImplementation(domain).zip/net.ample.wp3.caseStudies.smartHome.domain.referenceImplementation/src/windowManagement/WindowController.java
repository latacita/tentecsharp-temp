cclass windowManagement.WindowManagement;

//This is the component that controls the window directly
//At the moment we are going to suppose that all the controlled windows can vary their aperture
public cclass WindowController extends TypeComponent {

	//Visual class that simulates the windowController
	public VisualWindowController visualWindowController;
	
	public WindowControllerPort request;
	
	//Aperture value for the Window, the value can vary between 0 and 100
	public int windowAperture;
	//Id of the window that is being controlled
	public String windowId;
	//Floor in witch the dimmer is deployed, null if it is not in any floor
	public String floorId=null;
	//Room in witch the dimmer is deployed, null if it is not in any room
	public String roomId=null;
	//Device Kind
	public DeviceKind deviceKind;
	
	public WindowController(String id){
		super(id);
		deviceKind=new DeviceKind();
		deviceKind.setValue("WindowController");
		windowAperture=0;
		request=new WindowControllerPort();
		visualWindowController=new VisualWindowController();
	}
	
	public DeviceKind getDeviceKind() {
		return deviceKind;
	}

	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floor) {
		this.floorId = floor;
		visualWindowController.setFloorId(floor);
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String room) {
		this.roomId = room;
		visualWindowController.setRoomId(room);
	}

	public String getWindowId() {
		return windowId;
	}

	public void setWindowId(String windowId) {
		visualWindowController.setWindowId(windowId);
		this.windowId = windowId;
	}
	
	public int getWindowAperture() {
		return windowAperture;
	}

	public void setWindowAperture(int windowAperture) {
		visualWindowController.setAperture(windowAperture);
		this.windowAperture = windowAperture;
	}

	public WindowControllerPort getRequest() {
		return request;
	}
	
	public cclass WindowControllerPort extends TypePort implements IWindowController{
		public WindowControllerPort(){
			super();
		}
		
		public void setAperture(int value){
			WindowController.this.setWindowAperture(value);
		}
		public int getAperture(){
			return WindowController.this.getWindowAperture();
		}
		public String getId(){
			return WindowController.this.getWindowId();
		}
		public String getWindowId(){
			return WindowController.this.getWindowId();
		}
		
		public String getFloorId(){
			return WindowController.this.getFloorId();
		}
		
		public void setFloorId(String value){
			WindowController.this.setFloorId(value);
		}
		
		public String getRoomId(){
			return WindowController.this.getRoomId();
		}
		
		public void setRoomId(String value){
			WindowController.this.setRoomId(value);
		}
	}
}

