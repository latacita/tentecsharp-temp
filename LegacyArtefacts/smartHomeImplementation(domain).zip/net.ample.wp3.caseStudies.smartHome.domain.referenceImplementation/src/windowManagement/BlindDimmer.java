cclass windowManagement.WindowManagement;

public cclass BlindDimmer extends TypeComponent {

	public RequestPort request;
	//FloorId in witch the dimmer is deployed, null if it is not in a room
	public String floorId=null;
	//Room in witch the dimmer is deployed, null if it is not in any room
	public String roomId=null;
	//Id of the window that is controlled by the dimmer
	public String blindId;
	//Value of the dimmer regulator
	public int dimmerValue;
	//Device Kind
	public DeviceKind deviceKind;
	
	//Elements to made the dimmer visible since we have no real devices
	public VisualBlindDimmer visualDimmer;
	
	public BlindDimmer(String id){
		super(id);
		deviceKind=new DeviceKind();
		deviceKind.setValue("BlindDimmer");
		request=new RequestPort();
		visualDimmer=new VisualBlindDimmer(this);
	}
	
	public DeviceKind getDeviceKind() {
		return deviceKind;
	}

	public String getBlindId() {
		return blindId;
	}

	public void setBlindId(String blindId) {
		this.blindId = blindId;
		visualDimmer.setBlindId(blindId);
	}

	public int getDimmerValue() {
		return dimmerValue;
	}

	//This method doens't notify about the change
	public void setDimmerValue(int value) {
		this.dimmerValue=value;
		visualDimmer.setAperture(value);
	}
	
	//This method is called when the dimmer is changed manually by the user
	//The internal value of the dimmer is not changed here, since it will be done by the houseGateway
	public void changeDimmerValue(int value){
		ArrayList ports=request.getPortsIBlindDimmerNotify();
		//Tell all the connected components that the value has changed
		for(int i=0;i<ports.size();i++){
			((IBlindDimmerNotify)ports.get(i)).blindDimmerValueChanged(value,blindId);
		}
	}

	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floor) {
		this.floorId = floor;
		visualDimmer.setFloorId(floor);
	}

	public RequestPort getRequest() {
		return request;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String room) {
		this.roomId = room;
		visualDimmer.setRoomId(room);
	}

	public cclass RequestPort extends TypePort implements IBlindDimmer{
		
		public ArrayList portsIBlindDimmerNotify;
		
		public RequestPort(){
			super();
			portsIBlindDimmerNotify=new ArrayList();
		}
		
		public ArrayList getPortsIBlindDimmerNotify() {
			return portsIBlindDimmerNotify;
		}

		public void connectPort(IBlindDimmerNotify port){
			portsIBlindDimmerNotify.add(port);
		}
		
		public String getId(){
			return BlindDimmer.this.getId();
		}
		
		public String getBlindId(){
			return BlindDimmer.this.getBlindId();
		}
		
		public String getFloorId(){
			return BlindDimmer.this.getFloorId();
		}
		
		public void setFloorId(String value){
			BlindDimmer.this.setFloorId(value);
		}
		
		public String getRoomId(){
			return BlindDimmer.this.getRoomId();
		}
		
		public void setRoomId(String value){
			BlindDimmer.this.setRoomId(value);
		}
		
		public int getAperture(){
			return BlindDimmer.this.getDimmerValue();
		}
		
		public void setAperture(int value){
			BlindDimmer.this.setDimmerValue(value);
		}
	}
}

