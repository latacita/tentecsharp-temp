package windowManagement;

public interface IBlindController extends initialModel.IDevice{
	public void setAperture(int value);
	public int getAperture();
	//Get the Id of the blind controller by the controller
	public String getBlindId();
}
