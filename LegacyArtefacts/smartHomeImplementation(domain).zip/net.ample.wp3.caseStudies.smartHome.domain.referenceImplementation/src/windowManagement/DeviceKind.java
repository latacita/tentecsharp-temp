cclass windowManagement.WindowManagement;

public cclass DeviceKind {
    
	public DeviceKind(){
		values.add("WindowController");
		values.add("WindowDimmer");
		values.add("BlindDimmer");
		values.add("BlindController");
	}     
}
