package windowManagement;

public interface IWindowGUINotify {
	public void changeWindowAperture(String windowId,int value);
}
