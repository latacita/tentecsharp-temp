package windowManagement;
import initialModel.InitialModel;
import java.util.*;
import visual.windows.*;

public cclass WindowManagement extends InitialModel{

	public ArrayList windowDimmerList;
	public ArrayList blindDimmerList;
	public ArrayList windowControllerList;
	public ArrayList blindControllerList;
	
	public WindowManagement(){
		super();
		windowDimmerList=new ArrayList();
		blindDimmerList=new ArrayList();
		windowControllerList=new ArrayList();
		blindControllerList=new ArrayList();
	}
	
	public ArrayList getWindowDimmerList(){
		return windowDimmerList;
	}
	
	public ArrayList getBlindDimmerList(){
		return blindDimmerList;
	}
	
	public ArrayList getWindowControllerList(){
		return windowControllerList;
	}
	
	public ArrayList getBlindControllerList(){
		return blindControllerList;
	}
	
}
