cclass windowManagement.WindowManagement;

public cclass WindowDimmer extends TypeComponent {

	public RequestPort request;
	//FloorId in witch the dimmer is deployed, null if it is not in a room
	public String floorId=null;
	//Room in witch the dimmer is deployed, null if it is not in any room
	public String roomId=null;
	//Id of the window that is controlled by the dimmer
	public String windowId;
	//Value of the dimmer regulator
	public int dimmerValue;
	//Device Kind
	public DeviceKind deviceKind;
	
	//Elements to made the dimmer visible since we have no real devices
	public VisualWindowDimmer visualDimmer;
	
	public WindowDimmer(String id){
		super(id);
		deviceKind=new DeviceKind();
		deviceKind.setValue("WindowDimmer");
		request=new RequestPort();
		visualDimmer=new VisualWindowDimmer(this);
	}
	
	public DeviceKind getDeviceKind() {
		return deviceKind;
	}

	public String getWindowId() {
		return windowId;
	}

	public void setWindowId(String windowId) {
		this.windowId = windowId;
		visualDimmer.setWindowId(windowId);
	}

	public int getDimmerValue() {
		return dimmerValue;
	}

	//This method doens't notify about the change
	public void setDimmerValue(int value) {
		this.dimmerValue=value;
		visualDimmer.setAperture(value);
	}
	
	//This method is called when the dimmer is changed manually by the user
	//The internal value of the dimmer is not changed here, since it will be done by the houseGateway
	public void changeDimmerValue(int value){
		ArrayList ports=request.getPortsIWindowDimmerNotify();
		//Tell all the connected components that the value has changed
		for(int i=0;i<ports.size();i++){
			((IWindowDimmerNotify)ports.get(i)).windowDimmerValueChanged(value,windowId);
		}
	}

	public String getFloorId() {
		return floorId;
	}

	public void setFloorId(String floor) {
		this.floorId = floor;
		visualDimmer.setFloorId(floor);
	}

	public RequestPort getRequest() {
		return request;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String room) {
		this.roomId = room;
		visualDimmer.setRoomId(room);
	}

	public cclass RequestPort extends TypePort implements IWindowDimmer{
		
		public ArrayList portsIWindowDimmerNotify;
		
		public RequestPort(){
			super();
			portsIWindowDimmerNotify=new ArrayList();
		}
		
		public ArrayList getPortsIWindowDimmerNotify() {
			return portsIWindowDimmerNotify;
		}

		public void connectPort(IWindowDimmerNotify port){
			portsIWindowDimmerNotify.add(port);
		}
		
		public String getId(){
			return WindowDimmer.this.getId();
		}
		
		public String getWindowId(){
			return WindowDimmer.this.getWindowId();
		}
		
		public String getFloorId(){
			return WindowDimmer.this.getFloorId();
		}
		
		public void setFloorId(String value){
			WindowDimmer.this.setFloorId(value);
		}
		
		public String getRoomId(){
			return WindowDimmer.this.getRoomId();
		}
		
		public void setRoomId(String value){
			WindowDimmer.this.setRoomId(value);
		}
		
		public int getAperture(){
			return WindowDimmer.this.getDimmerValue();
		}
		
		public void setAperture(int value){
			WindowDimmer.this.setDimmerValue(value);
		}	
	}
}
