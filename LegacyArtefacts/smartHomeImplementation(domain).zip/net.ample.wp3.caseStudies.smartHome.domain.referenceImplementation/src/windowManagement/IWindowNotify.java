package windowManagement;

public interface IWindowNotify {
	public void changeWindowAperture(String windowId, int value);
}
