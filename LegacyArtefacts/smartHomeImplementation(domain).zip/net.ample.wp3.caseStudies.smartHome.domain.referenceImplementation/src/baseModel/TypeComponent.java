cclass baseModel.BaseModel;

public cclass TypeComponent {

	public String id;
	
	public TypeComponent(String id){
		this.id=id;
	}
	
	public String getId(){
		return id;
	}
	
	//Method that initialize the component
	public void init(){
		
	}
	
	public cclass TypePort{
		public TypeComponent comp;
		
		public TypePort(){
			
		}
	}
}
