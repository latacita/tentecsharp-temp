package heaterManagement;
import java.util.ArrayList;
import initialModel.*;
import visual.heater.*;

public cclass HeaterManagement extends InitialModel{
	
	public ArrayList heatingrControllerList;
	public ArrayList thermometerList;
	
	public HeaterManagement(){
		heatingrControllerList=new ArrayList();
		thermometerList=new ArrayList();
	}
	
	public ArrayList getHeatingControllerList(){
		return heatingrControllerList;
	}
	
	public ArrayList getThermometerList(){
		return thermometerList;
	}
	
}
