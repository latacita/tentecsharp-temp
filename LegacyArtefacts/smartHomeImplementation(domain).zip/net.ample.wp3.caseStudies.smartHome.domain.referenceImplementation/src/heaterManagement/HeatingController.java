cclass heaterManagement.HeaterManagement;

public cclass HeatingController extends TypeComponent{

	public RequestPort request;
	public int power;
	public HeaterManagement.HeatingModes mode;
	public boolean on;
	public VisualHeatingController visualGUI;
	
	//Id of the thermometer that is being controled
	public String heaterId;
	//Floor in witch the Switch is deployed
	public String floorId=null;
	//Room in witch the Switch is deployed, null if it is not in any room
	public String roomId=null;
	
	public HeatingController(String id){
		super(id);
		heaterId=new String("");
		request=new RequestPort();
		visualGUI=new VisualHeatingController(this);
	}
	
	public String getHeaterId(){
		return heaterId;
	}
	
	public void setHeaterId(String id){
		this.heaterId=id;
		this.visualGUI.setHeaterId(id);
	}
	
	public void setRoomId(String roomId){
		this.roomId=roomId;
		visualGUI.setRoomId(roomId);
	}
	
	public String getRoomId(){
		return this.roomId;
	}
	
	public void setFloorId(String id){
		this.floorId=id;
		visualGUI.setFloorId(id);
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public int getPower(){
		return power;
	}
	
	public HeaterManagement.HeatingModes getMode(){
		return mode;
	}
	
	public boolean IsOn(){
		return on;
	}
	
	public void setPower(String heaterId,int value){
		if(this.heaterId.equals(heaterId)){
			this.power=value;
			this.visualGUI.setPower(""+value);
		}
	}
	
	public void setMode(String heaterId,HeaterManagement.HeatingModes mode){
		if(this.heaterId.equals(heaterId)){
			this.mode=mode;
			this.visualGUI.setMode(mode.getStringValue());
		}
	}

	public void heatingSwitch(String heaterId,boolean on){
		if(this.heaterId.equals(heaterId)){
			this.on=on;
			if(on){
				this.visualGUI.setState("On");
			}else{
				this.visualGUI.setState("Off");
			}
		}
	}
	
	public RequestPort getRequest(){
		return request;
	}
	
	public cclass RequestPort extends TypePort implements IHeating{
		
		public RequestPort(){
			super();
		}
		
		public void setPower(String heaterId,int value){
			HeatingController.this.setPower(heaterId,value);
		}
		public void setMode(String heaterId,HeaterManagement.HeatingModes mode){
			HeatingController.this.setMode(heaterId,mode);
		}
		public void heatingSwitch(String heaterId,boolean on){
			HeatingController.this.heatingSwitch(heaterId,on);
		}
		
		public void setTemperature(String heaterId,float temp){
			//--------------------------------------------------
		}
	}
}
