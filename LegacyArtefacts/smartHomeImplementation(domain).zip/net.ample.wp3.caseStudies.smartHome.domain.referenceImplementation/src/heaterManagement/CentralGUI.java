cclass heaterManagement.HeaterManagement;

public cclass CentralGUI{

	public HeaterNotifyPort heaterNotifyPort;
	public CentralGeneralHeaterPanel generalHeaterPanel;
	
	public CentralGUI(String id){
		super(id);
		heaterNotifyPort=new HeaterNotifyPort();
		generalHeaterPanel=new CentralGeneralHeaterPanel(this);
		visualGUI.addPanel(generalHeaterPanel,"HeatingControl","/visual/icons/heating20.png");
	}
	
	public HeaterNotifyPort getHeaterNotifyPort(){
		return heaterNotifyPort;
	}
	
	public cclass HeaterNotifyPort extends TypePort{
		public ArrayList portsIGeneralHeaterNotify;
		
		public HeaterNotifyPort(){
			portsIGeneralHeaterNotify=new ArrayList();
		}
		
		public void connectPort(IGeneralHeaterNotify port){
			portsIGeneralHeaterNotify.add(port);
		}	
		
		public ArrayList getPortsIGeneralHeaterNotify(){
	    	return portsIGeneralHeaterNotify;
	    }
	}
	
	//Methods used by the visual GUI to notify to CentralGUI
	
	public void changeAllHeatersTemperature(float value){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).changeAllHeatersTemp(null,null,value);
		}
	}
	
	public void switchOnAllHeaters(){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).switchOnAllHeaters(null,null);
		}
	}
	
	public void switchOffAllHeaters(){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).switchOffAllHeaters(null,null);
		}
	}
}
