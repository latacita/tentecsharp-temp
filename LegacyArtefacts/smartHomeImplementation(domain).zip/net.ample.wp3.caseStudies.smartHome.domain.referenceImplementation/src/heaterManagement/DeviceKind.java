cclass heaterManagement.HeaterManagement;

public cclass DeviceKind {
	
	public DeviceKind(){
		values.add("Heating");
		values.add("Thermometer");
	}
}
