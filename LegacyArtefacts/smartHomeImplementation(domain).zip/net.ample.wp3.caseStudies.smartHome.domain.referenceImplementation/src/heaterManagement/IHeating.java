package heaterManagement;

public interface IHeating {
	public void setPower(String heaterId,int amount);
	public void setMode(String heaterId,HeaterManagement.HeatingModes mode);
	public void heatingSwitch(String heaterId,boolean on);
	public void setTemperature(String heaterId,float temperature);
}
