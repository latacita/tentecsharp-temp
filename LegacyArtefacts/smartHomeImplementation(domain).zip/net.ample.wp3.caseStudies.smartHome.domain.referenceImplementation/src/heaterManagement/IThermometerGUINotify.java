package heaterManagement;

public interface IThermometerGUINotify {
	public void newTemperature(String thermometerId,float temp);
	public void newOutsideTemperature(String thermometerId,float temp);
}
