cclass heaterManagement.HeaterManagement;

public cclass RoomGUI{

	public HeaterNotifyPort heaterNotifyPort;
	//Tabbed pane that is added to the main menu of the GUI
	protected HeaterGUITabbedPanel heaterTabbedPanel;
	//Tabbed pane that is added to the main menu of the GUI
	protected ThermometerGUITabbedPanel thermometerTabbedPanel;
	//Panel with the general option for the room heaters
	public RoomGeneralHeaterPanel generalHeaterPanel;
	//List of heater GUIs controlled by the room GUI
	protected ArrayList listHeaterGUI;
	//List of thermometer GUIs controlled by the room GUI
	protected ArrayList listThermometerGUI;
	
	public RoomGUI(String id){
		super(id);
		listHeaterGUI=new ArrayList();
		listThermometerGUI=new ArrayList();
		heaterTabbedPanel=new HeaterGUITabbedPanel();
		thermometerTabbedPanel=new ThermometerGUITabbedPanel();
		heaterNotifyPort=new HeaterNotifyPort();
		generalHeaterPanel=new RoomGeneralHeaterPanel(this);		
		visualGUI.addTabbedPanel(heaterTabbedPanel,"Heaters","/visual/icons/heater20.png");
		visualGUI.addTabbedPanel(thermometerTabbedPanel,"Thermometers","/visual/icons/thermometer20.png");
		visualGUI.addPanel(generalHeaterPanel,"HeatingControl","/visual/icons/heating20.png");
	}
	
	public HeaterNotifyPort getHeaterNotifyPort(){
		return heaterNotifyPort;
	}
	
	public void addListHeaterGUIElement(HeaterGUI heaterGUI){
		listHeaterGUI.add(heaterGUI);
		heaterTabbedPanel.addHeaterGUIPanel("HeaterGUI: "+heaterGUI.getId(),heaterGUI.getVisualGUI());
	}
	
	public void addListThermometerGUIElement(ThermometerGUI thermometerGUI){
		listThermometerGUI.add(thermometerGUI);
		thermometerTabbedPanel.addThermometerGUIPanel("ThermometerGUI: "+thermometerGUI.getId(),thermometerGUI.getVisualGUI());
	}
	
	public cclass HeaterNotifyPort extends TypePort{
		public ArrayList portsIGeneralHeaterNotify;
		
		public HeaterNotifyPort(){
			super();
			portsIGeneralHeaterNotify=new ArrayList();
		}
		
		public void connectPort(IGeneralHeaterNotify port){
			portsIGeneralHeaterNotify.add(port);
		}	
		
		public ArrayList getPortsIGeneralHeaterNotify(){
	    	return portsIGeneralHeaterNotify;
	    }
	}
	
	//Methods used by the visual GUI to notify to RoomGUI
	
	public void changeAllHeatersTemperature(float value){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).changeAllHeatersTemp(null,roomId,value);
		}
	}
	
	public void switchOnAllHeaters(){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).switchOnAllHeaters(null,roomId);
		}
	}
	
	public void switchOffAllHeaters(){
		ArrayList ports;
		ports=getHeaterNotifyPort().getPortsIGeneralHeaterNotify();
		for (int i=0;i<ports.size();i++){
			((IGeneralHeaterNotify)ports.get(i)).switchOffAllHeaters(null,roomId);
		}
	}
}