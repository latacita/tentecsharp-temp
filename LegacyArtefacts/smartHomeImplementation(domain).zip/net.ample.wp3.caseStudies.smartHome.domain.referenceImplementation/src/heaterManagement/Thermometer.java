cclass heaterManagement.HeaterManagement;

public cclass Thermometer extends TypeComponent{

	public VisualThermometer visualGUI;
	public RequestPort request;
	protected float temp=0;
	protected float outsideTemp=0;
	//Id of the thermometer that is being controled
	public String thermometerId;
	//Floor in witch the Switch is deployed
	public String floorId=null;
	//Room in witch the Switch is deployed, null if it is not in any room
	public String roomId=null;
	
	
	public Thermometer(String id){
		super(id);
		thermometerId=new String("");
		request=new RequestPort();
		visualGUI=new VisualThermometer(this);
	}
	
	public void setThermometerId(String id){
		this.thermometerId=id;
		visualGUI.setThermometerId(id);
	}
	
	public String getThermometerId(){
		return thermometerId;
	}
	
	public void setRoomId(String roomId){
		this.roomId=roomId;
		visualGUI.setRoomId(roomId);
	}
	
	public String getRoomId(){
		return this.roomId;
	}
	
	public void setFloorId(String id){
		this.floorId=id;
		visualGUI.setFloorId(floorId);
	}
	
	public String getFloorId(){
		return floorId;
	}
	
	public float getTemp(){
		return temp;
	}
	
	public float getOutsideTemp(){
		return outsideTemp;
	}
	
	//This method is called each time the temperature changes, it has to notify to the HouseGateway
	public void setTemp(float temp){
		this.temp=temp;
		ArrayList ports=this.getRequest().getPortsIThermometerNotify();
		for(int i=0;i<ports.size();i++){
			((IThermometerNotify)ports.get(i)).newTemperature(this.thermometerId,temp);
		}
	}
	
	//This method is called each time the temperature changes, it has to notify to the HouseGateway
	public void setOutsideTemp(float temp){
		this.outsideTemp=temp;
		this.temp=temp;
		ArrayList ports=this.getRequest().getPortsIThermometerNotify();
		for(int i=0;i<ports.size();i++){
			((IThermometerNotify)ports.get(i)).newOutsideTemp(this.thermometerId,temp);
		}
	}
	
	public RequestPort getRequest(){
		return request;
	}
	
	public cclass RequestPort extends TypePort implements IThermometer{
		public ArrayList portsIThermometerNotify;
		
		public RequestPort(){
			super();
			portsIThermometerNotify=new ArrayList();
		}
		
		public ArrayList getPortsIThermometerNotify(){
			return portsIThermometerNotify;
		}
		
		public void connectPort(IThermometerNotify port){
			portsIThermometerNotify.add(port);
		}
		
		public float getTemperature(String thermometerId){
			return Thermometer.this.getTemp();
		}
		public float getOutDoorTemperature(String thermometerId){
			return Thermometer.this.getOutsideTemp();
		}
	}
}
