package visual.initial;

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class RoomGUIPanel extends JPanel {
	JPanel namePanel;	//Panel that contains the name of the GUI
	JTabbedPane tabbedMenu; //Tabbed menu for the GUI
	JLabel guiName;	//Name of the GUI
	
	JPanel generalOptionsPanel;

	//Test Stuff
	JLabel l1;
	
	
	public RoomGUIPanel (String name){
		namePanel=new JPanel();	
		guiName=new JLabel(name);	//Name of the GUI
		
		namePanel.add(guiName);
		
		//Tabbed pannel test-------------------------
		generalOptionsPanel=new JPanel();
		//Add some text
		l1=new JLabel("This panel contains the general controller that affects a room in the house");
		
		generalOptionsPanel.add(l1);
		
		tabbedMenu = new JTabbedPane();
		
		//tabbedMenu.addTab("General",generalOptionsPanel);
		
		this.setLayout(new BorderLayout());
		//this.add(namePanel,BorderLayout.PAGE_START);
		this.add(tabbedMenu,BorderLayout.CENTER);	
	}
	
	public String getNamePanel(){
		return this.guiName.getText();
	}
	
	//Method to add an panel item to the tabbedMenu
	public void addPanel(JPanel newPanel,String name){
		tabbedMenu.add(name,newPanel);
	}
	
	//Method to add an panel item to the tabbedMenu with an icon
	public void addPanel(JPanel newPanel,String name,String iconUrl){
		ImageIcon icon=createImageIcon(iconUrl);
		tabbedMenu.addTab(name, icon, newPanel);
	}
	
	//Method to add an tabbedMenu item to the tabbedMenu
	public void addTabbedPanel(JTabbedPane newPanel,String name){
		tabbedMenu.add(name,newPanel);
	}
	
	//Method to add an tabbedMenu item to the tabbedMenu with an icon
	public void addTabbedPanel(JTabbedPane newPanel,String name,String iconUrl){
		ImageIcon icon=createImageIcon(iconUrl);
		tabbedMenu.addTab(name,icon,newPanel);
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
