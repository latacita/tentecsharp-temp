package visual.smartEnergy;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;


public class VisualSmartEnergyPanel extends JPanel {

	public JLabel state;
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualSmartEnergyPanel(){
		super();
		state=new JLabel("Smart energy OFF");
		iconImage=createImageIcon("/visual/icons/energySaver40.png","Bulb icon");
		icon=new JLabel(iconImage);
		
		this.add(icon);
		this.add(state);
	}
	
	public void activate(){
		state.setText("Smart energy ON");
	}
	
	public void deactivate(){
		state.setText("Smart energy OFF");
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
