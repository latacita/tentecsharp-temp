package visual.lights;
import javax.swing.*;

public class LightGUITabbedPanel extends JTabbedPane {

	public LightGUITabbedPanel(){
		super();
	}
	
	public void addLightGUIPanel(String name,LightGUIPanel newPanel){
		this.addTab(name,createImageIcon("/visual/icons/bulb20.png"),newPanel);
	}
	

	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
