package visual.lights;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import lightManagement.LightManagement.LightController;
import initialModel.InitialModel;

//Very simple visual class that simulates a LightController
public class VisualLightController extends JPanel{
	public JLabel intensityText;
	public JLabel intensity;
	public JLabel stateText;
	public JLabel state;
	public JLabel lightId;
	public String lightIdString;
	public String roomIdString;
	public String floorIdString;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualLightController(){
		super();
		iconImage=createImageIcon("/visual/icons/bulb40.png","Bulb icon");
		icon=new JLabel(iconImage);
		lightIdString=null;
		roomIdString=null;
		lightId=new JLabel();
		intensityText=new JLabel ("Intensity: ");
		stateText=new JLabel ("State: ");
		intensity=new JLabel("00");
		state=new JLabel("Off");
		this.add(icon);
		this.add(lightId);
		this.add(intensityText);
		this.add(intensity);
		this.add(stateText);
		this.add(state);
	}
	
	public void setLightId(String lightId){
		this.lightId.setText(lightId);
		lightIdString=lightId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightController", lightIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightController", lightIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightController", lightIdString, this);
		}
	}
	
	public void setState(boolean state){
		if(state){
			this.state.setText("On");
		}else{
			this.state.setText("Off");
		}
	}
	
	public void setIntensity(int value){
		this.intensity.setText(Integer.toString(value));
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
