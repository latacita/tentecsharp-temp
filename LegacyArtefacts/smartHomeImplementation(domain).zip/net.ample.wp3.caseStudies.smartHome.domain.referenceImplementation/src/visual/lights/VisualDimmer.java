package visual.lights;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import lightManagement.LightManagement.Dimmer;

//Auxiliar class to show the dimmer in the Screen

public class VisualDimmer extends JPanel implements ChangeListener{
	
	//Reference to the Dimmer component in which it is contained
	public Dimmer dimmer;
	//Required swing visual elements
	public JLabel intensityText;
	public JLabel intensity;
	public JSlider intensitySlider;
	JLabel lightId;
	String lightIdString;
	String roomIdString;
	String floorIdString;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualDimmer(Dimmer dimmer){
		
		iconImage=createImageIcon("/visual/icons/bulb40.png","Bulb icon");
		icon=new JLabel(iconImage);
		this.dimmer=dimmer;
		lightId=new JLabel();
		lightIdString=null;
		roomIdString=null;
		this.intensitySlider=new JSlider();
		this.intensitySlider.setMaximum(100);
		this.intensitySlider.setPreferredSize(new Dimension(90, 16));
		this.intensitySlider.setValue(0);
		this.intensitySlider.addChangeListener(this);
		
		this.intensity = new JLabel();
		this.intensity.setText("0");
		this.intensity.setFont(new Font("Dialog", Font.BOLD, 10));
		this.intensityText = new JLabel();
		this.intensityText.setText("  Intensity:");
		this.intensityText.setFont(new Font("Dialog", Font.BOLD, 10));
		this.intensityText.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		this.add(icon);
		this.add(lightId);
		this.add(intensityText);
		this.add(intensity);
		this.add(intensitySlider);
		
	}
	
	public void setIntensity(int intensity){
		this.intensity.setText(Integer.toString(intensity));
		this.intensitySlider.setValue(intensity);
	}
	
	public void setLightId(String lightId){
		this.lightId.setText(lightId);
		lightIdString=lightId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightDimmer", lightIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightDimmer", lightIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((lightIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "LightDimmer", lightIdString, this);
		}
	}
	
	public void stateChanged(ChangeEvent e) {	
		//Intensity slider moved
	    JSlider source = (JSlider)e.getSource();
	    intensity.setText(String.valueOf(source.getValue()));
	    dimmer.changeDimmerValue(source.getValue());
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
