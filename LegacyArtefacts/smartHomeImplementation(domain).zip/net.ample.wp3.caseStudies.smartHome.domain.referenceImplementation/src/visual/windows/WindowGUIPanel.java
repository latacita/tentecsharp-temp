package visual.windows;
import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import windowManagement.*;


public class WindowGUIPanel extends JPanel implements ChangeListener{
	
	//Variable to store a reference to the CaesarJ GUIComponent of the light of the panel 
	WindowManagement.WindowGUI guiComponent;
	String windowId;
	JSlider apertureSlider;
	JLabel aperture;
	JLabel apertureText;
	JLabel id;
	int apertureValue;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public String getWindowId() {
		return windowId;
	}

	public void setWindowId(String id) {
		this.windowId = id;
		this.id.setText(id);
	}

	public int getAperture() {
		return apertureValue;
	}

	public void setAperture(int aperture) {
		this.aperture.setText(Integer.toString(aperture));
		this.apertureSlider.setValue(aperture);
		this.apertureValue=aperture;
	}
	
	public WindowGUIPanel(WindowManagement.WindowGUI guiComponent){
		super();
		this.guiComponent=guiComponent;
		this.apertureValue=00;
		iconImage=createImageIcon("/visual/icons/window40.png","Bulb icon");
		icon=new JLabel(iconImage);
		this.id=new JLabel();
		
		this.apertureSlider=new JSlider();
		this.apertureSlider.setMaximum(100);
		this.apertureSlider.setPreferredSize(new Dimension(90, 16));
		this.apertureSlider.setValue(00);
		this.apertureSlider.addChangeListener(this);
		
		this.aperture = new JLabel();
		this.aperture.setText("00");
		this.aperture.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText = new JLabel();
		this.apertureText.setText("  Aperture:");
		this.apertureText.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		this.add(icon);
		this.add(this.id);
		this.add(apertureSlider);
		this.add(apertureText);
		this.add(this.aperture);
	}
	
	//----------------------EVENTS--------------------------------------------------

	public void stateChanged(ChangeEvent e) {
		//Intensity slider moved
	    JSlider source = (JSlider)e.getSource();
	    aperture.setText(String.valueOf(source.getValue()));
	    guiComponent.notifyWindowApertureChange(windowId,source.getValue());
	}
	
	//Change the window aperture if it exists
	public void changeWindowAperture(String id, int value){
		if(windowId.equals(id)){
			setAperture(value);
		}
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}