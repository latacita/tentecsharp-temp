package visual.windows;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import windowManagement.*;

public class FloorGeneralWindowPanel extends JPanel implements ActionListener{
		
	//Variable to store a reference to the CaesarJ GUIComponent that represent this visual class 
	WindowManagement.FloorGUI guiComponent;
	JButton switchOnButton;
	JButton switchOffButton;
	JButton applyButton;
	JTextField apertureField;
	JLabel aperture;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
		
	public FloorGeneralWindowPanel(WindowManagement.FloorGUI guiComponent){
		this.guiComponent=guiComponent;
		iconImage=createImageIcon("/visual/icons/windows40.png","Bulb icon");
		icon=new JLabel(iconImage);
		this.switchOnButton=new JButton("OpenAll");
		this.switchOnButton.setText("OpenAll");
		this.switchOnButton.setActionCommand("open");
		this.switchOnButton.addActionListener(this);
		
		this.switchOffButton=new JButton("CloseAll");
		this.switchOffButton.setText("CloseAll");
		this.switchOffButton.setActionCommand("close");
		this.switchOffButton.addActionListener(this);
		
		this.applyButton=new JButton("Apply");
		this.applyButton.setText("ApplyAperture");
		this.applyButton.setActionCommand("apply");
		this.applyButton.addActionListener(this);
		
		this.aperture=new JLabel("Aperture:");
		this.apertureField=new JTextField();
		this.apertureField.setText("00");
		
		this.add(icon);
		this.add(switchOnButton);
		this.add(switchOffButton);
		this.add(aperture);
		this.add(apertureField);
		this.add(applyButton);
		
		
	}

	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("apply".equals(e.getActionCommand())) {
			try{
				int value=Integer.parseInt(apertureField.getText());
				if((0<=value)&&(value<=100)){
					guiComponent.changeAllWindowsAperture(value);
				}else{
					System.err.println("Error in FloorGeneralWindowPanel: The entered aperture is not valid");
				}
			}catch(Exception ex){
				System.err.println("Exception in FloorGeneralWindowPanel: "+ex.toString());
			}
	    } else if ("open".equals(e.getActionCommand())) {
	    	guiComponent.changeAllWindowsAperture(100);
	    } else if ("close".equals(e.getActionCommand())) {
	    	guiComponent.changeAllWindowsAperture(0);
	    } 
	} 	
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}