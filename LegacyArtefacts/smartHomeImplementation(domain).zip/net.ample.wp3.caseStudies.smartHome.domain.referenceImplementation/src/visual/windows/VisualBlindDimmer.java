package visual.windows;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import windowManagement.WindowManagement.BlindDimmer;

//Auxiliary class to show the dimmer in the Screen

public class VisualBlindDimmer extends JPanel implements ChangeListener{
	
	//Reference to the Dimmer component in which it is contained
	public BlindDimmer dimmer;
	//Required swing visual elements
	public JFrame frame;
	public JLabel apertureText;
	public JLabel aperture;
	public JSlider apertureSlider;
	public String blindIdString;
	public String roomIdString;
	public String floorIdString;
	public JLabel blindId;
	
	//Light icon
	ImageIcon iconImage;
	JLabel icon;
	
	public VisualBlindDimmer(BlindDimmer dimmer){
		this.dimmer=dimmer;
		iconImage=createImageIcon("/visual/icons/blind40.png","Bulb icon");
		icon=new JLabel(iconImage);
		blindId=new JLabel();
		blindIdString=null;
		roomIdString=null;
		
		this.apertureSlider=new JSlider();
		this.apertureSlider.setMaximum(100);
		this.apertureSlider.setPreferredSize(new Dimension(90, 16));
		this.apertureSlider.setValue(0);
		this.apertureSlider.addChangeListener(this);
		
		this.aperture = new JLabel();
		this.aperture.setText("0");
		this.aperture.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText = new JLabel();
		this.apertureText.setText("  Aperture:");
		this.apertureText.setFont(new Font("Dialog", Font.BOLD, 10));
		this.apertureText.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		this.add(icon);
		this.add(blindId);
		this.add(apertureText);
		this.add(aperture);
		this.add(apertureSlider);
		
	}
	
	public void setAperture(int aperture){
		this.aperture.setText(Integer.toString(aperture));
		this.apertureSlider.setValue(aperture);
	}
	
	public void setBlindId(String blindId){
		this.blindId.setText(blindId);
		blindIdString=blindId;
		if((blindIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "BlindDimmer", blindIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((blindIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "BlindDimmer", blindIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((blindIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "BlindDimmer", blindIdString, this);
		}
	}
	
	public void stateChanged(ChangeEvent e) {	
		//Intensity slider moved
	    JSlider source = (JSlider)e.getSource();
	    aperture.setText(String.valueOf(source.getValue()));
	    dimmer.changeDimmerValue(source.getValue());
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}