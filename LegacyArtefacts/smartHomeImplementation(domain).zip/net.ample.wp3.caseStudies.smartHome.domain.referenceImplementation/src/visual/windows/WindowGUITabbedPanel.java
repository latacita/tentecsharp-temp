package visual.windows;
import javax.swing.*;

public class WindowGUITabbedPanel extends JTabbedPane {

	public WindowGUITabbedPanel(){
		super();
	}
	
	public void addWindowGUIPanel(String name,WindowGUIPanel newPanel){
		this.addTab(name,createImageIcon("/visual/icons/window20.png"),newPanel);
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
