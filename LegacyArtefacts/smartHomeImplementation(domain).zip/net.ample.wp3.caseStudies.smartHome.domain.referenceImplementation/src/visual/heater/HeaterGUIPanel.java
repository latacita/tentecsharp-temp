package visual.heater;

import javax.swing.*;
import javax.swing.event.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import heaterManagement.*;

public class HeaterGUIPanel extends JPanel implements ActionListener{
	
	//Variable to store a reference to the CaesarJ GUIComponent of the heater of the panel 
	public HeaterManagement.HeaterGUI guiComponent; 
	public String heaterId;
	public JLabel id;
	public JLabel power;
	public JLabel powerText;
	public JLabel mode;
	public JLabel modeText;
	public JLabel state;
	public JLabel stateText;
	public JLabel temp;
	public JLabel tempText;
	public JButton applyTemp;
	public JButton changeState;
	public JTextField tempField;
	public JLabel tempFieldText;
	
	//Thermometer icon
	ImageIcon iconImage;
	JLabel icon;
	
	public String getHeaterId() {
		return heaterId;
	}

	public void setHeaterId(String id) {
		this.heaterId = id;
		this.id.setText(id);
	}
	
	public String getPower() {
		return power.getText();
	}

	public void setPower(String power){
		this.power.setText(power);
	}
	
	public String getTemp() {
		return temp.getText();
	}

	public void setTemp(String temp){
		this.temp.setText(temp);
	}
	
	public String getMode() {
		return mode.getText();
	}

	public void setMode(String mode){
		this.mode.setText(mode);
	}
	
	public String getState(){
		return this.state.getText();
	}
	
	public void setState(String state) {
		this.state.setText(state);
		if(state.equals("On")){
			changeState.setText("SwitchOff");
		}else{
			changeState.setText("SwitchOn");
		}
	}
	
	public HeaterGUIPanel(HeaterManagement.HeaterGUI guiComponent ){
		super();
		this.id=new JLabel("");
		this.guiComponent=guiComponent;
		
		iconImage=createImageIcon("/visual/icons/heater40.png","Thermomter icon");
		icon=new JLabel(iconImage);
		
		this.powerText=new JLabel("Power: ");
		this.power=new JLabel("00");
		this.modeText=new JLabel("Mode: ");
		this.mode=new JLabel("Cooling");
		this.stateText=new JLabel("State: ");
		this.state=new JLabel("Off");
		this.temp=new JLabel("24");
		this.tempText=new JLabel("Temp: ");
		this.tempFieldText=new JLabel("NewTemp: ");
		this.tempField=new JTextField("24");
		
		this.applyTemp=new JButton("Apply");
		this.applyTemp.setActionCommand("ApplyTemp");
		this.applyTemp.addActionListener(this);
		
		this.changeState=new JButton("state");
		this.changeState.setActionCommand("state");
		this.changeState.addActionListener(this);
		this.changeState.setText("SwitchOn");
		
		this.tempField=new JTextField("24");
		
		this.add(icon);
		this.add(this.id);
		this.add(this.powerText);
		this.add(this.power);
		this.add(this.modeText);
		this.add(this.mode);
		this.add(this.stateText);
		this.add(this.state);
		this.add(this.tempText);
		this.add(this.temp);
		this.add(this.tempFieldText);
		this.add(this.tempField);
		this.add(this.applyTemp);
		this.add(this.changeState);
		
	}
	
	//----------------------EVENTS--------------------------------------------------
			
	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("ApplyTemp".equals(e.getActionCommand())) {
	        try{
	        	float temp=Float.parseFloat(tempField.getText());
	        	this.temp.setText(""+temp);
	        	guiComponent.heaterTemperatureChanged(heaterId,temp);
	        }catch (Exception ex){
	        	System.err.println("Exception in HeaterPanel: "+ex.toString());
	        }
			
	    } else if ("state".equals(e.getActionCommand())) {
	        JButton b=((JButton)e.getSource());
	        if(b.getText().equals("SwitchOff")){
	        	b.setText("SwitchOn");
	        	state.setText("Off");
	        	guiComponent.heaterSwitchChanged(heaterId,false);
	        }else{
	        	b.setText("SwitchOff");
	        	state.setText("On");
	        	guiComponent.heaterSwitchChanged(heaterId,true);
	        }
	    } 
	} 	
	
	//---------------------------------------------------------------------
	//Methods used by the GUI componentes----------------------------------
	//---------------------------------------------------------------------
	
	
	//Change the heater power if it exists
	public void changeHeaterPower(String id, String power){
		if(this.heaterId.equals(id)){
			setPower(power);
		}
	}
	
	//Change the heater mode if it exists
	public void changeHeaterMode(String id, String mode){
		if(this.heaterId.equals(id)){
			setMode(mode);
		}
	}
	
	//Change the heater state if it exists
	public void changeHeaterState(String id, String state){
		if(this.heaterId.equals(id)){
			setState(state);
		}
	}
	
	//Change the heater temperature if it exists
	public void changeHeaterTemperature(String id, String temp){
		if(this.heaterId.equals(id)){
			setTemp(temp);
		}
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
	
}
