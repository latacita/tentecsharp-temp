package visual.heater;

import initialModel.InitialModel;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import heaterManagement.*;

public class VisualThermometer extends JPanel implements ActionListener{
		
	//Variable to store a reference to the CaesarJ GUIComponent that represent this visual class 
	HeaterManagement.Thermometer guiComponent;
	//Required swing visual elements
	JLabel thermometerId;
	String thermometerIdString;
	String roomIdString;
	String floorIdString;
	
	JButton applyOutsideButton;
	JButton applyInsideButton;
	JTextField insideField;
	JTextField outsideField;
	JLabel inside;
	JLabel outside;
	
	//Thermometer icon
	ImageIcon iconImage;
	JLabel icon;
		
	public VisualThermometer(HeaterManagement.Thermometer guiComponent){
		this.guiComponent=guiComponent;
		
		iconImage=createImageIcon("/visual/icons/thermometer40.png","Thermomter icon");
		icon=new JLabel(iconImage);
		thermometerId=new JLabel();
		thermometerIdString=null;
		roomIdString=null;
		
		this.applyInsideButton=new JButton("ApplyInside");
		this.applyInsideButton.setText("Set Temp");
		this.applyInsideButton.setActionCommand("applyInside");
		this.applyInsideButton.addActionListener(this);
		
		this.applyOutsideButton=new JButton("ApplyOutside");
		this.applyOutsideButton.setText("Set Temp");
		this.applyOutsideButton.setActionCommand("applyOutside");
		this.applyOutsideButton.addActionListener(this);
		
		this.inside=new JLabel("InsideTemp:");
		this.insideField=new JTextField();
		this.insideField.setText("25");
		
		this.outside=new JLabel("OutsideTemp:");
		this.outsideField=new JTextField();
		this.outsideField.setText("30");
		
		this.add(icon);
		this.add(thermometerId);
		this.add(inside);
		this.add(insideField);
		this.add(applyInsideButton);
		this.add(outside);
		this.add(outsideField);
		this.add(applyOutsideButton);
	}

	public void setThermometerId(String thermometerId){
		this.thermometerId.setText(thermometerId);
		thermometerIdString=thermometerId;
		if((thermometerIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "Thermometer", thermometerIdString, this);
		}
	}
	
	public void setRoomId(String roomId){
		this.roomIdString=roomId;
		if((thermometerIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "Thermometer", thermometerIdString, this);
		}
	}
	
	public void setFloorId(String floorId){
		this.floorIdString=floorId;
		if((thermometerIdString!=null)&&(roomIdString!=null)&&(floorIdString!=null)){
			InitialModel.addDevice(floorIdString,roomIdString, "Thermometer", thermometerIdString, this);
		}
	}
	
	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("applyInside".equals(e.getActionCommand())) {
			try{
				float value=Float.parseFloat(insideField.getText());
				if((-60<=value)&&(value<=55)){
					guiComponent.setTemp(value);
				}else{
					System.err.println("Error in VisualThermometer: The temperature value is not valid");
				}
			}catch(Exception ex){
				System.err.println("Exception in in VisualThermometer:: "+ex.toString());
			}
	    }else if ("applyOutside".equals(e.getActionCommand())) {
			try{
				float value=Float.parseFloat(outsideField.getText());
				if((-60<=value)&&(value<=55)){
					guiComponent.setOutsideTemp(value);
				}else{
					System.err.println("Error in VisualThermometer: The temperature value is not valid");
				}
			}catch(Exception ex){
				System.err.println("Exception in in VisualThermometer:: "+ex.toString());
			}
	    }
	} 	
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
