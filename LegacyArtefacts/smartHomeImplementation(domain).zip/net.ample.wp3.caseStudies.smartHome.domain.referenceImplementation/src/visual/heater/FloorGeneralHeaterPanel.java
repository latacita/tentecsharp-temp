package visual.heater;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import heaterManagement.*;

public class FloorGeneralHeaterPanel extends JPanel implements ActionListener{
		
	//Variable to store a reference to the CaesarJ GUIComponent that represent this visual class 
	HeaterManagement.FloorGUI guiComponent;
	JButton switchOnButton;
	JButton switchOffButton;
	JButton applyButton;
	JTextField temperatureField;
	JLabel temperature;
	//Thermometer icon
	ImageIcon iconImage;
	JLabel icon;
		
	public FloorGeneralHeaterPanel(HeaterManagement.FloorGUI guiComponent){
		this.guiComponent=guiComponent;
		iconImage=createImageIcon("/visual/icons/heating40.png","Thermomter icon");
		icon=new JLabel(iconImage);
		this.switchOnButton=new JButton("SwitchOnAll");
		this.switchOnButton.setText("SwitchOnAll");
		this.switchOnButton.setActionCommand("switchOn");
		this.switchOnButton.addActionListener(this);
		
		this.switchOffButton=new JButton("SwitchOffAll");
		this.switchOffButton.setText("SwitchOffAll");
		this.switchOffButton.setActionCommand("switchOff");
		this.switchOffButton.addActionListener(this);
		
		this.applyButton=new JButton("Apply");
		this.applyButton.setText("ApplyTemperature");
		this.applyButton.setActionCommand("apply");
		this.applyButton.addActionListener(this);
		
		this.temperature=new JLabel("Temperature:");
		this.temperatureField=new JTextField();
		this.temperatureField.setText("00");
		
		this.add(icon);
		this.add(switchOnButton);
		this.add(switchOffButton);
		this.add(temperature);
		this.add(temperatureField);
		this.add(applyButton);
		
		
	}

	public void actionPerformed(ActionEvent e) {
	    //TurnOn/OFF button pressed
		if ("apply".equals(e.getActionCommand())) {
			try{
				float value=Float.parseFloat(temperatureField.getText());
				if((0<=value)&&(value<=100)){
					guiComponent.changeAllHeatersTemperature(value);
				}else{
					System.err.println("Error in FloorGeneralHeaterPanel: The entered temperature is not valid");
				}
			}catch(Exception ex){
				System.err.println("Exception in FloorGeneralHeaterPanel: "+ex.toString());
			}
	    } else if ("switchOn".equals(e.getActionCommand())) {
	    	guiComponent.switchOnAllHeaters();
	    } else if ("switchOff".equals(e.getActionCommand())) {
	    	guiComponent.switchOffAllHeaters();
	    } 
	} 	
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}