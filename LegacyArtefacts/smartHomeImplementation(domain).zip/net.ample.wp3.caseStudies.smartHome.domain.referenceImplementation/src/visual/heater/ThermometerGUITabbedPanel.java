package visual.heater;
import javax.swing.*;

public class ThermometerGUITabbedPanel extends JTabbedPane {

	public ThermometerGUITabbedPanel(){
		super();
	}
	
	public void addThermometerGUIPanel(String name,ThermometerGUIPanel newPanel){
		this.addTab(name,createImageIcon("/visual/icons/thermometer20.png"),newPanel);
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
